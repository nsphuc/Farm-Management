# ĐẶC TẢ THIẾT KẾ KIẾN TRÚC TỔNG THỂ HỆ THỐNG AGRI-ERP
## (MASTER SYSTEM ARCHITECTURE & TECHNICAL DESIGN SPECIFICATION)

> **Mã văn kiện:** `SPEC-ARCH-011`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Là Bản Thiết Kế Kiến Trúc Nền Tảng Dành Cho Backend & Frontend Engineers.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Tôn chỉ:** *"Phân lớp rạch ròi (Strict Layering) - Mô-đun hóa độc lập (Modular Monolith) - Không phụ thuộc vòng lặp (Zero Circular Dependency)"*.

---

## 1. KIẾN TRÚC TỔNG THỂ & PHÂN LỚP HỆ THỐNG (LAYERED MODULAR MONOLITH)

Hệ thống Quản trị Nông nghiệp Đa Trang trại (Farm Management SaaS) được thiết kế theo mô hình **Layered Modular Monolith**. Lựa chọn này đảm bảo toàn vẹn giao dịch ACID tuyệt đối (đặc biệt quan trọng với hạch toán kho hàng, công nợ, giá thành), đồng thời loại bỏ độ trễ mạng và độ phức tạp vận hành của Microservices trong giai đoạn 1.

### 1.1. Sơ Đồ Kiến Trúc Phân Lớp Toàn Diện (End-to-End Architecture)

```mermaid
graph TD
    subgraph "CLIENT TIER (React 18+ Vite SPA)"
        S1[AuthShell: /login, /force-change-password]
        S2[PlatformShell: /platform/* - Super Admin]
        S3[TenantAppShell: /app/* - 9 Workspaces]
        S4[PublicTraceShell: /trace/:code - Cổng QR]
    end

    subgraph "EDGE & SECURITY TIER"
        CORS[CORS & Rate Limiter Filter]
        JWT[JwtAuthenticationFilter: Access Token Bearer]
        CTX[SecurityContextHolder: TenantId & Accessible Farms]
    end

    subgraph "PRESENTATION TIER (Spring Boot Controllers)"
        CTRL[REST Controllers: Validate Request DTO with Jakarta]
        EXP_HND[GlobalExceptionHandler: Standard ApiErrorResponse]
    end

    subgraph "BUSINESS APPLICATION TIER (Spring Services)"
        SVC[Application Services: @Transactional Boundary]
        GUARD[Security Guards: @farmSecurity, Maker-Checker QC]
        EVENT_PUB[ApplicationEventPublisher: Domain Events]
    end

    subgraph "PERSISTENCE TIER (Spring Data JPA / Hibernate)"
        REPO[JPA Repositories: Specifications, Projections, Locks]
        MAPPER[MapStruct Mappers: Entity <-> DTO]
    end

    subgraph "DATA STORAGE TIER"
        DB[(MySQL 8.x InnoDB: 72 Tables, Foreign Keys, Check Constraints)]
        S3_STORAGE[(Object Storage / S3 CDN: Ảnh Chấm Công, Hóa Đơn, POD)]
    end

    S1 & S2 & S3 & S4 -->|HTTP REST / JSON| CORS
    CORS --> JWT --> CTX --> CTRL
    CTRL -->|Dùng DTO| SVC
    SVC --> GUARD
    SVC -->|Query / Save Entity| REPO
    SVC -->|Bắn sự kiện sau Commit| EVENT_PUB
    REPO -->|SQL Dialect / ACID| DB
    SVC -.->|Upload / Get Media URL| S3_STORAGE
    CTRL -.->|Bắt lỗi nghiệp vụ| EXP_HND
```

### 1.2. Quy Tắc Ranh Giới Phụ Thuộc Bất Khả Xâm Phạm (Strict Dependency Rules)

1.  **Quy tắc Dòng Chảy Đơn Chiều (Unidirectional Flow):**
    $$\text{Controller} \longrightarrow \text{Service} \longrightarrow \text{Repository} \longrightarrow \text{Database}$$
    *   **Controller:** Chỉ làm việc với `Request DTO` và `Response DTO`. Tuyệt đối cấm Controller gọi trực tiếp `Repository` mà không qua `Service`.
    *   **Service:** Chứa 100% logic nghiệp vụ, tính toán công thức, phân bổ chi phí, quản lý ranh giới giao dịch `@Transactional`. Service không bao giờ nhận hoặc trả HTTP Servlet Object (`HttpServletRequest`, `HttpServletResponse`).
    *   **Repository:** Chỉ làm nhiệm vụ truy vấn cơ sở dữ liệu (`save`, `findById`, `findAll`, custom queries với `@Query` hoặc `JpaSpecificationExecutor`).
2.  **Nguyên Tắc Chống Rò Rỉ Entity (Zero Entity Leakage):**
    *   Entity JPA **TUYỆT ĐỐI KHÔNG ĐƯỢC THOÁT RA KHỎI TẦNG SERVICE**.
    *   Controller không được biết đến cấu trúc nội bộ của Entity. Mọi dữ liệu trả về cho Controller bắt buộc phải được chuyển đổi thành `Response DTO` thông qua MapStruct Mapper.
    *   Điều này loại bỏ hoàn toàn lỗi tuần tự hóa JSON vòng lặp (`JsonBackReference`), lỗi `LazyInitializationException` và rò rỉ dữ liệu nhạy cảm (như `password_hash`).

---

## 2. CẤU TRÚC PACKAGE BACKEND SPRING BOOT CHUẨN

Mã nguồn Backend (`backend/src/main/java/com/farm/saas/...`) được chia thành 2 khối rạch ròi: `common` (nền tảng dùng chung) và `modules` (10 phân hệ nghiệp vụ độc lập tương ứng với 72 bảng).

```
backend/src/main/java/com/farm/saas/
├── FarmSaasApplication.java
│
├── common/                                # Khối Tiện Ích & Hạ Tầng Dùng Chung
│   ├── config/                            # Cấu hình Spring (Async, Cors, Jackson, Cache)
│   ├── security/                          # Bảo mật Spring Security
│   │   ├── auth/                          # UserDetails, TokenProvider, AuthEntryPoint
│   │   ├── filter/                        # JwtAuthenticationFilter, TenantContextFilter
│   │   └── guard/                         # FarmSecurityGuard (@farmSecurity)
│   ├── exception/                         # Xử lý Ngoại lệ Toàn cục
│   │   ├── GlobalExceptionHandler.java    # ControllerAdvice chuẩn hóa ApiErrorResponse
│   │   ├── BusinessException.java         # Ngoại lệ cơ sở cho lỗi nghiệp vụ
│   │   ├── InsufficientStockException.java# Lỗi xuất vượt tồn khả dụng
│   │   └── ResourceNotFoundException.java # Lỗi không tìm thấy thực thể
│   ├── audit/                             # Audit Trail Tự Động
│   │   ├── AuditLogAspect.java            # AOP Aspect bắt các thay đổi nhạy cảm
│   │   └── EntityAuditorAware.java        # Tự động điền createdBy/updatedBy
│   ├── util/                              # Hàm tiện ích (DateUtils, GeoDistanceUtils, BarcodeParser)
│   └── codegenerator/                     # Bộ sinh mã nghiệp vụ tự động (SO-, RC-, IS-, BAT-)
│
└── modules/                               # 10 Phân Hệ Nghiệp Vụ Theo Chuẩn 72 Bảng
    ├── platform/                          # Phân hệ 1: Tenants, Subscriptions, Enterprises
    ├── auth/                              # Phân hệ 2: Users, Roles, Permissions, Refresh Tokens
    ├── geography/                         # Phân hệ 3: Farms, Zones, Locations, Cycles, Assignments
    ├── masterdata/                        # Phân hệ 4: Crop Types, Breeds, Materials, Quotas, Shifts
    ├── inventory/                         # Phân hệ 5: Warehouses, Inventory, Receipts, Issues, Transfers
    ├── crop/                              # Phân hệ 6A: Crop Seasons, Farming Logs, Backflushing
    ├── livestock/                         # Phân hệ 6B: Livestock Groups, Weight Logs, Vet Events
    ├── quality/                           # Phân hệ 7: Harvest, Product Batches, QC, Snapshots, Labels
    ├── hr/                                # Phân hệ 8: Employees, Shifts, Attendance GPS, Leaves, Tasks
    ├── finance/                           # Phân hệ 9: Expenses, Allocations, Sales, Debt, Payments, Budgets
    └── notification/                      # Phân hệ 10: In-app Notifications & WebSocket Alerts
```

### 2.1. Cấu Trúc Nội Bộ Chuẩn Hóa Cho Mỗi Module Nghiệp Vụ
Mỗi package con trong `modules/` (ví dụ `modules/inventory`) bắt buộc tuân theo kiến trúc thư mục con đồng nhất:
*   `controller/`: Chứa các Spring REST Controllers (nhận DTO, kiểm tra `@PreAuthorize`).
*   `dto/request/`: Các Request DTO kèm Jakarta Validation annotations.
*   `dto/response/`: Các Response DTO giàu thông tin hiển thị (Pre-joined labels).
*   `entity/`: Các JPA Entity tương ứng với các bảng trong `V1_0__init_system_core.sql`.
*   `repository/`: Spring Data JPA Repositories.
*   `service/`: Interface định nghĩa các hợp đồng nghiệp vụ.
*   `service/impl/`: Lớp cài đặt cụ thể logic nghiệp vụ và giao dịch `@Transactional`.
*   `mapper/`: Interface MapStruct để chuyển đổi giữa Entity và DTO.
*   `event/`: Các Domain Event phục vụ xử lý bất đồng bộ sau giao dịch.

### 2.2. Chiến Lược Xử Lý Ngoại Lệ Tập Trung (Global Exception Strategy)
Toàn bộ Controller đều được bao bọc bởi `GlobalExceptionHandler` (`@RestControllerAdvice`). Hệ thống chuẩn hóa định dạng trả về thống nhất theo lớp `ApiErrorResponse`:

```java
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ApiErrorResponse> handleBusinessException(BusinessException ex, HttpServletRequest request) {
        ApiErrorResponse error = ApiErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.BAD_REQUEST.value())
            .error("Bad Request")
            .errorCode(ex.getErrorCode())
            .message(ex.getMessage())
            .path(request.getRequestURI())
            .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiErrorResponse> handleValidationException(MethodArgumentNotValidException ex, HttpServletRequest request) {
        Map<String, String> fieldErrors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(err -> 
            fieldErrors.put(err.getField(), err.getDefaultMessage()));

        ApiErrorResponse error = ApiErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.BAD_REQUEST.value())
            .error("Validation Error")
            .errorCode("INVALID_INPUT_DATA")
            .message("Dữ liệu đầu vào không hợp lệ")
            .fieldErrors(fieldErrors)
            .path(request.getRequestURI())
            .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiErrorResponse> handleAccessDenied(AccessDeniedException ex, HttpServletRequest request) {
        ApiErrorResponse error = ApiErrorResponse.builder()
            .timestamp(Instant.now())
            .status(HttpStatus.FORBIDDEN.value())
            .error("Forbidden")
            .errorCode("ACCESS_DENIED")
            .message("Bạn không có quyền thực hiện thao tác này hoặc không thuộc phạm vi trang trại cho phép")
            .path(request.getRequestURI())
            .build();
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(error);
    }
}
```

### 2.3. Chiến Lược Xử Lý Bất Đồng Bộ Phía Sau Giao Dịch (Event-Driven Transaction Listeners)
Các tác vụ phụ như ghi chép nhật ký kiểm toán bất biến (`audit_logs` #10) và phát thông báo (`notifications` #71) **TUYỆT ĐỐI KHÔNG ĐƯỢC LÀM CHẬM HOẶC GÂY ROLLBACK GIAO DỊCH CHÍNH**.

Hệ thống áp dụng cơ chế bắn sự kiện Spring Event và chỉ lắng nghe **SAU KHI GIAO DỊCH ĐÃ COMMIT THÀNH CÔNG VÀO DATABASE**:

```java
@Component
@RequiredArgsConstructor
public class AuditLogEventListener {

    private final AuditLogRepository auditLogRepository;

    @Async("auditTaskExecutor")
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleAuditTrailEvent(AuditTrailEvent event) {
        // Chạy trên thread pool riêng biệt, không ảnh hưởng đến thread chính
        AuditLog log = AuditLog.builder()
            .tenantId(event.getTenantId())
            .userId(event.getUserId())
            .action(event.getAction())
            .module(event.getModule())
            .endpoint(event.getEndpoint())
            .method(event.getMethod())
            .ipAddress(event.getIpAddress())
            .userAgent(event.getUserAgent())
            .statusCode(event.getStatusCode())
            .executionTimeMs(event.getExecutionTimeMs())
            .traceId(event.getTraceId())
            .oldValue(event.getOldValue())
            .newValue(event.getNewValue())
            .build();
        auditLogRepository.save(log);
    }
}
```

---

## 3. CẤU TRÚC THƯ MỤC FRONTEND REACT VITE CHUẨN

Mã nguồn Frontend (`frontend/src/...`) được tái thiết lập theo mô hình **Shell-Workspace Architecture**, phản ánh chính xác 4 Application Shells và 9 Workspaces tác nghiệp:

```
frontend/src/
├── app/                                   # Bộ Khung Điều Hướng & Bảo Vệ Router
│   ├── routes.jsx                         # Cây định tuyến Router v6 (BrowserRouter)
│   └── guards/                            # Các Chốt Chặn Kiểm Soát Quyền
│       ├── AuthGuard.jsx                  # Kiểm tra Access Token, chuyển hướng /login
│       ├── MustChangePasswordGuard.jsx    # Bắt buộc đổi mật khẩu lần đầu
│       ├── RoleScopeGuard.jsx             # Kiểm tra Scope (SYSTEM vs TENANT vs FARM)
│       └── PermissionGuard.jsx            # Kiểm tra cụ thể mã quyền PERM_*
│
├── shells/                                # 4 Application Shells Độc Lập
│   ├── AuthShell/                         # Shell Xác Thực (Tập trung, tối giản, không Sidebar)
│   ├── PlatformShell/                     # Shell Quản Trị Khách Thuê (Dành cho Super Admin)
│   ├── TenantAppShell/                    # Shell Nghiệp Vụ Chính (Header chọn Farm + Sidebar 9 Ws)
│   └── PublicTraceShell/                  # Shell Tra Cứu QR Nguồn Gốc (Không cần Login, Mobile-First)
│
├── workspaces/                            # 9 Bàn Làm Việc Nghiệp Vụ Chuyên Biệt
│   ├── A_Geography/                       # Workspace A: Mặt bằng & Phân công
│   ├── B_Personnel360/                    # Workspace B: Hồ sơ Nhân sự 360° & Tài khoản SaaS
│   ├── C_InventoryHub/                    # Workspace C: Trung tâm Giao dịch Kho & Quét Mã vạch
│   ├── D_Partners/                        # Workspace D: Sổ Danh bạ Đối tác & VietQR
│   ├── E_FarmingOps/                      # Workspace E: Bàn làm việc Canh tác & Chăn nuôi
│   ├── F_QaTraceability/                  # Workspace F: Đường ống QA & Truy xuất QR
│   ├── G_EmployeeDailyOps/                # Workspace G: Cổng Nhân viên & Chấm công GPS/Selfie
│   ├── H1_CostAccounting/                 # Workspace H1: Giá thành, Phân bổ Chi phí & Ngân sách
│   └── H2_SalesCashflow/                  # Workspace H2: Bán sỉ, Giao hàng, Công nợ & VietQR
│
├── pages/                                 # Các Trang Chức Năng Bổ Trợ
│   ├── settings/                          # Cài đặt Danh mục tĩnh 7 Tabs
│   ├── reports/                           # Trung tâm 5 Báo cáo điều hành chuyên sâu
│   ├── system/                            # Quản trị Hệ thống & Tra cứu Audit Logs
│   ├── platform/                          # Quản lý khách thuê SaaS (Super Admin)
│   └── public/                            # Trang hiển thị dữ liệu truy xuất QR
│
├── components/                            # Thư Viện Thành Phần Dùng Chung
│   ├── ui/                                # UI Primitives (Button, Modal, Input, Badge, Dropdown)
│   ├── common/                            # Thành Phần Nghiệp Vụ Đặc Thù
│   │   ├── Can.jsx                        # Thẻ phân quyền giao diện <Can permission="...">
│   │   ├── SlideOverDrawer.jsx            # Drawer trượt từ cạnh phải cho Form nhập liệu
│   │   ├── DataTable.jsx                  # Bảng dữ liệu phân trang, lọc cột, sort server-side
│   │   ├── BarcodeScannerInput.jsx        # Ô quét mã vạch tự động (Laser / Camera)
│   │   ├── SelfieCameraModal.jsx          # Khung chụp ảnh Camera trước xác thực GPS
│   │   └── VietQRModal.jsx                # Hộp thoại sinh mã QR thanh toán NAPAS 24/7
│   └── layout/                            # Header, Sidebar, FarmContextSwitcher, Breadcrumbs
│
├── services/                              # Tầng Kết Nối API & Quản Lý Dữ Liệu
│   ├── api/                               # Cấu hình Axios & Request Interceptors
│   │   ├── apiClient.js                   # Axios Instance kèm cơ chế Silent Refresh Token
│   │   └── endpoints.js                   # Danh mục toàn bộ URI API hệ thống
│   └── modules/                           # Dịch vụ gọi API theo từng phân hệ
│
└── store/                                 # Quản Lý Trạng Thái Toàn Cục (Zustand Stores)
    ├── useAuthStore.js                    # Lưu Access Token in-memory, User Info, Permissions
    ├── useActiveFarmStore.js              # Lưu Trang trại, Phân khu, Chu kỳ đang làm việc
    └── useNotificationStore.js            # Lưu trữ và đếm số thông báo chưa đọc
```

---

## 4. CÁC QUYẾT ĐỊNH KIẾN TRÚC TRỌNG YẾU (ARCHITECTURE DECISION RECORDS - ADRs)

Bộ quyết định kiến trúc này là lời giải thích chính thức cho các giải pháp kỹ thuật được triển khai trong hệ sinh thái Farm Management:

```mermaid
graph LR
    subgraph "6 KIẾN TRÚC QUYẾT ĐỊNH CỐT LÕI (ADR 01 -> 06)"
        ADR1["ADR-01: Composite Foreign Keys<br/>The Farm Barrier Guard"]
        ADR2["ADR-02: Access Token In-Memory<br/>+ HttpOnly Refresh Token"]
        ADR3["ADR-03: Pessimistic Locking<br/>Bảo vệ Tồn kho & Công nợ"]
        ADR4["ADR-04: JSON Immutable Snapshots<br/>Đóng băng dữ liệu QR Code"]
        ADR5["ADR-05: AFTER_COMMIT Events<br/>Audit Logs & Notifications"]
        ADR6["ADR-06: Modular Monolith<br/>Toàn vẹn ACID Phase 1"]
    end
```

### ADR-01: Composite Foreign Keys Làm Hàng Rào Chắn Đa Trang Trại (The Farm Barrier Guard)
*   **Bối cảnh:** Trong môi trường Farm SaaS, một Tenant sở hữu nhiều Farm. Nếu chỉ sử dụng khóa ngoại đơn `farm_id`, một lập trình viên bất cẩn có thể viết câu lệnh SQL nối bảng nhầm lẫn giữa Zone của Farm A với Kho của Farm B.
*   **Quyết định:** Áp dụng khóa ngoại tổ hợp `(tenant_id, farm_id)` trên toàn bộ các bảng cấp Farm (như `production_zones`, `warehouses`, `crop_seasons`, `product_batches`).
*   **Hệ quả:** Cơ sở dữ liệu MySQL sẽ từ chối ở cấp độ DDL (Database Engine Level) bất kỳ hành động ghi chép dữ liệu nào có `farm_id` không thuộc đúng `tenant_id` của bản ghi cha. Bảo vệ tuyệt đối ranh giới dữ liệu mà không phụ thuộc hoàn toàn vào code ứng dụng.

### ADR-02: Access Token In-Memory & HttpOnly Cookie Cho Refresh Token
*   **Bối cảnh:** Lưu trữ Access Token trong `localStorage` hoặc `sessionStorage` rất dễ bị tin tặc đánh cắp thông qua các cuộc tấn công XSS (Cross-Site Scripting).
*   **Quyết định:**
    *   **Access Token (JWT):** Chỉ được lưu trữ tạm thời trong biến bộ nhớ (In-Memory State của Zustand). Khi người dùng F5 hoặc mở tab mới, Access Token sẽ được cấp lại thông qua cơ chế Silent Refresh.
    *   **Refresh Token:** Bắt buộc lưu trữ trong `HttpOnly`, `Secure`, `SameSite=Strict` Cookie do trình duyệt quản lý. Mã JavaScript phía Client hoàn toàn không thể đọc được Cookie này.
    *   **Token Rotation:** Mỗi khi gọi API `/api/v1/auth/refresh`, Refresh Token cũ sẽ bị vô hiệu hóa ngay trong bảng `refresh_tokens` (#72) và thay bằng một Refresh Token mới.

### ADR-03: Khóa Bi Quan (`PESSIMISTIC_WRITE`) Cho Tồn Kho Và Hạn Mức Công Nợ
*   **Bối cảnh:** Trong môi trường sản xuất nhiều công nhân cùng xuất kho vật tư hoặc nhiều nhân viên bán hàng cùng chốt đơn giữ chỗ một lô hàng, xung đột đồng thời (Race Condition) có thể dẫn tới tồn kho bị âm (`quantity_on_hand < 0`) hoặc vượt hạn mức tín dụng khách hàng.
*   **Quyết định:** Áp dụng Khóa Bi Quan `SELECT ... FOR UPDATE` (thông qua `@Lock(LockModeType.PESSIMISTIC_WRITE)` của JPA) khi:
    1.  Cập nhật số lượng tồn kho `warehouse_inventory` (#31).
    2.  Giữ chỗ hoặc xuất bán lô thành phẩm `product_batches` (#44).
    3.  Cập nhật số dư công nợ của đối tác trong `debt_records` (#66).
*   **Hệ quả:** Đảm bảo tính tuần tự hóa tuyệt đối của các giao dịch vật tư và tiền tệ, triệt tiêu hoàn toàn rủi ro tồn kho ảo.

### ADR-04: Bản Chụp JSON Bất Biến Cho Dữ Liệu Truy Xuất Nguồn Gốc (Immutable Traceability Snapshots)
*   **Bối cảnh:** Khi người tiêu dùng quét mã QR trên bao bì nông sản sau 6 tháng, các bảng như `farming_logs`, `harvest_records`, thông tin nông trại có thể đã bị chỉnh sửa hoặc mùa vụ đã đóng. Nếu truy vấn động trực tiếp từ các bảng nguồn, thông tin truy xuất có thể bị sai lệch so với thời điểm đóng gói thực tế.
*   **Quyết định:** Ngay tại thời điểm Quản lý phê duyệt KCS (`product_batches.status = 'READY_TO_PRINT'`), hệ thống trích xuất toàn bộ dữ liệu nhật ký, phân bón, chứng nhận VietGAP thành một tài liệu JSON duy nhất và lưu vào bảng `traceability_snapshots` (#49) kèm mã băm SHA-256 (`snapshot_hash`).
*   **Hệ quả:** Cổng truy xuất công khai (`/api/v1/public/traceability/{code}`) chỉ đọc từ bản chụp đóng băng này. Dữ liệu vĩnh viễn không bị thay đổi, tốc độ phản hồi cực nhanh (< 50ms) và bảo vệ được cơ sở dữ liệu nội bộ không bị quá tải khi lượng quét QR tăng đột biến.

### ADR-05: Cơ Chế Bắn Sự Kiện Sau Giao Dịch (`TransactionPhase.AFTER_COMMIT`) Cho Audit & Notification
*   **Bối cảnh:** Ghi nhật ký kiểm toán (`audit_logs`) và gửi thông báo (`notifications`) là các thao tác phụ. Nếu đặt chung trong cùng transaction với nghiệp vụ chính, một lỗi nhỏ khi ghi log có thể khiến toàn bộ giao dịch xuất kho hoặc bán hàng bị rollback oan uổng.
*   **Quyết định:** Sử dụng Spring `@TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)` kết hợp `@Async`.
*   **Hệ quả:** Các tác vụ phụ chạy độc lập trên thread pool nền sau khi dữ liệu chính đã được ghi nhận an toàn xuống ổ đĩa, đảm bảo hiệu năng cao nhất cho người dùng.

### ADR-06: Lựa Chọn Modular Monolith Thay Vì Microservices Trong Giai Đoạn 1
*   **Bối cảnh:** Dự án cần đảm bảo tính toàn vẹn nghiệp vụ liên chuỗi (từ Gieo trồng $\rightarrow$ Thu hoạch $\rightarrow$ KCS $\rightarrow$ Kho $\rightarrow$ Bán sỉ $\rightarrow$ Giá thành $\rightarrow$ Công nợ).
*   **Quyết định:** Phát triển hệ thống dưới dạng **Modular Monolith** trên nền Spring Boot và MySQL duy nhất. Các module được phân tách ranh giới rõ ràng thông qua cấu trúc package và Domain Events.
*   **Hệ quả:** Cho phép hệ thống thực thi các transaction phức tạp trong một kết nối JDBC duy nhất, dễ dàng kiểm thử tích hợp (Integration Test), đơn giản hóa việc triển khai (chỉ cần 1 container Docker backend) và sẵn sàng tách thành Microservices độc lập trong tương lai nếu quy mô mở rộng yêu cầu.

---

*Văn kiện `SPEC-ARCH-011` là bản vẽ thiết kế kiến trúc chuẩn mực, toàn bộ mã nguồn Backend Spring Boot và Frontend React phải tuân thủ nghiêm ngặt theo các cấu trúc package, luồng dữ liệu và quyết định ADR đã được phê duyệt.*
