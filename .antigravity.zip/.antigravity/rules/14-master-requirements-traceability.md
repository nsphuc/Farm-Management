# MA TRẬN TRUY VẾT YÊU CẦU ĐẾN TRIỂN KHAI & KIỂM THỬ
## (MASTER REQUIREMENTS TRACEABILITY MATRIX - RTM)

> **Mã văn kiện:** `SPEC-TRACE-014`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Là Bản Đồ Kiểm Toán Khép Kín Xuyên Suốt Từ Yêu Cầu Đến Database, API, UI Và Test Cases.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Tôn chỉ:** *"Không yêu cầu mồ côi (Zero Orphan Requirements) - Không bảng thừa vô thừa nhận (Zero Unclaimed Tables) - Truy vết khép kín 100%"*.

---

## 1. QUY CHUẨN MÃ ĐỊNH DANH TRUY VẾT HỆ THỐNG

Để đảm bảo tính nhất quán tuyệt đối giữa các kỹ sư phân tích nghiệp vụ, lập trình viên Backend, Frontend và chuyên viên kiểm thử QA, hệ thống thiết lập bảng tiền tố định danh bất biến sau:

```mermaid
graph LR
    subgraph "CHUỖI TRUY VẾT KHÉP KÍN 8 BƯỚC (END-TO-END TRACEABILITY)"
        FR["Yêu Cầu Chức Năng<br/>FR-[MODULE]-[00X]"]
        SPEC["Quy Tắc Miền<br/>File 01 -> 03"]
        RBAC["Quyền Hạn RBAC<br/>PERM_* (File 04)"]
        UI["Màn Hình & Nút Bấm<br/>UI-[WS]-[00X] (08, 09)"]
        API["Hợp Đồng API<br/>API-[MODULE]-[00X] (07)"]
        DB["Lược Đồ SQL<br/>Bảng #1 -> #72 (V1_0)"]
        TC["Kịch Bản Nghiệm Thu<br/>TC-[MODULE]-[00X] (13)"]
    end

    FR --> SPEC --> RBAC --> UI --> API --> DB --> TC
```

| Tiền Tố Mã | Khái Niệm Thực Thể Đại Diện | Nguồn Quy Chiếu Thẩm Quyền | Ví Dụ Điển Hình |
| :---: | :--- | :--- | :--- |
| **`FR-*`** | Functional Requirement (Yêu cầu nghiệp vụ chức năng) | Sơ đồ phân cấp tính năng Module 1.1 $\rightarrow$ 7.7 | `FR-CROP-001`, `FR-INV-002`, `FR-FIN-003` |
| **`UI-*`** | User Interface Screen / Component (Màn hình & Giao diện) | File [`08-master-ui-workspace-flows.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/08-master-ui-workspace-flows.md) & [`09`](file:///d:/Projects/Farm_Management/.antigravity/rules/09-master-screen-action-specs.md) | `UI-WS-E-FARMING`, `UI-MODAL-RECEIPT` |
| **`API-*`**| REST Endpoint & DTO Contract (Điểm cuối giao tiếp) | File [`07-master-api-dto-contracts.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/07-master-api-dto-contracts.md) | `API-CROP-POST-LOGS`, `API-INV-GET-STOCK` |
| **`PERM_*`**| Permission Code (Mã thẩm quyền kiểm soát truy cập) | File [`04-master-roles-permissions.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/04-master-roles-permissions.md) | `PERM_CROP_LOG`, `PERM_QC_APPROVE` |
| **`TC-*`** | Master Acceptance Test Case (Kịch bản kiểm thử nghiệm thu) | File [`13-master-test-strategy-acceptance.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/13-master-test-strategy-acceptance.md) | `TC-CROP-001`, `TC-SEC-003`, `TC-CONC-001` |
| **`TABLE-*`**| MySQL Table Entity (Bảng dữ liệu vật lý lõi) | File [`V1_0__init_system_core.sql`](file:///d:/Projects/Farm_Management/backend/src/main/resources/db/migration/V1_0__init_system_core.sql) & [`15`](file:///d:/Projects/Farm_Management/.antigravity/rules/15-master-data-dictionary-erd.md) | `farming_logs` (#20), `warehouse_inventory` (#31) |

---

## 2. BẢNG MA TRẬN TRUY VẾT TOÀN DIỆN (FULL TRACEABILITY MATRIX - RTM)

Bảng đối soát chuỗi giá trị khép kín từ sơ đồ chức năng Module 1.1 $\rightarrow$ 7.7, đối chiếu trực tiếp với toàn bộ 72 bảng cơ sở dữ liệu:

| Mã Yêu Cầu | Chức Năng Nghiệp Vụ (Module 1.1 -> 7.7) | Quy Tắc Miền (File) | Mã Quyền RBAC (`permissions.code`) | Màn Hình / Workspace (File 08, 09) | Hợp Đồng Endpoint REST API (File 07) | Bảng SQL Ánh Xạ (V1_0__init_system_core.sql) | Mã Kịch Bản Test Case (File 13) | Trạng Thái Đặc Tả |
| :---: | :--- | :---: | :--- | :--- | :--- | :--- | :---: | :---: |
| **`FR-ORG-001`** | 1.1 Quản trị khách thuê & Gói dịch vụ SaaS | File 01 (Mục 9) | `PERM_TENANT_MANAGE` | Platform Shell (`/platform/tenants`) | `POST/GET /api/v1/platform/tenants` | `tenants` (#1), `tenant_subscriptions` (#2) | `TC-SEC-001` | **SPEC_APPROVED** |
| **`FR-ORG-002`** | 1.1 Hồ sơ pháp nhân & Định danh VietQR | File 01 (Mục 8) | `PERM_FARM_UPDATE` (hoặc `PERM_FARM_VIEW` / `PERM_FARM_UPDATE` dành cho `ROLE_FARM_OWNER`, `ROLE_ACCOUNTANT`) | Settings (`/app/settings?tab=enterprise`)| `GET/PUT /api/v1/enterprise/profile` | `enterprises` (#3) | `TC-FIN-003` | **SPEC_APPROVED** |
| **`FR-GEO-001`** | 1.2 Khởi tạo trang trại, tâm GPS & Geofence | File 01 (Mục 1, 6)| `PERM_FARM_CREATE`, `PERM_FARM_UPDATE` | Workspace A (`/app/geography`) | `POST/PUT /api/v1/farms` | `farms` (#11), `farm_operational_settings` (#17) | `TC-HR-001` | **SPEC_APPROVED** |
| **`FR-GEO-002`** | 1.3 Phân khu sản xuất & Lô đất / Chuồng trại | File 01 (Mục 1) | `PERM_ZONE_MANAGE`, `PERM_FARM_VIEW` | Workspace A (`/app/geography`) | `POST/GET /api/v1/farms/{id}/zones` | `production_zones` (#13), `zone_locations` (#14) | `TC-SEC-002` | **SPEC_APPROVED** |
| **`FR-GEO-003`** | 1.4 Phân công quản lý trang trại hiện trường | File 01 (Mục 1) | `PERM_ZONE_MANAGE` | Workspace A (`/app/geography`) | `POST /api/v1/farms/{id}/assignments` | `farm_assignments` (#15), `user_farm_access` (#12) | `TC-SEC-002` | **SPEC_APPROVED** |
| **`FR-GEO-004`** | 1.5 Chu kỳ sản xuất & Niên độ tài chính | File 01 (Mục 1) | `PERM_FARM_UPDATE` | Settings (`/app/settings?tab=cycles`) | `POST/GET /api/v1/farms/{id}/cycles` | `operational_cycles` (#16) | `TC-FIN-004` | **SPEC_APPROVED** |
| **`FR-CRM-001`** | 1.6 Sổ danh bạ Đối tác & Hạn mức tín dụng | File 01 (Mục 8) | `PERM_FINANCE_SALES_ORDER` | Workspace D (`/app/partners`) | `POST/GET /api/v1/partners` | `partners` (#4) | `TC-FIN-001` | **SPEC_APPROVED** |
| **`FR-CROP-001`**| 2.1.1 Kế hoạch gieo trồng & Mở vụ mùa | File 01 (Mục 2) | `PERM_CROP_PLAN` | Workspace E (`/app/farming`) | `POST/GET /api/v1/farms/{id}/crop-seasons` | `crop_types` (#18), `crop_seasons` (#19) | `TC-CROP-001` | **SPEC_APPROVED** |
| **`FR-CROP-002`**| 2.1.2 Nhật ký canh tác & Trừ kho tự động | File 01 (Mục 2), 06| `PERM_CROP_LOG` | Workspace E (`/app/farming`) Drawer | `POST /api/v1/farms/{id}/farming-logs` | `farming_logs` (#20), `farming_log_supplies` (#41), `warehouse_issues` (#34) | `TC-CROP-001`, `TC-CONC-001` | **SPEC_APPROVED** |
| **`FR-CROP-003`**| 2.1.5 Thu hoạch nông sản & Chốt chặn PHI | File 01 (Mục 4) | `PERM_HARVEST_MANAGE` | Workspace E (`/app/farming`) Modal | `POST /api/v1/farms/{id}/harvest-records` | `harvest_records` (#43) | `TC-CROP-002` | **SPEC_APPROVED** |
| **`FR-LIVE-001`**| 2.2.1 Quản lý đàn, lứa nuôi & Mã thẻ tai | File 01 (Mục 1) | `PERM_LIVESTOCK_MANAGE` | Workspace E (`/app/farming`) Sector Live | `POST/GET /api/v1/farms/{id}/livestock-groups`| `livestock_breeds` (#21), `livestock_groups` (#22), `livestock_individuals` (#23) | `TC-LIVE-001` | **SPEC_APPROVED** |
| **`FR-LIVE-002`**| 2.2.3 Cân tăng trọng đàn & Đồ thị ADG | File 01 (Mục 1) | `PERM_LIVESTOCK_MANAGE` | Workspace E (`/app/farming`) | `POST /api/v1/farms/{id}/livestock-groups/{id}/weigh-in` | `livestock_weight_logs` (#24) | `TC-LIVE-001` | **SPEC_APPROVED** |
| **`FR-LIVE-003`**| 2.2.5 Sự kiện thú y, tiêm phòng & Trừ kho cám/thuốc | File 01 (Mục 4), 06| `PERM_LIVESTOCK_VET` | Workspace E (`/app/farming`) | `POST /api/v1/farms/{id}/livestock-groups/{id}/events` | `livestock_events` (#25), `livestock_event_supplies` (#42), `warehouse_issues` (#34) | `TC-CROP-001` | **SPEC_APPROVED** |
| **`FR-INV-001`** | 3.1 Khai báo kho & Phân loại kho lưu trữ | File 01 (Mục 3) | `PERM_INVENTORY_VIEW` | Settings (`/app/settings?tab=warehouses`) | `POST/GET /api/v1/farms/{id}/warehouses` | `warehouses` (#26) | `TC-INV-001` | **SPEC_APPROVED** |
| **`FR-INV-002`** | 3.2 Danh mục vật tư, mã vạch & Quy cách bao bì| File 01 (Mục 3) | `PERM_INVENTORY_VIEW` | Settings (`/app/settings?tab=materials`) | `POST/GET /api/v1/materials` | `material_categories` (#27), `materials` (#28), `material_unit_conversions` (#29) | `TC-INV-002` | **SPEC_APPROVED** |
| **`FR-INV-003`** | 3.3 Nhập kho mua hàng & Sinh công nợ phải trả | File 01 (Mục 3), 06| `PERM_INVENTORY_RECEIPT` | Workspace C (`/app/inventory/receipts`) | `POST /api/v1/farms/{id}/inventory/receipts` | `warehouse_receipts` (#32), `warehouse_receipt_items` (#33), `debt_records` (#66) | `TC-INV-001` | **SPEC_APPROVED** |
| **`FR-INV-004`** | 3.4 Xuất kho vật tư & Quản trị tồn kho tức thời | File 01 (Mục 3), 06| `PERM_INVENTORY_ISSUE` | Workspace C (`/app/inventory/issues`) | `POST /api/v1/farms/{id}/inventory/issues` | `warehouse_issues` (#34), `warehouse_issue_items` (#35), `warehouse_inventory` (#31) | `TC-CONC-001` | **SPEC_APPROVED** |
| **`FR-INV-005`** | 3.5 Điều chuyển hàng nội bộ liên kho / liên trại | File 01 (Mục 3) | `PERM_INVENTORY_TRANSFER`| Workspace C (`/app/inventory/transfers`) | `POST /api/v1/farms/{id}/inventory/transfers` | `warehouse_transfers` (#36), `warehouse_transfer_items` (#37) | `TC-INV-001` | **SPEC_APPROVED** |
| **`FR-INV-006`** | 3.6 Thẻ kho lịch sử biến động (Sổ cái bất biến) | File 01 (Mục 3) | `PERM_INVENTORY_VIEW` | Workspace C (`/app/inventory/transactions`)| `GET /api/v1/farms/{id}/inventory/transactions`| `warehouse_inventory_transactions` (#38) | `TC-INV-001` | **SPEC_APPROVED** |
| **`FR-INV-007`** | 3.7 Kiểm kê kho & Cân bằng thẻ kho tự động | File 01 (Mục 3) | `PERM_INVENTORY_STOCKTAKE`| Workspace C (`/app/inventory/stocktakes`) | `POST /api/v1/farms/{id}/inventory/stocktakes` | `stocktakes` (#39), `stocktake_items` (#40) | `TC-INV-001` | **SPEC_APPROVED** |
| **`FR-INV-008`** | 3.8 Định mức tiêu hao tiêu chuẩn (BOM Quotas) | File 01 (Mục 3) | `PERM_CROP_PLAN` | Settings (`/app/settings?tab=quotas`) | `POST/GET /api/v1/quotas` | `consumption_quotas` (#30) | `TC-CROP-001` | **SPEC_APPROVED** |
| **`FR-QA-001`**  | 3.9 Đóng gói Lô thành phẩm & Quản lý tồn lô | File 01 (Mục 5) | `PERM_HARVEST_MANAGE` | Workspace F (`/app/qa/batches`) | `POST/GET /api/v1/farms/{id}/product-batches` | `product_batches` (#44), `product_batch_sources` (#45), `product_batch_transactions` (#48) | `TC-QA-001`, `TC-FIN-001`| **SPEC_APPROVED** |
| **`FR-QA-002`**  | 3.10 Biên bản kiểm định KCS (Maker-Checker Guard)| File 01 (Mục 5), 04| `PERM_QC_INSPECT`, `PERM_QC_APPROVE` | Workspace F (`/app/qa/batches`) Modal | `POST /api/v1/farms/{id}/qc-inspections` | `qc_inspections` (#46), `qc_inspection_items` (#47) | `TC-SEC-003` | **SPEC_APPROVED** |
| **`FR-QA-003`**  | 3.11 Phê duyệt KCS, Đóng băng Snapshot & In tem | File 01 (Mục 5), 06| `PERM_QC_APPROVE`, `PERM_LABEL_PRINT` | Workspace F (`/app/qa/batches`) Modal In | `POST /api/v1/farms/{id}/product-batches/{id}/approve` | `traceability_snapshots` (#49), `label_print_logs` (#50) | `TC-QA-001` | **SPEC_APPROVED** |
| **`FR-QA-004`**  | 3.11 Lệnh thu hồi khẩn cấp lô thành phẩm | File 01 (Mục 5) | `PERM_QC_RECALL` | Workspace F (`/app/qa/batches`) Action | `POST /api/v1/farms/{id}/product-batches/{id}/recall` | `product_batches` (#44) | `TC-QA-002` | **SPEC_APPROVED** |
| **`FR-QA-005`**  | 3.12 Cổng tra cứu QR nguồn gốc nông sản công khai | File 01 (Mục 5), 07| `permitAll()` | PublicTraceShell (`/trace/:code`) | `GET /api/v1/public/traceability/{code}` | `traceability_snapshots` (#49) | `TC-QA-001` | **SPEC_APPROVED** |
| **`FR-HR-001`**  | 4.1 Hồ sơ nhân sự 360° & Quản lý phép năm | File 01 (Mục 6) | `PERM_HR_EMPLOYEE_MANAGE`| Workspace B (`/app/hr`) | `POST/GET /api/v1/hr/employees` | `employees` (#51) | `TC-HR-003` | **SPEC_APPROVED** |
| **`FR-HR-002`**  | 4.2 Giao nhiệm vụ hiện trường đa nhân sự | File 01 (Mục 6) | `PERM_TASK_ASSIGN` | Workspace G (`/app/my-dashboard`) Kanban | `POST/GET /api/v1/farms/{id}/tasks` | `farm_tasks` (#57), `farm_task_assignees` (#58) | `TC-HR-002` | **SPEC_APPROVED** |
| **`FR-HR-003`**  | 4.3 Chấm công 2 đầu GPS Geofence + Ảnh Selfie | File 01 (Mục 6) | `PERM_HR_ATTENDANCE` | Workspace G (`/app/my-dashboard`) Clock | `POST /api/v1/hr/attendance/check-in` | `time_attendances` (#54) | `TC-HR-001`, `TC-HR-002` | **SPEC_APPROVED** |
| **`FR-HR-004`**  | 4.4 Phân ca làm việc chuẩn & Lịch trực tuần | File 01 (Mục 6) | `PERM_HR_EMPLOYEE_MANAGE`| Settings & Workspace G Lịch ca | `POST/GET /api/v1/hr/shifts` | `work_shifts` (#52), `shift_assignments` (#53) | `TC-HR-002` | **SPEC_APPROVED** |
| **`FR-HR-005`**  | 4.5 Quản lý đơn xin nghỉ phép & Đăng ký OT | File 01 (Mục 6) | `PERM_HR_EMPLOYEE_MANAGE`| Workspace G (`/app/my-dashboard`) Drawer | `POST/PUT /api/v1/hr/leaves` | `leave_requests` (#55), `overtime_requests` (#56) | `TC-HR-003` | **SPEC_APPROVED** |
| **`FR-HR-006`**  | 4.6 Tổng hợp công & Điều chỉnh công có kiểm toán | File 01 (Mục 6) | `PERM_HR_EMPLOYEE_MANAGE`| Workspace B (`/app/hr?tab=attendance`) | `PUT /api/v1/hr/attendance/{id}/adjust` | `time_attendances` (#54) | `TC-HR-002` | **SPEC_APPROVED** |
| **`FR-FIN-001`** | 5.1 Tập hợp 4 nguồn chi phí sản xuất nông nghiệp | File 01 (Mục 7) | `PERM_FINANCE_EXPENSE` | Workspace H1 (`/app/cost-accounting`) Left | `POST/GET /api/v1/farms/{id}/expenses` | `cost_categories` (#59), `farm_expenses` (#60) | `TC-FIN-004` | **SPEC_APPROVED** |
| **`FR-FIN-002`** | 5.2 Bàn phân bổ chi phí chung vào Mùa vụ/Đàn/Khu | File 01 (Mục 7) | `PERM_FINANCE_EXPENSE` | Workspace H1 Right Allocation Pane | `POST /api/v1/farms/{id}/expenses/{id}/allocate` | `cost_allocations` (#61) | `TC-FIN-004` | **SPEC_APPROVED** |
| **`FR-FIN-003`** | 5.3 Đơn bán sỉ B2B & Cơ chế giữ chỗ lô thành phẩm | File 01 (Mục 8), 06| `PERM_FINANCE_SALES_ORDER`| Workspace H2 (`/app/commercial/sales`) | `POST /api/v1/farms/{id}/sales-orders` | `sales_orders` (#62), `sales_order_items` (#63), `product_batches` (#44) | `TC-FIN-001` | **SPEC_APPROVED** |
| **`FR-FIN-004`** | 5.3 Giao hàng nhiều đợt & Chụp biên bản POD | File 01 (Mục 8), 06| `PERM_DELIVERY_MANAGE` | Workspace H2 (`/app/commercial/deliveries`)| `POST /api/v1/farms/{id}/sales-deliveries` | `sales_deliveries` (#64), `sales_delivery_items` (#65) | `TC-FIN-002` | **SPEC_APPROVED** |
| **`FR-FIN-005`** | 5.4 Tính giá thành đơn vị thực tế (Unit Cost/kg) | File 01 (Mục 7) | `PERM_FINANCE_REPORT` | Workspace H1 (`/app/cost-accounting`) Tab 3| `GET /api/v1/farms/{id}/costing/unit-cost` | `farm_expenses` (#60), `harvest_records` (#43), `cost_allocations` (#61) | `TC-FIN-004` | **SPEC_APPROVED** |
| **`FR-FIN-006`** | 5.5 Sổ theo dõi công nợ 2 chiều & Tuổi nợ | File 01 (Mục 8) | `PERM_FINANCE_PAYMENT` | Workspace H2 (`/app/commercial/debt`) | `GET /api/v1/farms/{id}/debts` | `debt_records` (#66) | `TC-FIN-003` | **SPEC_APPROVED** |
| **`FR-FIN-007`** | 5.5 Thanh toán VietQR Napas247 & Cấn trừ nợ đại lý | File 01 (Mục 8), 06| `PERM_PAYMENT_ALLOCATE` | Workspace H2 Modal VietQR / Cấn trừ | `POST /api/v1/farms/{id}/payments` | `payment_transactions` (#67), `payment_allocations` (#68) | `TC-FIN-003`, `TC-CONC-002` | **SPEC_APPROVED** |
| **`FR-FIN-008`** | 5.6 Dự toán ngân sách & Kiểm soát vượt hạn mức | File 01 (Mục 7) | `PERM_FINANCE_EXPENSE` | Workspace H1 (`/app/cost-accounting?tab=budgets`)| `POST/GET /api/v1/farms/{id}/budgets` | `budgets` (#69), `budget_line_items` (#70) | `TC-FIN-004` | **SPEC_APPROVED** |
| **`FR-RPT-001`** | 6.1 Báo cáo điều hành Executive Dashboard | File 07 (Mục 4), 12| `PERM_FINANCE_REPORT` | Trung tâm Báo Cáo (`/app/reports?tab=kpi`) | `GET /api/v1/reports/executive-dashboard` | Đọc dữ liệu tổng hợp đa bảng | `TC-RPT-001` | **SPEC_APPROVED** |
| **`FR-RPT-002`** | 6.2 Báo cáo tuổi thọ kho & Cảnh báo hạn dùng FEFO | File 07 (Mục 4), 12| `PERM_INVENTORY_VIEW` | Trung tâm Báo Cáo (`/app/reports?tab=aging`)| `GET /api/v1/reports/inventory-aging` | `warehouse_inventory` (#31), `materials` (#28) | `TC-RPT-002` | **SPEC_APPROVED** |
| **`FR-RPT-003`** | 6.3 Báo cáo Giá thành & Lợi nhuận Vụ mùa (Crop P&L)| File 07 (Mục 4) | `PERM_FINANCE_REPORT` | Trung tâm Báo Cáo (`/app/reports?tab=pnl`) | `GET /api/v1/reports/crop-cost-profit` | `crop_seasons` (#19), `sales_order_items` (#63) | `TC-RPT-003` | **SPEC_APPROVED** |
| **`FR-RPT-004`** | 6.4 Báo cáo Chuyển đổi thức ăn FCR & Tăng trọng | File 07 (Mục 4) | `PERM_FINANCE_REPORT` | Trung tâm Báo Cáo (`/app/reports?tab=fcr`) | `GET /api/v1/reports/livestock-fcr` | `livestock_groups` (#22), `livestock_weight_logs` (#24)| `TC-RPT-004` | **SPEC_APPROVED** |
| **`FR-RPT-005`** | 6.5 Báo cáo Phân tích tuổi nợ khách hàng (Aging) | File 07 (Mục 4) | `PERM_FINANCE_REPORT` | Trung tâm Báo Cáo (`/app/reports?tab=debts`)| `GET /api/v1/reports/debt-aging` | `debt_records` (#66), `partners` (#4) | `TC-RPT-005` | **SPEC_APPROVED** |
| **`FR-SYS-001`** | 7.1 Cấp tài khoản SaaS liên kết 1-1 hồ sơ nhân sự| File 01 (Mục 6) | `PERM_HR_EMPLOYEE_MANAGE`| Workspace B (`/app/hr`) Drawer Cấp TK | `POST /api/v1/hr/employees/{id}/provision-account`| `users` (#5), `user_roles` (#8), `employees` (#51) | `TC-SEC-004` | **SPEC_APPROVED** |
| **`FR-SYS-002`** | 7.2 Quản lý phiên đăng nhập & Xoay vòng Refresh Token| File 05 (Mục 2), 07| `permitAll()` | AuthShell (`/login`, `/refresh`) | `POST /api/v1/auth/refresh` | `refresh_tokens` (#72) | `TC-SEC-004` | **SPEC_APPROVED** |
| **`FR-SYS-003`** | 7.3 Nhật ký kiểm toán bất biến & So sánh biến động| File 05 (Mục 4), 11| `PERM_TENANT_MANAGE` | Quản trị Hệ Thống (`/app/system?tab=audit`)| `GET /api/v1/system/audit-logs` | `audit_logs` (#10) | `TC-SEC-001` | **SPEC_APPROVED** |
| **`FR-SYS-004`** | 7.4 Trung tâm Thông báo đẩy & Cảnh báo tồn kho | File 01 (Mục 9) | `isAuthenticated()` | TopBar Notification Bell & Drawer | `GET/PUT /api/v1/notifications` | `notifications` (#71) | `TC-SYS-004` | **SPEC_APPROVED** |
| **`FR-SYS-005`** | 7.5 Quản trị Vai trò & Ma trận Phân quyền RBAC Hệ thống | File 04, 05, 07 | `PERM_TENANT_MANAGE` / `PERM_HR_EMPLOYEE_MANAGE` | Settings/System (`/app/settings?tab=roles`) | `GET /api/v1/system/roles`, `GET /api/v1/auth/me/permissions` | `roles` (#6), `permissions` (#7), `role_permissions` (#9) | `TC-SEC-004` | **SPEC_APPROVED** |

> [!NOTE]
> **Ghi Chú Về Việc Ánh Xạ Các Bảng Nội Bộ Hệ Thống (`roles` #6, `permissions` #7, `role_permissions` #9):**
> *   **Bản chất dữ liệu:** Đây là 3 bảng nền tảng kiểm soát truy cập theo vai trò (RBAC), được nạp dữ liệu tĩnh (Seed Data) trực tiếp từ migration `V1_0__init_system_core.sql` gồm 6 Vai trò hệ thống và 30 Quyền hạn chuẩn.
> *   **Lý do không phơi bày API CRUD trực tiếp:** Để ngăn chặn hoàn toàn nguy cơ leo thang đặc quyền (Privilege Escalation) và đảm bảo tính toàn vẹn bảo mật toàn hệ thống, người dùng và quản trị viên không được phép tự do tạo, sửa, xóa các quyền cốt lõi qua API CRUD công khai.
> *   **Cơ chế truy xuất & Use case nghiệp vụ:** Dữ liệu từ 3 bảng này được nạp vào bộ nhớ cache (`SecurityContext`, JWT Claims, Redis/Caffeine) khi người dùng đăng nhập; được truy vấn chỉ đọc qua `GET /api/v1/system/roles` (xem ma trận vai trò) và `GET /api/v1/auth/me/permissions` (lấy quyền người dùng cho frontend component `<Can>`); và được liên kết thực tế khi quản trị viên phân vai trò cho nhân sự qua bảng `user_roles` (#8) tại chức năng `FR-SYS-001`.

---

## 3. BẢNG KIỂM TOÁN ĐỘ BAO PHỦ & ĐỘ TRỄ TRIỂN KHAI (COVERAGE AUDIT SUMMARY)

### 3.1. Thống Kê Độ Bao Phủ 72 Bảng Database Phase 1

```mermaid
pie title ĐỘ BAO PHỦ ĐẶC TẢ TRÊN 72 BẢNG DDL
    "69 Bảng Nghiệp Vụ & Master Data (Đầy đủ CRUD/FSM/API)" : 69
    "3 Bảng RBAC Nội Bộ (Seed Data & Cached Security)" : 3
```

*   **Tổng số bảng DDL lõi đã ánh xạ:** **Đủ 72/72 bảng (Đạt tỷ lệ bao phủ thực tế 100.0%)**.
    *   **69 Bảng Nghiệp vụ / Giao dịch / Danh mục:** Đầy đủ hợp đồng API CRUD, màn hình UI, FSM, luật bảo mật The Farm Barrier Guard và kịch bản nghiệm thu tại các File `01`, `02`, `06`, `07`, `08`, `09`, `13`.
    *   **3 Bảng Bảo mật Nội bộ (`roles` #6, `permissions` #7, `role_permissions` #9):** Được quản lý qua hệ thống Seed Migration, phục vụ cơ chế xác thực phân quyền Spring Security `@PreAuthorize`, trích xuất quyền người dùng phục vụ UI `<Can>` và gán quyền nhân sự `user_roles` (#8).
*   **Độ bao phủ Hợp đồng API:** 100% các bảng đều có REST Endpoint tương ứng tại File `07` (Endpoint nghiệp vụ hoặc Endpoint trích xuất quyền bảo mật).
*   **Độ bao phủ Màn hình UI:** 100% các bảng đều được quy hoạch tại File `08` và `09`.
*   **Độ bao phủ Phân quyền RBAC:** 100% các thao tác đều được gán nhãn thẩm quyền trong 30 quyền tại File `04`.
*   **Độ bao phủ Kiểm thử Acceptance:** 100% các luồng giao dịch đều có kịch bản nghiệm thu tại File `13`.

### 3.2. Danh Mục Các Tính Năng Hoãn Lại Sang Phase 2 (`PHASE_2_DEFERRED`)
Để bảo vệ tiến độ và giữ vững kiến trúc Modular Monolith tinh gọn, các tính năng sau đây được chủ động xác định thuộc Phase 2 và **KHÔNG LÀM THAY ĐỔI LƯỢC ĐỒ 72 BẢNG HIỆN TẠI**:
1.  **Điều khiển phần cứng IoT tự động hai chiều qua MQTT:** (Hiện tại Phase 1 đã có bảng `farm_operational_settings` #17 lưu ngưỡng thông số tưới tiêu; việc tích hợp Gateway MQTT kích hoạt máy bơm phần cứng sẽ kích hoạt ở Phase 2).
2.  **Công cụ tính lương và trích nộp bảo hiểm xã hội chuyên sâu (Payroll Engine):** (Hiện tại Phase 1 đã có bảng tổng hợp công `time_attendances` #54 và chi phí phân bổ `farm_expenses` nguồn `PAYROLL_ALLOCATION`; thuật toán biểu thuế thu nhập cá nhân lũy tiến từng phần sẽ bổ sung ở Phase 2).
3.  **Sàn giao dịch thương mại điện tử bán lẻ B2C (Consumer Marketplace):** (Hệ thống tập trung 100% vào mô hình B2B quản trị nội bộ nông trại và bán sỉ thương lái).

---

*Văn kiện `SPEC-TRACE-014` khép lại toàn bộ bộ 16 văn kiện đặc tả hệ thống (`00` -> `15`), thiết lập chuỗi truy vết hoàn hảo 100% không góc khuất từ ý tưởng kinh doanh đến từng dòng code và cơ sở dữ liệu.*
