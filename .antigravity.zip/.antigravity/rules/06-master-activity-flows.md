# SƠ ĐỒ LUỒNG HOẠT ĐỘNG & GIAO DỊCH NGUYÊN TỬ AGRI-ERP
## (MASTER MULTI-TABLE TRANSACTIONAL FLOWS & ATOMIC CONCURRENCY SPECIFICATION)

> **Mã văn kiện:** `SPEC-FLOW-006`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Là Bản Thiết Kế Thuật Toán Giao Dịch Sống Còn Cho Toàn Bộ Backend Developers.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Tôn chỉ:** *"Tính trọn vẹn ACID (Atomicity, Consistency, Isolation, Durability) - Khóa bi quan chống Race Condition - Không bao giờ để dữ liệu lệch sổ sách"*.

---

## 1. TỔNG QUAN 9 LUỒNG GIAO DỊCH NGUYÊN TỬ CỐT LÕI

| STT | Luồng Giao Dịch Nghiệp Vụ | Điểm Kích Hoạt (API Endpoint) | Các Bảng SQL Cập Nhật Cùng Lúc (Atomic) | Cơ Chế Khóa Đồng Thời (Concurrency Lock) |
| :---: | :--- | :--- | :--- | :--- |
| **1** | **Cấp phát Tài khoản Nhân sự Phân cấp** (Hierarchical Provisioning) | `POST /api/v1/hr/employees/{id}/provision-account` | `employees` (#51), `users` (#5), `user_roles` (#8), `user_farm_access` (#12), `farm_assignments` | Hierarchical Recruitment Guard & Unique Constraint |
| **2** | **Hoàn tất Nhập kho Mua hàng** (Purchase Stock-in & Payable) | `POST /api/v1/farms/{farmId}/inventory/receipts/{id}/complete` | `warehouse_receipts` (#32), `warehouse_inventory` (#31), `warehouse_inventory_transactions` (#38), `debt_records` (#66), `partners` (#57) | Farm Barrier Guard & Pessimistic Write Lock trên Lô kho |
| **3** | **Tiêu hao Tự động Canh tác** (Atomic Auto-Backflushing) | `POST /api/v1/farms/{farmId}/farming-logs` hoặc `livestock-events` | `farming_logs` (#20), `farming_log_supplies` (#41), `warehouse_issues` (#34), `warehouse_issue_items` (#35), `warehouse_inventory` (#31), `warehouse_inventory_transactions` (#38), `farm_expenses` (#60) | `@Lock(PESSIMISTIC_WRITE)` trên tồn kho `warehouse_inventory` |
| **4** | **Thu hoạch & Đóng gói Thành phẩm** (Harvest to Finished Batch) | `POST /api/v1/farms/{farmId}/harvest-records` | `harvest_records` (#43), `crop_seasons` (#19) hoặc `livestock_groups` (#22), `product_batches` (#44), `product_batch_sources` (#45), `product_batch_transactions` (#48) | Pessimistic Lock trên Vụ mùa / Đàn nuôi |
| **5** | **Phê duyệt KCS & Đóng băng Truy xuất** (QC Approval & Freeze) | `POST /api/v1/farms/{farmId}/product-batches/{id}/approve` | `qc_inspections` (#46), `product_batches` (#44), `traceability_snapshots` (#49) | Maker-Checker Guard (`inspector_user_id != approver_user_id`) |
| **6** | **Xuất Giao hàng & Công nợ Phải thu** (Sales Delivery & Receivable) | `POST /api/v1/farms/{farmId}/sales-deliveries/{id}/dispatch` | `sales_deliveries` (#64), `sales_delivery_items` (#65), `product_batches` (#44), `product_batch_transactions` (#48), `sales_order_items` (#63), `sales_orders` (#62), `debt_records` (#66), `partners` (#57) | Farm Barrier Guard & Pessimistic Write Lock trên Lô thành phẩm |
| **7** | **Thanh toán VietQR & Cấn trừ Nợ** (Payment Allocation & Settle) | `POST /api/v1/farms/{farmId}/payments/vietqr-webhook` hoặc `/confirm` | `payment_transactions` (#67), `debt_records` (#66), `payment_allocations` (#68), `sales_orders` (#62) | `@Lock(PESSIMISTIC_WRITE)` trên Sổ nợ `debt_records` |
| **8** | **Điểm danh Tổ Lao động Thời vụ** (Batch Roll-Call Attendance) | `POST /api/v1/hr/attendance/batch-roll-call` | `employee_attendances` (#54) (hàng loạt), `audit_logs` (#10) | Unique Constraint Guard `(employee_id, attendance_date, work_shift_id)` |
| **9** | **Kết toán Chu kỳ Vận hành** (Cycle Financial Settlement) | `POST /api/v1/farms/{farmId}/cycles/{id}/settlement` (Maker), `/sign` (Checker), `/confirm` (Owner) | `cycle_settlements`, `operational_cycles`, `farm_expenses` (#60), `sales_orders` (#62), `audit_logs` (#10) | 3-Step Maker-Checker Multi-Phase Guard & State Lock |

---

## 2. CHI TIẾT THUẬT TOÁN 9 LUỒNG GIAO DỊCH NGUYÊN TỬ

---

### LUỒNG 1: CẤP PHÁT TÀI KHOẢN NHÂN SỰ PHÂN CẤP (HIERARCHICAL PROVISIONING)

*   **Bối cảnh:** Nhân viên nhóm 6A (chính thức/kỹ thuật) mới vào làm việc tại trang trại, sau khi lập hồ sơ trong `employees` (#51), Cấp quản lý bấm nút `[ Cấp Tài Khoản Hệ Thống ]` để người đó có thể đăng nhập Web/App. (Lao động thời vụ 6B không cấp tài khoản, xem Luồng 8).
*   **Quyền RBAC yêu cầu & Chốt chặn Phân cấp Tuyển dụng (Hierarchical Recruitment Guard):**
    *   `ROLE_FARM_OWNER` (Cấp 2, `PERM_HR_EMPLOYEE_MANAGE` cấp Tenant): Chỉ cấp tài khoản và gán vai trò `ROLE_FARM_MANAGER` (Cấp 3).
    *   `ROLE_FARM_MANAGER` (Cấp 3, `PERM_HR_EMPLOYEE_MANAGE` cấp Farm): Tuyển dụng và cấp tài khoản cho 4 vai trò Cấp 4 (`ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_ACCOUNTANT`, `ROLE_FIELD_STAFF`) tại đúng `farmId` được giao quản lý. Cấm tuyệt đối việc tạo tài khoản Farm Owner hoặc gán vào farm khác.
*   **Danh sách 5 bảng cập nhật cùng lúc:**
    1.  `users` (#5): Thêm bản ghi tài khoản mới (`tenant_id`, `username`, `email`, `password_hash`, `status = 'ACTIVE'`, `must_change_password = TRUE`).
    2.  `employees` (#51): Cập nhật liên kết `user_id = users.id`.
    3.  `user_roles` (#8): Thêm vai trò được chỉ định (`tenant_id`, `user_id`, `role_id`, `farm_id` nếu là vai trò cấp Farm).
    4.  `user_farm_access` (#12): Thêm danh sách các trang trại mà nhân viên được phép truy cập (`user_id`, `farm_id`, `tenant_id`).
    5.  `farm_assignments`: Ghi nhận bổ nhiệm chức danh tại trang trại (`user_id`, `farm_id`, `role_in_farm`, `assigned_at`, `status = 'ACTIVE'`).
*   **Quy tắc Atomicity:** Nếu tạo user thành công nhưng gán vai trò `user_roles` hoặc `farm_assignments` bị lỗi, toàn bộ giao dịch phải rollback; không được để lại user "mồ côi" không có quyền trong database.

```mermaid
sequenceDiagram
    autonumber
    actor Manager as Farm Manager (Cấp 3)
    participant API as HrEmployeeController
    participant Svc as AccountProvisioningService
    participant DB as MySQL Database

    Manager->>API: POST /api/v1/hr/employees/51/provision-account
    API->>Svc: provisionAccount(employeeId, request)
    Note over Svc: @Transactional(rollbackFor = Exception.class)<br/>Kiểm tra Hierarchical Recruitment Guard
    Svc->>DB: 1. INSERT INTO users (tenant_id, username, password_hash, must_change_password=TRUE)
    Svc->>DB: 2. UPDATE employees SET user_id = users.id WHERE id = 51
    Svc->>DB: 3. INSERT INTO user_roles (tenant_id, user_id, role_id, farm_id)
    Svc->>DB: 4. INSERT INTO user_farm_access (user_id, farm_id, tenant_id)
    Svc->>DB: 5. INSERT INTO farm_assignments (user_id, farm_id, role_in_farm)
    DB-->>Svc: Commit Transaction thành công
    Svc-->>API: UserProvisionedResponse
    API-->>Manager: 201 Created (Kèm mật khẩu tạm thời)
```

---

### LUỒNG 2: HOÀN TẤT NHẬP KHO MUA HÀNG (PURCHASE STOCK-IN & PAYABLE DEBT)

*   **Bối cảnh:** Thủ kho (`ROLE_WAREHOUSE_STAFF` - Maker) lập phiếu nhập và kiểm đếm, Quản lý Trại (`ROLE_FARM_MANAGER` - Checker) duyệt phiếu; khi hoàn tất, hệ thống kích hoạt tự động cập nhật kho và công nợ.
*   **Quyền RBAC yêu cầu:** `PERM_INVENTORY_RECEIPT` và quyền truy cập farm `@farmSecurity.canAccessFarm(farmId)`.
*   **Chốt chặn The Farm Barrier Guard:** Nhà cung cấp (`partner_id`) bắt buộc phải thuộc cùng trang trại: `partners.farm_id == farmId`.
*   **Danh sách 4 bảng cập nhật cùng lúc:**
    1.  `warehouse_receipts` (#32): Cập nhật `status = 'COMPLETED'`, ghi nhận `approved_by`, `approved_at = CURRENT_TIMESTAMP`. Khóa cứng phiếu.
    2.  `warehouse_inventory` (#31): Cộng số lượng tồn thực tế `quantity_on_hand` theo từng dòng vật tư (`material_id`, `warehouse_id`, `batch_number`, `storage_bin_code`).
    3.  `warehouse_inventory_transactions` (#38): Ghi nhận bút toán Sổ cái thẻ kho với `direction = 'IN'`, `transaction_type = 'INWARD'`, `reference_doc_type = 'WAREHOUSE_RECEIPT'`, `balance_before`, `balance_after = balance_before + quantity`.
    4.  `debt_records` (#66): Nếu là phiếu nhập mua hàng (`receipt_type = 'PURCHASE'`), tự động tạo một khoản nợ phải trả cho nhà cung cấp (`partner_id`): `debt_type = 'PAYABLE'`, `warehouse_receipt_id = warehouse_receipts.id`, `total_debt = warehouse_receipts.total_amount`, `paid_amount = 0.00`, `remaining_debt = total_debt`, `due_date = receipt_date + partner.payment_term_days`, `status = 'ACTIVE'`.

```java
@Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
public ReceiptResponse completePurchaseReceipt(Long farmId, Long receiptId) {
    WarehouseReceipt receipt = receiptRepository.findByIdAndFarmId(receiptId, farmId)
        .orElseThrow(() -> new EntityNotFoundException("Phiếu nhập kho không tồn tại"));

    if (!"DRAFT".equals(receipt.getStatus()) && !"APPROVED".equals(receipt.getStatus())) {
        throw new IllegalStateException("Chỉ phiếu ở trạng thái DRAFT hoặc APPROVED mới được hoàn tất");
    }

    // 1. Cập nhật trạng thái phiếu nhập
    receipt.setStatus("COMPLETED");
    receipt.setApprovedBy(SecurityUtils.getCurrentUserId());
    receipt.setApprovedAt(Instant.now());
    receiptRepository.save(receipt);

    // 2. Duyệt từng dòng chi tiết để cộng kho và ghi thẻ kho
    for (WarehouseReceiptItem item : receipt.getItems()) {
        // Khóa bi quan dòng tồn kho để chống Race Condition khi có 2 luồng nhập cùng lô
        WarehouseInventory inv = inventoryRepository.findAndLock(
            receipt.getTenantId(), farmId, receipt.getWarehouseId(), item.getMaterialId(), item.getBatchNumber())
            .orElseGet(() -> createEmptyInventory(receipt, item));

        BigDecimal balanceBefore = inv.getQuantityOnHand();
        BigDecimal balanceAfter = balanceBefore.add(item.getQuantity());

        inv.setQuantityOnHand(balanceAfter);
        inv.setExpiryDate(item.getExpiryDate());
        inventoryRepository.save(inv);

        // Ghi Sổ cái thẻ kho (Append-Only)
        WarehouseInventoryTransaction trans = WarehouseInventoryTransaction.builder()
            .tenantId(receipt.getTenantId()).farmId(farmId).warehouseId(receipt.getWarehouseId())
            .materialId(item.getMaterialId()).batchNumber(item.getBatchNumber())
            .transactionType("INWARD").referenceDocType("WAREHOUSE_RECEIPT")
            .referenceDocId(receipt.getId()).referenceItemId(item.getId())
            .direction("IN").quantity(item.getQuantity())
            .balanceBefore(balanceBefore).balanceAfter(balanceAfter)
            .transactionDate(receipt.getReceiptDate())
            .build();
        inventoryTransactionRepository.save(trans);
    }

    // 3. Tự động sinh công nợ phải trả nếu là mua hàng (Farm Barrier Guard)
    if ("PURCHASE".equals(receipt.getReceiptType())) {
        Partner partner = partnerRepository.findByIdAndFarmId(receipt.getPartnerId(), farmId)
            .orElseThrow(() -> new EntityNotFoundException("Đối tác không tồn tại hoặc không thuộc trang trại này"));
        LocalDate dueDate = receipt.getReceiptDate().plusDays(partner.getPaymentTermDays());
        
        DebtRecord debt = DebtRecord.builder()
            .tenantId(receipt.getTenantId()).farmId(farmId).partnerId(partner.getId())
            .warehouseReceiptId(receipt.getId()).debtType("PAYABLE")
            .totalDebt(receipt.getTotalAmount()).paidAmount(BigDecimal.ZERO)
            .remainingDebt(receipt.getTotalAmount()).dueDate(dueDate).status("ACTIVE")
            .build();
        debtRecordRepository.save(debt);
    }

    return receiptMapper.toResponse(receipt);
}
```

---

### LUỒNG 3: TIÊU HAO TỰ ĐỘNG CANH TÁC (ATOMIC AUTO-BACKFLUSHING)

*   **Bối cảnh:** Kỹ sư nông nghiệp ghi nhật ký bón phân / phun thuốc (`farming_logs` #20) hoặc Bác sĩ thú y ghi sự kiện tiêm vắc-xin (`livestock_events` #25) có khai báo vật tư sử dụng.
*   **Quyền RBAC yêu cầu:** `PERM_CROP_LOG` hoặc `PERM_LIVESTOCK_VET`.
*   **Danh sách 7 bảng cập nhật cùng lúc:**
    1.  `farming_logs` (#20): Lưu thông tin hoạt động (`activity_type`, `log_date`, `phi_days`, `phi_end_date`).
    2.  `farming_log_supplies` (#41): Lưu danh sách vật tư sử dụng thực tế (`actual_quantity`, `unit_price`, `total_price`).
    3.  `warehouse_inventory` (#31): **Khóa dòng tồn kho (`@Lock(PESSIMISTIC_WRITE)`)**, kiểm tra tồn khả dụng `quantity_on_hand - reserved_quantity >= actual_quantity`. Nếu không đủ tồn: Ném lỗi `INSUFFICIENT_STOCK` và ROLLBACK toàn bộ nhật ký. Nếu đủ tồn: Trừ `quantity_on_hand`.
    4.  `warehouse_issues` (#34): Tự động tạo Phiếu xuất kho nội bộ (`issue_type = 'PRODUCTION_BACKFLUSH'`, `is_backflushed = TRUE`, `status = 'COMPLETED'`, `farming_log_id = farming_logs.id`).
    5.  `warehouse_issue_items` (#35): Tạo các dòng xuất kho tương ứng với từng vật tư.
    6.  `warehouse_inventory_transactions` (#38): Ghi bút toán xuất kho `direction = 'OUT'`, `transaction_type = 'OUTWARD'`, `balance_after = balance_before - quantity`.
    7.  `farm_expenses` (#60): Hạch toán một bút toán chi phí sản xuất trực tiếp (`expense_source = 'INVENTORY_BACKFLUSH'`, `reference_id = warehouse_issues.id`, `amount = warehouse_issues.total_amount`, `status = 'CONFIRMED'`).

```mermaid
sequenceDiagram
    autonumber
    actor Engineer as Kỹ sư Nông nghiệp
    participant API as FarmingLogController
    participant Svc as FarmingLogService
    participant DB as MySQL Database (InnoDB)

    Engineer->>API: POST /api/v1/farms/1/farming-logs (Kèm danh sách vật tư)
    API->>Svc: createFarmingLog(farmId, request)
    Note over Svc: @Transactional(rollbackFor = Exception.class)
    Svc->>DB: 1. INSERT INTO farming_logs
    Svc->>DB: 2. INSERT INTO farming_log_supplies
    loop Cho từng vật tư tiêu hao
        Svc->>DB: 3. SELECT * FROM warehouse_inventory WHERE ... FOR UPDATE (Khóa dòng)
        alt Tồn kho khả dụng < Số lượng tiêu hao
            Svc-->>API: THROW InsufficientStockException (HTTP 400)
            Note over Svc,DB: ROLLBACK TOÀN BỘ TRANSACTION!
        else Đủ tồn kho
            Svc->>DB: 4. UPDATE warehouse_inventory SET quantity_on_hand = quantity_on_hand - actual_qty
            Svc->>DB: 5. INSERT INTO warehouse_inventory_transactions (direction='OUT')
        end
    end
    Svc->>DB: 6. INSERT INTO warehouse_issues (issue_type='PRODUCTION_BACKFLUSH', status='COMPLETED')
    Svc->>DB: 7. INSERT INTO warehouse_issue_items
    Svc->>DB: 8. INSERT INTO farm_expenses (expense_source='INVENTORY_BACKFLUSH')
    DB-->>Svc: COMMIT TRANSACTION THÀNH CÔNG
    Svc-->>API: FarmingLogResponse
    API-->>Engineer: 201 Created (Nhật ký đã lưu & Đã tự động trừ kho)
```

---

### LUỒNG 4: THU HOẠCH & ĐÓNG GÓI LÔ THÀNH PHẨM (HARVEST TO FINISHED BATCH)

*   **Bối cảnh:** Công nhân thực hiện thu hoạch nông sản tại ruộng hoặc xuất chuồng gia súc.
*   **Quyền RBAC yêu cầu:** `PERM_HARVEST_MANAGE` và `@farmSecurity.canAccessFarm(farmId)`.
*   **Danh sách 5 bảng cập nhật cùng lúc:**
    1.  `harvest_records` (#43): Tạo biên bản thu hoạch (`harvest_code`, `source_type = 'CROP_SEASON'`, `season_id`, `quantity`, `quality_grade`, `harvest_date`).
    2.  `crop_seasons` (#19): Cộng lũy kế sản lượng thu hoạch thực tế:
        $$\text{actual\_yield\_kg} = \text{actual\_yield\_kg} + \text{harvest\_records.quantity}$$
    3.  `product_batches` (#44): Tự động tạo một Lô thành phẩm đóng gói lưu trữ tại Kho Nông sản (`warehouse_id`), trạng thái khởi tạo `status = 'PENDING_APPROVAL'`, `initial_quantity = quantity`, `remaining_quantity = quantity`, `reserved_quantity = 0.00`.
    4.  `product_batch_sources` (#45): Ghi nhận dòng nguồn gốc nguyên liệu trỏ tới `harvest_record_id` với `contributed_quantity = quantity`.
    5.  `product_batch_transactions` (#48): Ghi nhận bút toán Sổ cái thành phẩm với `direction = 'IN'`, `transaction_type = 'HARVEST_IN'`, `reference_type = 'HARVEST_RECORD'`, `balance_before = 0.00`, `balance_after = quantity`.

---

### LUỒNG 5: PHÊ DUYỆT KCS & ĐÓNG BĂNG TRUY XUẤT (QC APPROVAL & TRACEABILITY FREEZE)

*   **Bối cảnh:** Sau khi Kỹ thuật viên kiểm định KCS (`ROLE_TECHNICAL_STAFF` - Maker, `qc_inspections` #46) lập phiếu đánh giá đạt chuẩn `overall_result = 'PASSED'`, Quản lý Trang trại (`ROLE_FARM_MANAGER` - Checker Cấp 3) hoặc Chủ trang trại (`ROLE_FARM_OWNER` - Cấp 2) bấm nút `[ Phê Duyệt Lô & Cấp Mã QR ]`.
*   **Quyền RBAC yêu cầu & Chốt chặn Maker-Checker:** `PERM_QC_APPROVE` (Bắt buộc kiểm tra: `inspector_user_id != approver_user_id` — người duyệt không được là người kiểm định).
*   **Danh sách 3 bảng cập nhật cùng lúc:**
    1.  `product_batches` (#44): 
        *   Cập nhật `status = 'READY_TO_PRINT'`.
        *   Ghi nhận `approved_by_user_id = currentUserId`, `approved_at = CURRENT_TIMESTAMP`.
        *   Tự động sinh mã định danh toàn cầu duy nhất: **`traceability_code = UUID.randomUUID().toString()`**.
    2.  `traceability_snapshots` (#49): Trích xuất toàn bộ dữ liệu lịch sử sản xuất của lô hàng và đóng băng vào bảng bản chụp truy xuất:
        *   `enterprise_info_json`: Thông tin doanh nghiệp, MST, địa chỉ, tài khoản VietQR.
        *   `vietgap_cert_json`: Danh sách chứng nhận VietGAP/GlobalGAP còn hiệu lực.
        *   `farming_timeline_json`: Toàn bộ cây lịch sử nhật ký canh tác (`farming_logs`), danh sách phân bón, thuốc BVTV và ngày cách ly đã tuân thủ.
        *   `harvest_info_json`: Biên bản thu hoạch, ngày thu hoạch, người thu hoạch.
        *   `qc_inspection_json`: Biên bản KCS, chỉ tiêu hóa nghiệm đạt chuẩn.
        *   `snapshot_hash`: Mã băm SHA-256 tính toán từ nội dung các chuỗi JSON trên nhằm chống sửa đổi giả mạo.
    3.  `audit_logs` (#10): Ghi nhật ký phê duyệt lô thành phẩm và cấp mã truy xuất nguồn gốc.

---

### LUỒNG 6: XUẤT GIAO HÀNG & CÔNG NỢ PHẢI THU (SALES DELIVERY & RECEIVABLE DEBT)

*   **Bối cảnh:** Thủ kho (`ROLE_WAREHOUSE_STAFF` - Maker) xuất hàng cho xe tải giao hàng cho Khách mua sỉ theo Đơn bán hàng (`sales_orders` #62) đã được duyệt, bấm `[ Xuất Giao Hàng ]`.
*   **Quyền RBAC yêu cầu:** `PERM_DELIVERY_MANAGE` và `@farmSecurity.canAccessFarm(farmId)`.
*   **Chốt chặn The Farm Barrier Guard:** Khách hàng đối tác (`partner_id`) bắt buộc phải thuộc cùng trang trại: `partners.farm_id == farmId`.
*   **Danh sách 7 bảng cập nhật cùng lúc:**
    1.  `sales_deliveries` (#64): Cập nhật `status = 'DISPATCHED'`, ghi nhận `delivered_by_user_id`, thời gian giao `dispatched_at`.
    2.  `product_batches` (#44): **Khóa dòng bằng Pessimistic Lock**:
        *   Trừ tồn kho thực tế: `remaining_quantity = remaining_quantity - delivery_qty`.
        *   Giải phóng tồn kho đã đặt trước: `reserved_quantity = reserved_quantity - delivery_qty`.
    3.  `product_batch_transactions` (#48): Ghi Sổ cái xuất thành phẩm: `direction = 'OUT'`, `transaction_type = 'SALE_DISPATCH'`, `reference_type = 'SALES_DELIVERY'`.
    4.  `sales_order_items` (#63): Cộng dồn sản lượng đã giao thực tế:
        $$\text{shipped\_quantity} = \text{shipped\_quantity} + \text{delivery\_qty}$$
    5.  `sales_orders` (#62): Cập nhật trạng thái đơn hàng sang `DELIVERED` (nếu giao một phần) hoặc `COMPLETED` (nếu đã giao đủ 100% tất cả các mặt hàng).
    6.  `debt_records` (#66): Tự động phát sinh một khoản nợ phải thu của khách hàng (`partner_id`):
        `debt_type = 'RECEIVABLE'`, `sales_order_id = sales_orders.id`, `total_debt = sales_deliveries.total_shipped_amount`, `remaining_debt = total_debt`, `status = 'ACTIVE'`.
    7.  `sales_orders.debt_amount`: Đồng bộ số tiền nợ còn lại của đơn hàng.

---

### LUỒNG 7: THANH TOÁN VIETQR & CẤN TRỪ NỢ (VIETQR PAYMENT & DEBT OFFSET)

*   **Bối cảnh:** Khách hàng quét mã VietQR chuyển khoản thanh toán tiền hàng hoặc Kế toán nhận tiền mặt/chuyển khoản từ Đại lý, bấm `[ Xác Nhận Thanh Toán ]`.
*   **Quyền RBAC yêu cầu:** `PERM_FINANCE_PAYMENT` và `PERM_PAYMENT_ALLOCATE`.
*   **Danh sách 4 bảng cập nhật cùng lúc:**
    1.  `payment_transactions` (#67): Tạo bản ghi thanh toán với `status = 'COMPLETED'`, `payment_type = 'RECEIPT'`, `confirmed_by_user_id`, `confirmed_at`.
    2.  `debt_records` (#66): **Khóa dòng nợ (`@Lock(PESSIMISTIC_WRITE)`)**, thực hiện cấn trừ nợ:
        *   `paid_amount = paid_amount + allocated_amount`.
        *   `remaining_debt = total_debt - paid_amount`.
        *   Nếu `remaining_debt == 0.00`: Chuyển `status = 'SETTLED'`.
    3.  `payment_allocations` (#68): Ghi nhận bút toán phân bổ dòng tiền: Liên kết `payment_id`, `debt_record_id`, `allocated_amount`.
    4.  `sales_orders` (#62): Cập nhật số tiền đã trả trên đơn hàng:
        *   `paid_amount = paid_amount + allocated_amount`.
        *   `debt_amount = final_amount - paid_amount`.
        *   Cập nhật `payment_status`: Nếu `debt_amount == 0.00` chuyển `PAID`, nếu còn nợ chuyển `PARTIALLY_PAID`.

```java
@Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
public PaymentResponse allocatePaymentToDebt(Long farmId, Long paymentId, PaymentAllocationRequest request) {
    PaymentTransaction payment = paymentRepository.findByIdAndFarmId(paymentId, farmId)
        .orElseThrow(() -> new EntityNotFoundException("Giao dịch thanh toán không tồn tại"));

    // Khóa bi quan bản ghi nợ để tránh việc 2 kế toán cùng cấn trừ nợ đồng thời
    DebtRecord debt = debtRepository.findAndLockById(request.getDebtRecordId())
        .orElseThrow(() -> new EntityNotFoundException("Hồ sơ công nợ không tồn tại"));

    BigDecimal allocatedAmount = request.getAllocatedAmount();
    if (allocatedAmount.compareTo(debt.getRemainingDebt()) > 0) {
        throw new IllegalArgumentException("Số tiền phân bổ không được vượt quá số nợ còn lại");
    }

    // 1. Cập nhật số tiền đã phân bổ trên giao dịch thanh toán
    payment.setAllocatedAmount(payment.getAllocatedAmount().add(allocatedAmount));
    paymentRepository.save(payment);

    // 2. Cấn trừ nợ trong debt_records
    debt.setPaidAmount(debt.getPaidAmount().add(allocatedAmount));
    debt.setRemainingDebt(debt.getTotalDebt().subtract(debt.getPaidAmount()));
    if (debt.getRemainingDebt().compareTo(BigDecimal.ZERO) == 0) {
        debt.setStatus("SETTLED");
    }
    debtRepository.save(debt);

    // 3. Ghi Sổ cái phân bổ thanh toán payment_allocations
    PaymentAllocation allocation = PaymentAllocation.builder()
        .tenantId(payment.getTenantId()).farmId(farmId)
        .paymentId(payment.getId()).debtRecordId(debt.getId())
        .allocatedAmount(allocatedAmount).notes(request.getNotes())
        .build();
    allocationRepository.save(allocation);

    // 4. Nếu khoản nợ này gắn với Đơn bán hàng -> Đồng bộ sales_orders
    if (debt.getSalesOrderId() != null) {
        SalesOrder order = salesOrderRepository.findById(debt.getSalesOrderId()).orElseThrow();
        order.setPaidAmount(order.getPaidAmount().add(allocatedAmount));
        order.setDebtAmount(order.getFinalAmount().subtract(order.getPaidAmount()));
        
        if (order.getDebtAmount().compareTo(BigDecimal.ZERO) == 0) {
            order.setPaymentStatus("PAID");
        } else {
            order.setPaymentStatus("PARTIALLY_PAID");
        }
        salesOrderRepository.save(order);
    }

    return paymentMapper.toResponse(payment);
}
```

---

### LUỒNG 8: ĐIỂM DANH TỔ LAO ĐỘNG THỜI VỤ (BATCH ROLL-CALL ATTENDANCE)

*   **Bối cảnh:** Nhóm lao động thời vụ 6B (lao động nhật, bốc vác, làm cỏ không có tài khoản SaaS) bắt đầu ca làm việc. Trưởng phân khu hoặc Thủ kho (`ROLE_FARM_MANAGER` hoặc được phân quyền `PERM_HR_ATTENDANCE`) thực hiện chụp ảnh toàn đội tại hiện trường và gửi điểm danh tập thể một chạm.
*   **Điểm kích hoạt:** `POST /api/v1/hr/attendance/batch-roll-call`
*   **Quyền RBAC yêu cầu:** `PERM_HR_ATTENDANCE` và `@farmSecurity.canAccessFarm(farmId)`.
*   **Danh sách bảng cập nhật cùng lúc:**
    1.  `employee_attendances` (#54): Thêm hàng loạt bản ghi điểm danh cho danh sách `employee_ids`:
        *   `employee_id`: ID nhân sự thời vụ thuộc farm.
        *   `attendance_date`: Ngày làm việc hiện tại.
        *   `work_shift_id`: Ca làm việc.
        *   `check_in_time`: Thời điểm điểm danh tập thể.
        *   `check_in_photo_url`: URL ảnh chụp cả đội tại hiện trường (S3/MinIO).
        *   `check_in_latitude`, `check_in_longitude`: Tọa độ GPS hiện trường điểm danh.
        *   `status = 'PRESENT'`.
        *   `verified_by_user_id`: ID của Quản lý/Thủ kho thực hiện điểm danh.
    2.  `audit_logs` (#10): Ghi vết kiểm toán điểm danh tập thể với số lượng lao động đã check-in.
*   **Ràng buộc Atomicity & Chống trùng lặp:** 
    *   Tất cả `employee_ids` phải thuộc đúng `farmId` và `employee_type = 'SEASONAL'`.
    *   Sử dụng Unique Constraint `(employee_id, attendance_date, work_shift_id)` để chống điểm danh 2 lần trong cùng 1 ca.

```mermaid
sequenceDiagram
    autonumber
    actor Supervisor as Trưởng Khu / Thủ Kho
    participant API as AttendanceController
    participant Svc as BatchAttendanceService
    participant DB as MySQL Database

    Supervisor->>API: POST /api/v1/hr/attendance/batch-roll-call (employeeIds[], shiftId, photoUrl, lat, lng)
    API->>Svc: batchRollCall(farmId, request)
    Note over Svc: @Transactional(rollbackFor = Exception.class)<br/>Xác thực tọa độ GPS & nhân sự thuộc Farm
    loop Cho từng employeeId
        Svc->>DB: INSERT INTO employee_attendances (employee_id, attendance_date, work_shift_id, photo_url, lat, lng, verified_by)
    end
    Svc->>DB: INSERT INTO audit_logs (action='BATCH_ROLL_CALL', record_count=N)
    DB-->>Svc: Commit Transaction thành công
    Svc-->>API: BatchRollCallResponse (successCount, failedList)
    API-->>Supervisor: 200 OK (Điểm danh thành công cả tổ)
```

---

### LUỒNG 9: KẾT TOÁN CHU KỲ VẬN HÀNH (OPERATIONAL CYCLE FINANCIAL SETTLEMENT)

*   **Bối cảnh:** Một Mùa vụ (`crop_seasons`) hoặc Đàn nuôi (`livestock_groups`) hoàn tất thu hoạch và tiêu thụ hết sản lượng. Kế toán, Quản lý Trại và Chủ Trại tiến hành quy trình 3 bước Maker-Checker để chốt sổ chi phí, doanh thu, lợi nhuận và giải phóng chu kỳ sang `CLOSED`.
*   **Quy trình 3 Bước Phân cấp (3-Step Hierarchical Workflow):**
    1.  **Bước 1 - Lập bảng kết toán (Draft):** Kế toán Trại (`ROLE_ACCOUNTANT` - Maker, `PERM_FINANCE_REPORT`) gọi `POST /api/v1/farms/{farmId}/cycles/{id}/settlement`:
        *   Hệ thống tổng hợp chi phí thực tế từ `farm_expenses` (#60) (vật tư backflush, nhân công, chi phí chung).
        *   Tổng hợp doanh thu thực tế từ `sales_orders` (#62) và tình trạng thu hồi công nợ từ `debt_records` (#66).
        *   Tạo bản ghi `cycle_settlements` với trạng thái `DRAFT`, tính toán Lợi nhuận gộp và Tỷ suất ROI.
    2.  **Bước 2 - Ký duyệt vận hành (Sign):** Quản lý Trang trại (`ROLE_FARM_MANAGER` - Checker Cấp 3, `PERM_FINANCE_REPORT`) gọi `POST /api/v1/farms/{farmId}/cycles/{id}/settlement/sign`:
        *   Kiểm tra số liệu thực tế tại trại, ký xác nhận chuyển trạng thái `cycle_settlements` sang `SIGNED_BY_MANAGER`.
    3.  **Bước 3 - Xác nhận & Đóng chu kỳ (Confirm & Close):** Chủ Trang trại (`ROLE_FARM_OWNER` - Approver Cấp 2, `PERM_FINANCE_REPORT`) gọi `POST /api/v1/farms/{farmId}/cycles/{id}/settlement/confirm`:
        *   Cập nhật `cycle_settlements.status = 'CONFIRMED'`.
        *   Chuyển trạng thái Vụ mùa/Đàn nuôi sang `CLOSED`.
        *   Tự động kích hoạt cơ chế Hủy các công việc định kỳ còn tồn đọng (`farm_tasks` chuyển `CANCELLED`).
        *   Ghi nhận bút toán chuyển lợi nhuận thuần về tài khoản Chủ sở hữu.
*   **Các bảng SQL cập nhật cùng lúc:**
    `cycle_settlements`, `crop_seasons` hoặc `livestock_groups`, `farm_tasks`, `audit_logs`.

```mermaid
sequenceDiagram
    autonumber
    actor Acc as Kế toán (Maker)
    actor Mgr as Farm Manager (Checker)
    actor Owner as Farm Owner (Approver)
    participant API as CycleSettlementController
    participant Svc as CycleSettlementService
    participant DB as MySQL Database

    Acc->>API: 1. POST /cycles/{id}/settlement (Lập dự thảo kết toán)
    API->>Svc: draftSettlement(farmId, cycleId)
    Svc->>DB: INSERT INTO cycle_settlements (status='DRAFT', total_revenue, total_cost, profit)
    Svc-->>API: 201 Created (Bảng kết toán dự thảo)

    Mgr->>API: 2. POST /cycles/{id}/settlement/sign (Ký duyệt cấp Trại)
    API->>Svc: signSettlement(farmId, cycleId)
    Svc->>DB: UPDATE cycle_settlements SET status='SIGNED_BY_MANAGER', signed_by=userId
    Svc-->>API: 200 OK (Đã ký chuyển Owner)

    Owner->>API: 3. POST /cycles/{id}/settlement/confirm (Xác nhận & Đóng chu kỳ)
    API->>Svc: confirmAndCloseCycle(farmId, cycleId)
    Note over Svc: @Transactional(rollbackFor = Exception.class)
    Svc->>DB: UPDATE cycle_settlements SET status='CONFIRMED', confirmed_by=ownerId
    Svc->>DB: UPDATE crop_seasons SET status='CLOSED' WHERE id=cycleId
    Svc->>DB: UPDATE farm_tasks SET status='CANCELLED' WHERE season_id=cycleId AND status IN ('PENDING','IN_PROGRESS')
    Svc->>DB: INSERT INTO audit_logs (action='CYCLE_SETTLEMENT_CONFIRMED')
    DB-->>Svc: Commit Transaction
    Svc-->>API: 200 OK (Chu kỳ kết toán hoàn tất)
```

---
*Văn kiện `SPEC-FLOW-006` là tài liệu tham chiếu kỹ thuật bắt buộc để kiểm soát tính trọn vẹn dữ liệu và an toàn đồng thời cho toàn bộ hệ thống Farm SaaS.*
