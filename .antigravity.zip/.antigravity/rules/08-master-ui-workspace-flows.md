# HIẾN PHÁP KIẾN TRÚC 4 APPLICATION SHELLS & 9 WORKSPACES VẬN HÀNH AGRI-ERP
## (MASTER UI WORKSPACE FLOWS & COMPREHENSIVE ARCHITECTURE)
## (MASTER UI WORKSPACE FLOWS & COMPREHENSIVE ARCHITECTURE)
### PHIÊN BẢN 2.0: CHUẨN HÓA AGRI-ERP ĐỒNG BỘ TOÀN DIỆN CƠ SỞ DỮ LIỆU 72 BẢNG

> **Mã văn kiện:** `RULE-UI-001`  
> **Cấp độ hiệu lực:** **BẮT BUỘC TUÂN THỦ TỐI CAO (SUPREME FRONTEND STANDARD)**  
> **Cơ quan ban hành:** Ban Kiến trúc Hệ thống & UI/UX Frontend Lead  
> **Phiên bản đồng bộ:** `v2.0 - Agri-ERP Production Grade (Single Source of Truth DB 72 Tables Sync)`  
> **Căn cứ Database:** [V1_0__init_system_core.sql](file:///d:/Projects/Farm_Management/backend/src/main/resources/db/migration/V1_0__init_system_core.sql) (MySQL 8.x, InnoDB, utf8mb4_unicode_ci — 72 Bảng cốt lõi & RBAC Seed)  
> **Phạm vi ràng buộc:** Toàn bộ thành phần giao diện Frontend (React 18+, Vite, TailwindCSS, Zustand, React Hook Form, Lucide Icons) phủ kín **100% Sơ đồ phân cấp chức năng** (Từ Module 1.1 đến Module 7.7) và **100% 72 Bảng dữ liệu quan hệ** trong dự án Nền tảng Nông nghiệp Số Farm SaaS.  
> **Tôn chỉ tối thượng:** *"Chống phân mảnh giao diện (Anti-Siloed) — Bảo toàn ngữ cảnh tuyệt đối (Context Preservation) — Đơn nhất điểm tựa dữ liệu (Single Source of Truth) — Không độ trễ nhận thức (Zero Cognitive Friction)"*.

---

## MỤC LỤC CHI TIẾT

1. [Điều 1: Kiến Trúc 4 Tầng Khung Giao Diện (4 Application Shells) & Nguyên Tắc Cốt Lõi](#điều-1-kiến-trúc-4-tầng-khung-giao-diện-4-application-shells--nguyên-tắc-cốt-lõi)
   - [1.1. Bốn Shell Ứng Dụng Độc Lập (4 Application Shells)](#11-bốn-shell-ứng-dụng-độc-lập-4-application-shells)
   - [1.2. 5 Nguyên Tắc Thiết Kế UI Cốt Lõi (Core UI Principles)](#12-5-nguyên-tắc-thiết-kế-ui-cốt-lõi-core-ui-principles)
2. [Điều 2: Quy Hoạch Không Gian Làm Việc Hợp Nhất (Workspaces A -> H2)](#điều-2-quy-hoạch-không-gian-làm-việc-hợp-nhất-workspaces-a---h2)
   - [2.1. Workspace A: Quản Trị Mặt Bằng & Phân Công Hiện Trường (WS-PRODUCTION-GEOGRAPHY)](#21-workspace-a-quản-trị-mặt-bằng--phân-công-hiện-trường-ws-production-geography)
   - [2.2. Workspace B: Hồ Sơ Nhân Sự 360° & Tài Khoản SaaS (WS-HR-PERSONNEL-360)](#22-workspace-b-hồ-sơ-nhân-sự-360-v-tài-khoản-saas-ws-hr-personnel-360)
   - [2.3. Workspace C: Trung Tâm Giao Dịch Kho & Quét Đa Mã Vạch (WS-INVENTORY-TRANSACTION-HUB)](#23-workspace-c-trung-tâm-giao-dịch-kho--quét-đa-mã-vạch-ws-inventory-transaction-hub)
   - [2.4. Workspace D: Sổ Danh Bạ Đối Tác & Tài Khoản VietQR (WS-ORGANIZATION-PARTNERS)](#24-workspace-d-sổ-danh-bạ-đối-tác--tài-khoản-vietqr-ws-organization-partners)
   - [2.5. Workspace E: Bàn Làm Việc Canh Tác & Chăn Nuôi Hiện Trường Liền Mạch (WS-FARMING-OPERATIONS)](#25-workspace-e-bàn-làm-việc-canh-tác--chăn-nuôi-hiện-trường-liền-mạch-ws-farming-operations)
   - [2.6. Workspace F: Đường Ống Quản Trị Chất Lượng & Truy Xuất Nguồn Gốc (WS-QA-TRACEABILITY-PIPELINE)](#26-workspace-f-đường-ống-quản-trị-chất-lượng--truy-xuất-nguồn-gốc-ws-qa-traceability-pipeline)
   - [2.7. Workspace G: Cổng Thông Tin Nhân Viên, Chấm Công GPS/Selfie & Vận Hành Hàng Ngày (WS-EMPLOYEE-DAILY-OPS)](#27-workspace-g-cổng-thông-tin-nhân-viên-chấm-công-gpsselfie--vận-hành-hàng-ngày-ws-employee-daily-ops)
   - [2.8. Workspace H1: Quản Trị Giá Thành & Phân Bổ Chi Phí Sản Xuất (WS-COST-ACCOUNTING-ALLOCATION)](#28-workspace-h1-quản-trị-giá-thành--phân-bổ-chi-phí-sản-xuất-ws-cost-accounting-allocation)
   - [2.9. Workspace H2: Trung Tâm Bán Hàng, Giao Hàng & Thu Phí VietQR (WS-SALES-CASHFLOW-CONSOLE)](#29-workspace-h2-trung-tâm-bán-hàng-giao-hàng--thu-phí-vietqr-ws-sales-cashflow-console)
3. [Điều 3: Quy Hoạch Trung Tâm Cài Đặt Danh Mục & Phân Hệ Độc Lập](#điều-3-quy-hoạch-trung-tâm-cài-đặt-danh-mục--phân-hệ-độc-lập)
   - [3.1. Trung Tâm Cài Đặt Danh Mục Tĩnh (/app/settings - Master Data)](#31-trung-tâm-cài-đặt-danh-mục-tĩnh-appsettings---master-data)
   - [3.2. Phân Hệ Báo Cáo & Phân Tích Thông Minh (/app/reports - Module 6)](#32-phân-hệ-báo-cáo--phân-tích-thông-minh-appreports---module-6)
   - [3.3. Phân Hệ Quản Trị Hệ Thống, An Ninh & Tích Hợp (/app/system - Module 7)](#33-phân-hệ-quản-trị-hệ-thống-an-ninh--tích-hợp-appsystem---module-7)
4. [Điều 4: Sơ Đồ Luồng Thao Tác Từ Nhỏ Đến Lớn (Micro to Macro Interaction Flows)](#điều-4-sơ-đồ-luồng-thao-tác-từ-nhỏ-đến-lớn-micro-to-macro-interaction-flows)
   - [4.1. Luồng Lớn: Chuỗi Thiết Lập 5 Chặng & Quy Tắc Smart Empty State](#41-luồng-lớn-chuỗi-thiết-lập-5-chặng--quy-tắc-smart-empty-state)
   - [4.2. Luồng Nhỏ: 4 Cơ Chế Tác Nghiệp Thành Phần Trọng Yếu (Micro Component Flows)](#42-luồng-nhỏ-4-cơ-chế-tác-nghiệp-thành-phần-trọng-yếu-micro-component-flows)
5. [Điều 5: Bảng Ánh Xạ Phủ Kín 100% 72 Bảng SQL Vào Giao Diện UI](#điều-5-bảng-ánh-xạ-phủ-kín-100-72-bảng-sql-vào-giao-diện-ui)
6. [Điều 6: Ma Trận Đối Soát 100% Sơ Đồ Phân Cấp Chức Năng (Module 1.1 -> 7.7)](#điều-6-ma-trận-đối-soát-100-sơ-đồ-phân-cấp-chức-năng-module-11---77)
7. [Điều 7: Checklist Nghiệm Thu UI Bắt Buộc Trước Khi Merge Code (Frontend Review Gate)](#điều-7-checklist-nghiệm-thu-ui-bắt-buộc-trước-khi-merge-code-frontend-review-gate)

---

## KIẾN TRÚC TỔNG THỂ HỆ THỐNG WORKSPACE V2.0

```mermaid
graph TD
    subgraph "4 APPLICATION SHELLS"
        S_AUTH["1. AuthShell<br/>(/login, /force-change-password)"]
        S_PLATFORM["2. PlatformShell<br/>(/platform/* - Super Admin)"]
        S_TENANT["3. TenantAppShell<br/>(/app/* - 6 Roles Tenant Cấp 2-4)"]
        S_PUBLIC["4. PublicTraceShell<br/>(/trace/:code - Cổng QR Công Khai)"]
    end

    subgraph "TENANT APP SHELL - WORKSPACES VẬN HÀNH"
        WA["Workspace A: Mặt Bằng & Phân Công<br/>(Master-Detail: Farm - Zone - Staff)"]
        WB["Workspace B: Hồ Sơ Nhân Sự 360°<br/>(Drawer: Lý Lịch + Tài Khoản SaaS)"]
        WC["Workspace C: Trung Tâm Kho Bãi<br/>(Console: Quét Mã Vạch - Nhập - Xuất - Chuyển - Sổ Kho)"]
        WD["Workspace D: Danh Bạ Đối Tác<br/>(Directory: NCC, Khách, Logistics & VietQR)"]
        WE["Workspace E: Canh Tác & Chăn Nuôi<br/>(Master Vụ/Đàn: Nhật Ký + Auto-Backflush + Thu Hoạch)"]
        WF["Workspace F: Đường Ống QA & QR<br/>(Kanban 6 Cột: Lô -> QC -> In Tem -> Freeze Snapshot)"]
        WG["Workspace G: Cổng Nhân Viên Daily<br/>(My Dashboard: GPS/Selfie 2 Chiều, Việc, Phép)"]
        WH1["Workspace H1: Giá Thành & Chi Phí<br/>(Split-View: 4 Nguồn Chi Phí -> Phân Bổ -> Giá Thành/Kg)"]
        WH2["Workspace H2: Bán Hàng & Dòng Tiền<br/>(Console: Đơn Sỉ -> Giao Nhiều Đợt -> VietQR & Cấn Trừ)"]
    end

    subgraph "MASTER DATA & PHÂN HỆ ĐỘC LẬP"
        ST_MASTER["Trung Tâm Cài Đặt Danh Mục (/app/settings)<br/>(Enterprises, Cycles, Warehouses, Materials, BOM, Shifts)"]
        ST_REPORT["Module 6: Báo Cáo & Phân Tích (/app/reports)<br/>(Executive Dashboard, Sản Xuất, Kho, Nhân Sự, Tài Chính)"]
        ST_SYSTEM["Module 7: Quản Trị Hệ Thống (/app/system)<br/>(RBAC Roles/Perms, Audit Trail, Notification, IoT)"]
    end

    S_TENANT --> WA & WB & WC & WD & WE & WF & WG & WH1 & WH2
    S_TENANT --> ST_MASTER & ST_REPORT & ST_SYSTEM

    WA -->|Cung cấp vị trí hiện trường| WE
    WC -->|Xuất vật tư tự động Auto-Backflush| WE
    WE -->|Thu hoạch tạo Lô thành phẩm #44| WF
    WF -->|Đóng băng dữ liệu Traceability #49| S_PUBLIC
    WF -->|Lô đạt chuẩn KCS xuất kho| WH2
    WD -->|Đối tác giao dịch & Hạn mức nợ| WC & WH2
    WB -->|Biên chế nhân sự hiện trường| WA
    WB -->|Tài khoản SaaS & Quản lý Ca| WG
    WE -->|Chi phí tiêu hao & Sản lượng thực thu| WH1
    WG -->|Giờ công thực tế & Phân bổ lương| WH1

    style S_AUTH fill:#fef3c7,stroke:#d97706,stroke-width:2px
    style S_PLATFORM fill:#f1f5f9,stroke:#475569,stroke-width:2px
    style S_TENANT fill:#ecfdf5,stroke:#059669,stroke-width:2px
    style S_PUBLIC fill:#fee2e2,stroke:#dc2626,stroke-width:2px
```

---

## ĐIỀU 1: KIẾN TRÚC 4 TẦNG KHUNG GIAO DIỆN (4 APPLICATION SHELLS) & NGUYÊN TẮC CỐT LÕI

### 1.1. Bốn Shell Ứng Dụng Độc Lập (4 Application Shells)
Frontend được chia tách thành **4 Shell độc lập**, hoàn toàn cách ly về luồng xác thực, layout hiển thị và phạm vi phân quyền:

```
+-------------------------------------------------------------------------------------------------------+
|                                      KIẾN TRÚC 4 APPLICATION SHELLS                                    |
+-------------------------------------------------------------------------------------------------------+
|  1. AuthShell               | 2. PlatformShell             | 3. TenantAppShell         | 4. PublicTraceShell  |
|  - /login                   | - /platform/*                | - /app/*                  | - /trace/:code       |
|  - /force-change-password   | - Chỉ mở ROLE_SUPER_ADMIN    | - 6 Role của Tenant       | - Công khai 100%     |
|  - Token in-memory + Cookie | - Quản lý Tenant & Hợp đồng  | - TopBar + Sidebar Động   | - Đóng băng Snapshot |
|  - Cưỡng chế đổi mật khẩu   | - Ẩn 100% menu Farm Ops      | - Farm Context Switcher   | - Emergency Red Alert|
+-------------------------------------------------------------------------------------------------------+
```

#### 1.1.1. AuthShell (`/login`, `/force-change-password`)
*   **Mục đích:** Quản lý vòng đời xác thực, phiên truy cập và bảo mật sơ cấp.
*   **Cơ chế lưu trữ Token:**
    *   `access_token`: Lưu trữ độc quyền trong **in-memory Zustand store** (không bao giờ lưu vào `localStorage` hay `sessionStorage` để triệt tiêu nguy cơ tấn công XSS).
    *   `refresh_token`: Được Backend lưu trữ an toàn trong Database tại bảng `refresh_tokens` (#72) và chuyển giao qua **HttpOnly, Secure, SameSite Cookie**.
    *   Cơ chế **Silent Refresh Token Rotation**: Khi `access_token` sắp hết hạn hoặc nhận mã lỗi `401 Unauthorized`, Axios interceptor tự động kích hoạt `/api/v1/auth/refresh` lấy cặp token mới.
*   **Cưỡng chế đổi mật khẩu lần đầu (First-Login Guard):**
    *   Khi người dùng đăng nhập thành công, hệ thống kiểm tra trường `users.must_change_password` (#5).
    *   Nếu `must_change_password == true`: Router lập tức chặn đứng mọi chuyển hướng và **cưỡng chế điều hướng tới `/force-change-password`**. Người dùng không thể truy cập bất kỳ route nào khác thuộc hệ thống cho đến khi hoàn thành việc đổi mật khẩu mới (khớp regex bảo mật: tối thiểu 8 ký tự, gồm chữ hoa, chữ thường, số và ký tự đặc biệt). Sau khi đổi mật khẩu thành công, trường này được chuyển về `false`.

#### 1.1.2. PlatformShell (`/platform/*` - Dành riêng cho `ROLE_SUPER_ADMIN`)
*   **Mục đích:** Không gian quản trị tối cao dành riêng cho Quản trị viên nền tảng SaaS (`ROLE_SUPER_ADMIN`).
*   **Phân quyền kiểm soát:** Yêu cầu nghiêm ngặt quyền `PERM_TENANT_MANAGE`.
*   **Nghiệp vụ cốt lõi:**
    *   Quản lý danh mục Khách hàng thuê nền tảng (`tenants` #1): Mã định danh, tên công ty, subdomain, gói dịch vụ (`FREE`, `STARTER`, `PROFESSIONAL`, `ENTERPRISE`), trạng thái (`ACTIVE`, `SUSPENDED`, `INACTIVE`).
    *   Quản lý Gói dịch vụ & Hạn mức tài nguyên (`tenant_subscriptions` #2): Giới hạn số trang trại tối đa (`max_farms`), số tài khoản tối đa (`max_users`), thời hạn hợp đồng (`valid_from` $\rightarrow$ `valid_to`), kích hoạt/tạm dừng gói.
*   **Quy tắc cô lập giao diện:** **Tuyệt đối ẩn toàn bộ** menu vận hành trang trại (Workspace A $\rightarrow$ H2), thanh chuyển đổi trang trại TopBar, không tải bất kỳ state nào liên quan đến dữ liệu nông nghiệp nội bộ của Tenant.

#### 1.1.3. TenantAppShell (`/app/*` - Dành cho 6 Role Thuộc Tenant)
*   **Mục đích:** Khung ứng dụng làm việc hợp nhất dành cho 6 Vai trò người dùng thuộc Tenant trải dài từ Cấp 2 đến Cấp 4 (`ROLE_FARM_OWNER`, `ROLE_FARM_MANAGER`, `ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_ACCOUNTANT`, `ROLE_FIELD_STAFF`).
*   **TopBar Toàn Cục (Universal Global TopBar):**
    1.  `FarmContextSwitcher`: Dropdown chọn trang trại đang tác nghiệp. **Chỉ liệt kê các trang trại mà user hiện tại được cấp quyền** thông qua bảng `user_farm_access` (#12) (Đối với `ROLE_FARM_OWNER` hiển thị toàn bộ trang trại trong Tenant; đối với Farm Manager và Cấp 4 chỉ hiển thị trang trại phụ trách). Khi chọn trang trại, giá trị `activeFarmId` được lưu vào Zustand Store (`useFarmStore`) và đồng bộ lên URL search param `?farmId=...`.
    2.  `QuickScannerButton`: Nút quét mã vạch/QR toàn cục trên TopBar (Quét nhanh EAN-13, barcode thùng quy đổi, hoặc tra cứu mã Lô KCS).
    3.  `NotificationBell`: Nút chuông thông báo kết nối `notifications` (#71), hiển thị badge đỏ số tin chưa đọc.
*   **Dynamic Sidebar & Ma Trận Phân Quyền Không Gian Làm Việc (RBAC Sidebar Matrix):**
    *   Sidebar tự động kiểm tra vai trò và mảng 30 mã quyền (`permissions` #7) của người dùng hiện tại thông qua component bọc `<Can permission="...">`:
    *   **1. Giao diện Chủ trang trại / Chủ tịch HĐQT (`ROLE_FARM_OWNER`):**
        *   **Xóa bỏ hoàn toàn khỏi Sidebar:** `WS-E` (Bàn làm việc canh tác chi tiết) và `WS-G` (Chấm công cá nhân hàng ngày) để tập trung vào quản trị chiến lược chuỗi.
        *   **Chế độ Read-Only giám sát:** `WS-C` (Trung tâm kho bãi) và `WS-H` (Chi phí & Dòng tiền) chuyển sang chế độ Xem/Giám sát số liệu chuỗi, không hiển thị các nút thao tác lập chứng từ tác nghiệp.
        *   **Độc quyền các nút phê duyệt tối cao:** Nút duyệt hạn mức tín dụng đối tác (`creditLimit`), nút khóa đen đối tác vi phạm (`BLACKLISTED`), nút duyệt kế hoạch ngân sách (`budgets`), và nút ký xác nhận kết toán lợi nhuận chu kỳ (`Cycle Settlement`).
    *   **2. Giao diện Giám đốc / Quản lý trang trại (`ROLE_FARM_MANAGER`):**
        *   Trang bị đầy đủ **7 Workspace điều hành cơ sở**:
        *   `WS-A`: Không được tạo trang trại mới (`PERM_FARM_CREATE = ❌`), khi bấm `[+ Thêm Phân Khu]` thì phân khu mặc định ở trạng thái `MAINTENANCE` chờ Owner duyệt kích hoạt.
        *   `WS-B`: Tuyển dụng và phân quyền cho nhân sự Cấp 4 thuộc đúng `farmId` của trại.
        *   `WS-C`: Giám sát kho và đóng vai trò **Checker** phê duyệt các phiếu nhập/xuất/chuyển/kiểm kê do Thủ kho lập.
        *   `WS-D`: Quản lý đối tác trực tiếp giao dịch với trại.
        *   `WS-E`: Giám sát mùa vụ, kế hoạch đàn nuôi, kiểm tra nhật ký canh tác.
        *   `WS-F`: Trực tiếp ký duyệt chất lượng lô KCS (`PERM_QC_APPROVE`) và ban hành lệnh thu hồi (`PERM_QC_RECALL`).
        *   `WS-G`: Tự chấm công và duyệt bảng tổng hợp công tháng của toàn trại.
        *   `WS-H1 / H2`: Duyệt chi phí, duyệt đơn bán sỉ, và ký duyệt bảng kết toán chu kỳ (`Cycle Settlement`) trước khi chuyển hồ sơ lãi về cho Owner.
    *   **3. Giao diện Kỹ thuật & KCS (`ROLE_TECHNICAL_STAFF`):**
        *   Truy cập `WS-A` (xem mặt bằng), `WS-E` (**Maker**: lập kế hoạch vụ mùa, phác đồ thú y, giao việc kỹ thuật), `WS-F` (**Maker**: độc quyền lấy mẫu KCS `PERM_QC_INSPECT`, cấm tự duyệt), `WS-G` (chấm công cá nhân GPS và **Điểm danh tổ hiện trường 6B**).
    *   **4. Giao diện Thủ kho (`ROLE_WAREHOUSE_STAFF`):**
        *   Truy cập `WS-C` (**Maker**: lập phiếu nhập/xuất/chuyển/kiểm kê ở trạng thái `DRAFT`), `WS-F` (độc quyền in tem nhãn nhiệt dán thùng `PERM_LABEL_PRINT`), `WS-H2` (xuất hàng lên xe `PERM_DELIVERY_MANAGE`), `WS-G` (chấm công cá nhân GPS và **Điểm danh kho 6B**).
    *   **5. Giao diện Kế toán trang trại (`ROLE_ACCOUNTANT`):**
        *   Scope gán chặt chẽ tại `farmId`. Truy cập `WS-C` (đối chiếu sổ tồn kho Read-Only), `WS-D` (danh bạ đối tác), `WS-H1` (**Maker**: lập phiếu chi, phân bổ giá thành), `WS-H2` (**Maker**: lên đơn bán sỉ, lập phiếu thu chi VietQR, phân bổ công nợ FIFO), `WS-G` (tự chấm công cá nhân và xem bảng công đã chốt để hạch toán chi phí lương).
    *   **6. Giao diện Nhân viên hiện trường (`ROLE_FIELD_STAFF`):**
        *   Truy cập `WS-E` (xem lịch mùa vụ, nhập nhật ký chăm sóc, ghi sản lượng thu hoạch thực tế), `WS-G` (chấm công GPS 1 chạm, nhận nhiệm vụ và báo cáo tiến độ).

#### 1.1.4. PublicTraceShell (`/trace/:traceabilityCode` - Cổng Công Khai Không Cần Đăng Nhập)
*   **Mục đích:** Cổng thông tin tra cứu nguồn gốc nông sản công khai dành cho người tiêu dùng và đối tác thu mua thông qua quét mã QR in trên tem nhãn nhiệt (`label_print_logs` #50).
*   **Không yêu cầu xác thực:** Route hoàn toàn mở, không cần token hay cookie phiên.
*   **Hiển thị dữ liệu đóng băng bất biến (Immutable Snapshot):**
    *   Truy vấn trực tiếp từ bảng `traceability_snapshots` (#49) dựa theo `traceability_code`.
    *   Giải mã các trường JSON đóng băng tại thời điểm duyệt lô: `enterprise_info_json` (Hồ sơ DN, VietQR), `vietgap_cert_json` (Chứng chỉ an toàn), `farming_timeline_json` (Nhật ký canh tác, bón phân, phun thuốc, kiểm soát PHI), `harvest_info_json` (Ngày thu hoạch, sản lượng, quy cách), `qc_inspection_json` (Kết quả kiểm định chất lượng phòng lab/KCS).
    *   Hiển thị chữ ký số băm bảo mật `snapshot_hash` (SHA-256) đảm bảo tính toàn vẹn, chống làm giả thông tin nguồn gốc.
    *   Hệ thống Backend tự động tăng bộ đếm lượt quét `scan_count` và cập nhật thời điểm quét gần nhất `last_scanned_at`.
*   **Cơ chế Kích hoạt Cảnh báo Đỏ (Emergency Recall Alert):**
    *   Nếu lô hàng bị thu hồi (`product_batches.status == 'RECALLED'` #44):
    *   Hệ thống lập tức **chuyển toàn bộ giao diện sang màn hình Cảnh báo Nguy hiểm (Emergency Red Alert View)** với nền đỏ, biểu tượng cảnh báo nhấp nháy, hiển thị rõ ràng: *"CẢNH BÁO: LÔ NÔNG SẢN NÀY ĐÃ BỊ THU HỒI KHẨN CẤP TỪ NHÀ SẢN XUẤT"*, ghi rõ Lý do thu hồi (`product_batches.recall_reason`) và Thời điểm ban hành lệnh thu hồi (`product_batches.recalled_at`).

---

### 1.2. 6 Nguyên Tắc Thiết Kế UI Cốt Lõi (Core UI Principles)

1.  **Chống Phân Mảnh Giao Diện (The Anti-Siloed Principle):**
    *   Tuyệt đối cấm tạo các trang danh sách dạng bảng trơ trọi, cô lập buộc người dùng phải mở hàng loạt tab trình duyệt.
    *   Áp dụng chuẩn kiến trúc: **Master-Detail Split Screen** (cho quan hệ phân cấp địa lý và phân bổ giá thành); **Unified Slide-Over Drawer** (cho hồ sơ thực thể 360°); **Segmented Transaction Console** (cho chuỗi giao dịch kho, công nợ, bán hàng).
2.  **Điểm Tựa Dữ Liệu Đơn Nhất Trên Form (Single Source of Truth):**
    *   Mọi thao tác Tạo mới hoặc Chỉnh sửa toàn bộ thông tin xoay quanh một thực thể nghiệp vụ **bắt buộc nằm trên cùng một Modal hoặc Slide-Over Drawer**.
    *   Ví dụ: Thêm nhân viên mới $\rightarrow$ Form tích hợp đầy đủ thông tin lý lịch, hợp đồng, nút gạt Switch cấp tài khoản SaaS, gán Role RBAC và phân công phạm vi trang trại ngay trên cùng một form.
3.  **Thao Tác Nghiệp Vụ Liên Kết Nguyên Khối (Cross-Module Atomic Actions):**
    *   Một hành động thực tế tại nông trường kích hoạt chuỗi tác vụ liên hoàn:
        *   Ghi nhật ký bón phân/phun thuốc $\rightarrow$ Tự động sinh phiếu xuất kho tiêu hao (`warehouse_issues` loại `PRODUCTION_BACKFLUSH` #34) $\rightarrow$ Trừ tồn kho theo FEFO $\rightarrow$ Cập nhật sổ cái kho (#38) $\rightarrow$ Ghi nhận chi phí sản xuất trực tiếp (`farm_expenses` #60).
        *   Ghi nhận thu hoạch $\rightarrow$ Khởi tạo hồ sơ thu hoạch (`harvest_records` #43) $\rightarrow$ Kích hoạt tạo Lô thành phẩm chờ duyệt (`product_batches` #44) $\rightarrow$ Đóng gói chi phí sang Workspace H1 tính giá thành.
4.  **Bảo Toàn Ngữ Cảnh Tuyệt Đối (Context Preservation & Zero Cognitive Friction):**
    *   Ngữ cảnh hiện tại (`activeFarmId`, `activeZoneId`, `activeCycleId`) luôn được duy trì xuyên suốt trong URL query parameters và global store.
    *   Khi mở các Modal/Drawer thao tác con (thêm phân khu, gán nhân viên, ghi nhật ký, lập phiếu kho), hệ thống **bắt buộc tự động điền sẵn (pre-fill)** các khóa ngoại ngữ cảnh, không bắt người dùng phải chọn lại dropdown cha.
5.  **Phơi Bày Thông Tin Tịnh Tiến (Progressive Disclosure):**
    *   Bảng danh sách tổng quan chỉ hiển thị các trường nhận diện sống còn.
    *   Thông tin chi tiết chuyên sâu (tọa độ GPS, sơ đồ mặt bằng, biên lai ủy nhiệm chi, nhật ký audit, thành phần dinh dưỡng) chỉ hiển thị khi người dùng tương tác: click dòng, mở drawer chi tiết, hoặc hover tooltip.
6.  **Quy Chuẩn Nút Bấm An Toàn & Tự Sinh Mã Định Danh (Button & Auto-Code Standards):**
    *   **Component `Button.jsx` An Toàn Tuyệt Đối:**
        *   Tích hợp hàm bảo vệ `renderSafeIcon(icon)`: Ngăn ngừa 100% lỗi crash màn hình trắng khi truyền icon là Lucide React Component, JSX Element hoặc SVG không hợp lệ.
        *   Chống Double-Submit: Tích hợp cờ `isLoading`. Khi `isLoading = true`, nút bấm tự động chuyển sang trạng thái `disabled = true`, hiển thị Spinner quay tròn và chặn đứng mọi cú nhấp chuột liên tiếp gây trùng lặp giao dịch tài chính hoặc phiếu kho.
    *   **Quy Chuẩn Ô Mã Định Danh (Auto-Code Pattern):**
        *   Mọi ô nhập mã định danh (`code`, `skuCode`, `employeeCode`, `receiptCode`, `issueCode`, `batchCode`, `orderCode`...) tự động sinh theo mẫu chuẩn:
            $$\text{[TIỀN\_TỐ] - YYMM - XXXX}$$
            *(Ví dụ: `EMP-2610-0001`, `RCP-2610-0012`, `SO-2610-0005`)*.
        *   Khi Tạo Mới (Create): Ô mã hiển thị kèm nút bấm `[🔄 Tự sinh]` cho phép người dùng sinh mã tự động hoặc chỉnh sửa mã theo nhu cầu.
        *   Khi Chỉnh Sửa (Edit / Update): Ô mã định danh **BẮT BUỘC KHÓA CỨNG `readOnly={true}`** (nền xám nhẹ `bg-slate-100`, con trỏ `cursor-not-allowed`) để bảo toàn tính toàn vẹn khóa nghiệp vụ.

---

## ĐIỀU 2: QUY HOẠCH KHÔNG GIAN LÀM VIỆC HỢP NHẤT (WORKSPACES A -> H2)

Toàn bộ 72 bảng cơ sở dữ liệu và các luồng nghiệp vụ tương ứng được quy hoạch hoàn chỉnh vào **9 Workspace vận hành chuẩn mực**:

---

### 2.1. Workspace A: Quản Trị Mặt Bằng & Phân Công Hiện Trường (`WS-PRODUCTION-GEOGRAPHY`)
*   **Bảng SQL tích hợp:** `farms` (#11), `production_zones` (#13), `zone_locations` (#14), `farm_assignments` (#15).
*   **Mã quyền RBAC:** `PERM_FARM_VIEW`, `PERM_FARM_CREATE` (Độc quyền Owner), `PERM_FARM_UPDATE`, `PERM_ZONE_MANAGE`.
*   **Kiến trúc giao diện (Master-Detail Split-View):**
    *   **Cột trái (Master Geographic Tree):**
        *   Cây phân cấp địa lý 3 tầng: `Trang trại (Farm) -> Phân khu (Production Zone) -> Vị trí chi tiết (Zone Location)`.
        *   Bộ lọc nhanh theo loại hình trang trại (`farm_type`: `'CROP'`, `'LIVESTOCK'`, `'MIXED'`, `'AQUACULTURE'`) và loại phân khu (`zone_type`: `'GREENHOUSE'`, `'OPEN_FIELD'`, `'BARN'`, `'POND'`, `'STORAGE'`, `'ISOLATION'`).
        *   Nút bấm `[+ Thêm Trang Trại]`: **Chỉ hiển thị cho `ROLE_FARM_OWNER`**. Quản lý trang trại (`ROLE_FARM_MANAGER`) không có nút này.
        *   Nút bấm `[+ Thêm Phân Khu]`: Cho phép cả Owner và Farm Manager tạo phân khu. **Đặc biệt:** Khi `ROLE_FARM_MANAGER` tạo phân khu mới, hệ thống tự động gán trạng thái ban đầu là `'MAINTENANCE'` (Chờ Chủ trại phê duyệt kích hoạt sang `'ACTIVE'`).
    *   **Cột phải (Detail, Map & Staff Assignment Pane):**
        *   **Khi chọn Trang trại (`farms` #11):** Hiển thị mã `code`, tên `name`, loại hình `farm_type`, địa chỉ `address`, tọa độ GPS (`latitude`, `longitude`), tổng diện tích `total_area_m2`. Cấu hình bán kính hàng rào địa lý chấm công **`geofence_radius_m`** (mặc định 300 mét, ràng buộc `chk_farms_geofence > 0`). Trạng thái trang trại `status` (`'ACTIVE'`, `'INACTIVE'`, `'MAINTENANCE'`).
        *   **Khi chọn Phân khu (`production_zones` #13):** Hiển thị mã `code`, tên `name`, loại phân khu `zone_type`, diện tích `area_m2`, trạng thái (`'ACTIVE'`, `'FALLOW'`, `'QUARANTINE'`, `'MAINTENANCE'`), và trình xem/chỉnh sửa sơ đồ mặt bằng **`map_layout_json`** (tọa độ polygon GeoJSON).
        *   **Khi chọn Vị trí chi tiết (`zone_locations` #14):** Hiển thị mã vị trí `code`, tên vị trí `name`, mô tả `description`, trạng thái (`'ACTIVE'`, `'OCCUPIED'`, `'EMPTY'`, `'MAINTENANCE'`).
        *   **Panel Phân công Nhân sự Hiện trường (`farm_assignments` #15):**
            *   Hỗ trợ phân công nhân sự tại cả cấp Trang trại lẫn cấp Phân khu (`farm_assignments.zone_id`).
            *   Hiển thị danh sách cán bộ đang phụ trách tại chỗ. Nút `[+ Phân Công Nhân Sự]` mở modal gán nhân viên với các vai trò chuẩn SQL:
                `'FARM_MANAGER'`, `'ZONE_MANAGER'`, `'TECHNICAL_LEAD'`, `'AGRONOMIST'`, `'VETERINARIAN'`, `'WAREHOUSE_KEEPER'`, `'ACCOUNTANT'`, `'FIELD_WORKER'`.

```
+-------------------------------------------------------------------------------------------------------+
| WORKSPACE A: QUẢN TRỊ MẶT BẰNG & PHÂN CÔNG HIỆN TRƯỜNG                     [+ Thêm Phân Khu] [+ Gán Việc] |
+-------------------------------------------------------------------------------------------------------+
| CÂY MẶT BẰNG ĐỊA LÝ (Master Tree)     | CHI TIẾT PHÂN KHU & PHÂN CÔNG TẠI CHỖ (Detail Pane)           |
| v Trang trại Mộc Châu (F01 - MIXED)   | Phân khu: Nhà màng Dưa lưới N01 (ZONE-001)                    |
|   - Bán kính GPS: 300 m               | Loại: GREENHOUSE | Diện tích: 2,500 m2 | Trạng thái: ACTIVE   |
|   v Phân khu Trồng trọt:              | Sơ đồ mặt bằng (map_layout_json): Polygon GeoJSON [Đã nạp]    |
|     > Nhà màng N01 (GREENHOUSE) [x]   | ------------------------------------------------------------- |
|       - Luống 01 (L01 - OCCUPIED)     | VỊ TRÍ CHI TIẾT TRONG PHÂN KHU (zone_locations - 4 vị trí):  |
|       - Luống 02 (L02 - EMPTY)        | [ L01: Luống 1 (OCCUPIED) ] [ L02: Luống 2 (EMPTY) ]          |
|     > Ruộng Mở R01 (OPEN_FIELD)       | ------------------------------------------------------------- |
|   v Phân khu Chăn nuôi:               | NHÂN SỰ PHỤ TRÁCH TẠI CHỖ (farm_assignments):                 |
|     > Chuồng Bò Sữa C01 (BARN)        | 1. Trần Văn Nam | Vai trò: ZONE_MANAGER     | Từ: 01/01/2026  |
|     > Ao Cá Bác Hồ A01 (POND)         | 2. Lê Thị Mai   | Vai trò: AGRONOMIST       | Từ: 15/01/2026  |
|                                       | [+ Phân Công Cán Bộ Mới]  [ Chỉnh Sửa Sơ Đồ GeoJSON ]         |
+-------------------------------------------------------------------------------------------------------+
```

---

### 2.2. Workspace B: Hồ Sơ Nhân Sự 360° & Tài Khoản SaaS (`WS-HR-PERSONNEL-360`)
*   **Bảng SQL tích hợp:** `employees` (#51), `users` (#5), `user_roles` (#8), `user_farm_access` (#12), `roles` (#6).
*   **Mã quyền RBAC:** `PERM_HR_EMPLOYEE_MANAGE` (Owner quản lý Cấp 3; Farm Manager quản lý Cấp 4 tại trại).
*   **Kiến trúc giao diện (Slide-Over Drawer Đa Tab):**
    *   **Bảng danh sách tổng quan:** Hiển thị mã nhân viên `employee_code`, họ tên `full_name`, số điện thoại `phone`, email `email`, vị trí công việc `position`, phân loại lao động (6A / 6B), ngày vào làm `joined_date`, trạng thái lao động `status` (`'ACTIVE'`, `'ON_LEAVE'`, `'RESIGNED'`, `'TERMINATED'`).
    *   **Quy Chuẩn Form Tiếp Nhận & Hồ Sơ Nhân Viên (Employee Profile Form):**
        *   **BỎ HOÀN TOÀN Ô "Phòng Ban / Bộ Phận" (`department`):** Không hiển thị ô department trên giao diện. Backend Service tự động suy diễn ngầm giá trị phòng ban từ trường `position` (Ví dụ: `position = 'AGRONOMIST'` $\rightarrow$ Kỹ thuật; `position = 'WAREHOUSE_KEEPER'` $\rightarrow$ Kho vận).
        *   **Bắt buộc điền đầy đủ thông tin định danh (`*` Mandatory Fields):**
            *   Họ và tên (`full_name *`): Bắt buộc.
            *   Số CCCD / Định danh cá nhân (`id_card_number *`): Bắt buộc, kiểm tra Regex chuẩn 12 chữ số (`^[0-9]{12}$`).
            *   Số điện thoại (`phone *`): Bắt buộc, kiểm tra Regex chuẩn 10 chữ số bắt đầu bằng đầu số Việt Nam (`^(03|05|07|08|09)[0-9]{8}$`).
            *   Địa chỉ Email (`email *`): Bắt buộc, kiểm tra Regex định dạng thư điện tử RFC 5322.
            *   Ngày sinh (`date_of_birth`), Ngày vào làm (`joined_date *`), Loại hợp đồng (`contract_type *`), Mức lương cơ sở (`base_salary`), Hạn mức phép năm (`annual_leave_quota`).
        *   **Phân Tách Rõ Ràng Hai Nhóm Nhân Sự (6A vs 6B):**
            *   **Nhóm 6A - Nhân sự Biên chế / Chuyên môn (Có tài khoản SaaS):** Kỹ sư, thủ kho, kế toán, quản lý. Được cấp tài khoản SaaS (`users`), đăng nhập hệ thống, sử dụng Web / Mobile App Workspace G để Check-in/Check-out GPS + Selfie cá nhân và nhận/báo cáo nhiệm vụ hàng ngày.
            *   **Nhóm 6B - Lao động Thời vụ / Công nhật (Không có tài khoản SaaS):** Nhân công bốc vác, làm cỏ, thu hái thời vụ, dọn dẹp vệ sinh. Không cấp tài khoản SaaS. Hàng ngày được Trưởng phân khu (`ROLE_TECHNICAL_STAFF`) hoặc Thủ kho (`ROLE_WAREHOUSE_STAFF`) thực hiện **Điểm danh tổ tập thể (`batch roll-call`)** bằng chụp ảnh hiện trường + GPS thông qua API `POST /api/v1/hr/attendance/batch-roll-call`.
    *   **Tab 2 - Cấp Tài Khoản SaaS & Phân Quyền Theo Cấp Bậc (Hierarchical Provisioning):**
        *   Nút gạt Switch: `[ Cấp tài khoản truy cập hệ thống SaaS ]` (Chỉ mở cho nhân sự Nhóm 6A).
        *   Tự động khởi tạo `username` (ưu tiên SĐT hoặc email), cờ `must_change_password = true`.
        *   **Chốt chặn phân quyền theo cấp bậc:**
            *   Nếu người thực hiện là `ROLE_FARM_OWNER`: Chỉ được gán vai trò Cấp 3 `ROLE_FARM_MANAGER` cho các trang trại.
            *   Nếu người thực hiện là `ROLE_FARM_MANAGER`: Chỉ được gán các vai trò Cấp 4 (`ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_ACCOUNTANT`, `ROLE_FIELD_STAFF`) thuộc đúng `farmId` của trang trại mình quản lý.
    *   **Tab 3 - Bảng Tổng Hợp Công & Lương (Labor Ledger):**
        *   Tổng hợp dữ liệu công thực tế từ `time_attendances` (#54): Số ngày công chuẩn, tổng giờ làm, giờ đi muộn/về sớm, giờ tăng ca OT đã duyệt (`overtime_requests` #56), và quỹ phép năm còn lại (`leave_requests` #55).

---

### 2.3. Workspace C: Trung Tâm Giao Dịch Kho & Quét Đa Mã Vạch (`WS-INVENTORY-TRANSACTION-HUB`)
*   **Bảng SQL tích hợp:** `warehouse_receipts` (#32), `warehouse_receipt_items` (#33), `warehouse_issues` (#34), `warehouse_issue_items` (#35), `warehouse_transfers` (#36), `warehouse_transfer_items` (#37), `stocktakes` (#39), `stocktake_items` (#40), `warehouse_inventory` (#31), `warehouse_inventory_transactions` (#38).
*   **Mã quyền RBAC:** `PERM_INVENTORY_VIEW`, `PERM_INVENTORY_RECEIPT`, `PERM_INVENTORY_ISSUE`, `PERM_INVENTORY_TRANSFER`, `PERM_INVENTORY_STOCKTAKE`.
*   **Kiến trúc giao diện (Unified Transaction Console):**
    *   **Thanh chuyển Tab nghiệp vụ:** `[ Phiếu Nhập Kho ] | [ Phiếu Xuất Kho ] | [ Điều Chuyển Kho ] | [ Kiểm Kê Kho ] | [ Sổ Tồn Kho Thời Gian Thực ]`.
    *   **Nút tác vụ Split-Button `[+ Tạo Giao Dịch Kho v]`:**
        *   `[ Nhập Mua Từ Nhà Cung Cấp ]` (`receipt_type = 'PURCHASE'`)
        *   `[ Nhập Thu Hồi Nông Sản / Trả Hàng ]` (`receipt_type = 'HARVEST_RETURN'`)
        *   `[ Nhập Điều Chuyển Nội Bộ ]` (`receipt_type = 'INTERNAL_TRANSFER'`)
        *   `[ Nhập Điều Chỉnh Kiểm Kê ]` (`receipt_type = 'ADJUSTMENT'`)
        *   `[ Xuất Tiêu Hao Tự Động ]` (`issue_type = 'PRODUCTION_BACKFLUSH'`)
        *   `[ Xuất Sử Dụng Nội Bộ ]` (`issue_type = 'INTERNAL_USE'`)
        *   `[ Xuất Bán Giao Hàng ]` (`issue_type = 'SALE_FULFILLMENT'`)
        *   `[ Xuất Hủy Hư Hỏng ]` (`issue_type = 'DAMAGE_DISPOSAL'`)
        *   `[ Xuất Điều Chuyển Kho ]` (`issue_type = 'TRANSFER'`)
        *   `[ Mở Đợt Kiểm Kê ]` (`stocktakes`)
    *   **Cơ chế Quét Đa Mã Vạch (Multi-Barcode Engine):**
        *   Trên form nhập/xuất/kiểm kê, trường quét mã vạch chấp nhận 3 loại mã:
            1.  **Mã vạch đơn vị chuẩn (`materials.barcode` #28):** Tự động nhận diện mặt hàng, điền đơn vị chuẩn **`standard_unit`**, hệ số quy đổi `conversion_factor = 1.0000`.
            2.  **Mã vạch thùng/bao lớn (`material_unit_conversions.unit_barcode` #29):** Tự động chọn đơn vị nhập `entered_unit = unit_name`, điền hệ số quy đổi `conversion_factor`, và khi nhập số thùng `entered_quantity`, hệ thống tự tính số lượng chuẩn:
                $$\text{quantity} = \text{entered\_quantity} \times \text{conversion\_factor}$$
            3.  **Mã vạch lô nội bộ (`warehouse_inventory.internal_batch_barcode` #31):** Tự động định vị chính xác vị trí lô, hạn sử dụng và ngày sản xuất `manufacture_date` trong kho.
    *   **Luồng Nhập Mua Tự Sinh Công Nợ NCC:**
        *   Khi lập phiếu nhập mua (`receipt_type = 'PURCHASE'`), bắt buộc chọn Nhà cung cấp (`partner_id` lọc đối tác loại `SUPPLIER` hoặc `AGENT` từ bảng `partners` #4).
        *   Khi phiếu nhập được phê duyệt (`approved_by`, `approved_at`), hệ thống tự động sinh một bản ghi công nợ phải trả trong `debt_records` (#66) với `debt_type = 'PAYABLE'`, liên kết khóa ngoại **`warehouse_receipt_id`**, tổng nợ `total_debt = warehouse_receipts.total_amount`, dư nợ `remaining_debt = total_debt`, trạng thái `status = 'ACTIVE'`, sẵn sàng cho việc lập kế hoạch thanh toán VietQR tại Workspace H2.
    *   **Cơ Chế Phê Duyệt 2 Bước Maker - Checker (Draft -> Approved):**
        *   Tất cả phiếu nhập (`warehouse_receipts`), phiếu xuất (`warehouse_issues`), phiếu chuyển (`warehouse_transfers`), và phiếu kiểm kê (`stocktakes`) được tạo bởi **Maker (`ROLE_WAREHOUSE_STAFF`)** ở trạng thái ban đầu là `DRAFT`.
        *   Chỉ khi **Checker (`ROLE_FARM_MANAGER`)** thẩm định số liệu và bấm `[ Phê Duyệt & Xuất/Nhập Kho ]`, hệ thống mới ghi nhận `approved_by` và `approved_at`, đồng thời ghi vào Sổ cái biến động kho thống nhất (`warehouse_inventory_transactions` #38) và cập nhật số lượng tồn khả dụng trong `warehouse_inventory` (#31).
        *   `ROLE_FARM_OWNER` và `ROLE_ACCOUNTANT` chỉ theo dõi sổ tồn kho thời gian thực ở chế độ Read-Only, không tham gia lập hay duyệt phiếu kho tác nghiệp.

---

### 2.4. Workspace D: Sổ Danh Bạ Đối Tác & Tài Khoản VietQR (`WS-ORGANIZATION-PARTNERS`)
*   **Bảng SQL tích hợp:** `partners` (#4).
*   **Mã quyền RBAC:** `PERM_FINANCE_SALES_ORDER`, `PERM_FINANCE_PAYMENT`.
*   **Kiến trúc giao diện (Tabbed Directory Console):**
    *   **Thanh lọc phân loại đối tác:** `[ Tất Cả ] | [ Nhà Cung Cấp (SUPPLIER) ] | [ Khách Hàng / Thương Lái (BUYER) ] | [ Đơn Vị Vận Chuyển (LOGISTICS) ] | [ Đại Lý Hai Chiều (AGENT) ]`.
    *   **Thẻ tóm tắt đối tác:** Hiển thị tức thời Dư nợ hiện hành, Xếp hạng tín nhiệm `credit_rating`, Hạn mức tín dụng tối đa `credit_limit`, và Số ngày nợ mặc định `payment_term_days`.
    *   **Form Quản lý Đối tác Hợp nhất (`PartnerFormModal`):**
        *   Thông tin pháp lý & liên hệ: Mã đối tác `code`, tên đối tác `name`, mã số thuế **`tax_code`**, xếp hạng tín nhiệm **`credit_rating`**, người liên hệ, SĐT `phone`, email `email`, địa chỉ `address`, trạng thái **`status`** (`'ACTIVE'`, `'INACTIVE'`, `'BLACKLISTED'`).
        *   Chính sách tín dụng & công nợ:
            *   Hạn mức công nợ tối đa **`credit_limit`** (DECIMAL 14,2).
            *   Thời hạn thanh toán mặc định **`payment_term_days`** (Số ngày được nợ).
            *   Ràng buộc toàn vẹn `chk_partners_credit CHECK (credit_limit >= 0.00 AND payment_term_days >= 0)`.
        *   Cấu trúc tài khoản ngân hàng chuẩn Napas247 (Phục vụ sinh mã VietQR tự động):
            *   Mã BIN ngân hàng **`bank_bin`** (Mã 6 chữ số chuẩn Napas, ví dụ `970422` - MBBank, `970436` - Vietcombank).
            *   Tên ngân hàng **`bank_name`**.
            *   Số tài khoản ngân hàng **`bank_account_no`**.
            *   Tên chủ tài khoản thụ hưởng **`bank_account_name`** (Viết hoa không dấu).

---

### 2.5. Workspace E: Bàn Làm Việc Canh Tác & Chăn Nuôi Hiện Trường Liền Mạch (`WS-FARMING-OPERATIONS`)
*   **Bảng SQL tích hợp:** `crop_seasons` (#19), `farming_logs` (#20), `farming_log_supplies` (#41), `livestock_groups` (#22), `livestock_individuals` (#23), `livestock_weight_logs` (#24), `livestock_events` (#25), `livestock_event_supplies` (#42), `harvest_records` (#43), `product_batches` (#44).
*   **Mã quyền RBAC:** `PERM_CROP_VIEW`, `PERM_CROP_PLAN`, `PERM_CROP_LOG`, `PERM_LIVESTOCK_VIEW`, `PERM_LIVESTOCK_MANAGE`, `PERM_LIVESTOCK_VET`, `PERM_HARVEST_MANAGE`.
*   **Kiến trúc giao diện (Cross-Sector Field Console):**
    *   **Thanh Gạt Chuyển Đổi Lĩnh Vực Tối Thượng (Sector Switcher):**
        Nằm cố định trên thanh công cụ: `[ 🌾 TRỒNG TRỌT ]` $\longleftrightarrow$ `[ 🐄 CHĂN NUÔI ]`.
    *   **Cột Master (Bên Trái) - Đối Tượng Sản Xuất Đang Hoạt Động:**
        *   **Ở chế độ Trồng trọt:** Danh sách các **Mùa vụ canh tác (`crop_seasons` #19)** được nhóm theo Chu kỳ vận hành `operational_cycle_id` (#16) và Phân khu `zone_id` (#13). Hiển thị tên mùa vụ, giống cây trồng (`crop_types` #18), ngày gieo trồng `start_date`, dự kiến thu hoạch `expected_harvest_date`, ngày thu hoạch thực tế `actual_harvest_date`, diện tích gieo trồng **`planted_area_m2`**, lượng giống `seed_quantity`, sản lượng ước tính `estimated_yield_kg`, sản lượng thực tế `actual_yield_kg`, và trạng thái mùa vụ:
            `'SOIL_PREPARATION'` $\rightarrow$ `'SOWING'` $\rightarrow$ `'GROWING'` $\rightarrow$ `'HARVESTING'` $\rightarrow$ `'CLOSED'`, `'CANCELLED'`.
        *   **Ở chế độ Chăn nuôi:** Danh sách các **Đàn/Lứa nuôi (`livestock_groups` #22)** hoặc **Cá thể RFID (`livestock_individuals` #23)**. Hiển thị mã đàn/mã thẻ tai, giống vật nuôi (`livestock_breeds` #21), ngày nhập đàn, số lượng con hiện tại `current_quantity`, phân khu chuồng nuôi `zone_id`, và trạng thái:
            `'ACTIVE'` $\rightarrow$ `'QUARANTINED'` $\rightarrow$ `'SOLD'` $\rightarrow$ `'CULLED'`.
    *   **Cột Detail (Bên Phải) - 4 Tab Tác Nghiệp Hiện Trường Liên Hoàn:**
        *   **Tab 1 - Tiến Độ & Cảnh Báo An Toàn Sinh Học (PHI / Withdrawal):**
            *   Thông tin tổng quan: Biểu đồ thời gian sinh trưởng, diện tích gieo trồng `planted_area_m2` hoặc số đầu con.
            *   Chỉ báo an toàn thời gian cách ly thuốc BVTV (**`farming_logs.phi_end_date`**) hoặc thời gian ngưng thuốc thú y (**`withdrawal_end_date`**). Nếu ngày hiện tại chưa vượt qua `phi_end_date`, hệ thống bật huy hiệu cảnh báo ĐỎ: *"Đang trong thời gian cách ly an toàn (Còn X ngày). Nghiêm cấm thu hoạch!"*.
        *   **Tab 2 - Nhật Ký Hiện Trường & Tiêu Hao Tự Động (Auto-Backflushing):**
            *   *Trồng trọt:* Nhật ký canh tác (`farming_logs` #20) kết hợp vật tư sử dụng (`farming_log_supplies` #41). Hỗ trợ các loại hoạt động **`activity_type`** đúng 7 giá trị SQL:
                `'SOIL_TILLAGE'`, `'IRRIGATION'`, `'FERTILIZATION'`, `'PESTICIDE_APPLICATION'`, `'PRUNING'`, `'WEEDING'`, `'HARVESTING'`. Nhập số ngày cách ly `phi_days` (tự động gợi ý từ `materials.default_phi_days` #28) và ngày kết thúc cách ly `phi_end_date`.
            *   *Chăn nuôi:* Sự kiện thú y & dinh dưỡng (`livestock_events` #25) kết hợp thức ăn/thuốc thú y tiêu hao (`livestock_event_supplies` #42). Hỗ trợ các loại sự kiện **`event_type`** đúng 7 giá trị SQL:
                `'VACCINATION'`, `'WEIGHT_CHECK'`, `'BREEDING'`, `'BIRTH'`, `'MEDICAL_TREATMENT'`, `'TRANSFER'`, `'SLAUGHTER'`. Nhập số ngày cách ly `withdrawal_days` và ngày kết thúc cách ly `withdrawal_end_date`.
            *   **Cơ chế Auto-Backflushing nguyên tử:** Khi nhấn `[ Lưu Nhật Ký ]`, Backend tự động kích hoạt tạo Phiếu xuất kho (`warehouse_issues` #34 với `issue_type = 'PRODUCTION_BACKFLUSH'`), tự động trừ tồn kho theo nguyên tắc FEFO và hạch toán một bút toán chi phí sản xuất trực tiếp vào `farm_expenses` (#60) với `expense_source = 'INVENTORY_BACKFLUSH'` trong cùng một Database Transaction.
        *   **Tab 3 (Dành riêng Chăn nuôi) - Lịch Sử Cân Nặng & Tăng Trưởng (`livestock_weight_logs` #24):**
            *   Biểu đồ đường theo dõi tăng trọng cá thể/đàn qua các mốc thời gian: Ngày cân, cân nặng thực tế `weight_kg`, tốc độ tăng trọng bình quân ngày (ADG - Average Daily Gain), so sánh với đường cong tăng trưởng chuẩn của giống (`livestock_breeds.target_weight_kg` #21).
        *   **Tab 4 - Ghi Nhận Thu Hoạch / Xuất Chuồng & Chuyển Giao Lô KCS (`harvest_records` #43):**
            *   Form thu hoạch: Ngày thu hoạch `harvest_date`, sản lượng thực thu `quantity`, đơn vị đo `unit`, chất lượng phân loại **`quality_grade`** đúng 4 giá trị SQL:
                `'GRADE_A'`, `'GRADE_B'`, `'STANDARD'`, `'REJECT'`. Người thu hoạch ghi nhận bằng **`harvested_by_user_id`** (khóa ngoại `users.id`).
            *   **Kiểm soát chốt chặn an toàn (PHI Guard):** Nếu phân khu đang trong thời gian cách ly `phi_end_date`, nút `[ Ghi Nhận Thu Hoạch ]` bị khóa cứng (`disabled`).
            *   **Nút Chuyển Giao Tức Thì `[ Lưu & Khởi Tạo Lô Thành Phẩm (3.9) ]`:** Tự động tạo bản ghi thu hoạch trong `harvest_records` (#43), đồng thời chuyển thẳng thông tin sang **Workspace F để tạo Lô thành phẩm (`product_batches` #44)** và kết chuyển sản lượng sang **Workspace H1 để phục vụ tính giá thành đơn vị**.

```
+-------------------------------------------------------------------------------------------------------+
| WORKSPACE E: BÀN LÀM VIỆC CANH TÁC & HIỆN TRƯỜNG        [ Lĩnh Vực: (•) TRỒNG TRỌT   ( ) CHĂN NUÔI ]  |
+-------------------------------------------------------------------------------------------------------+
| MÙA VỤ ĐANG CHẠY (Master Column)      | CHI TIẾT TÁC NGHIỆP HIỆN TRƯỜNG (4 Tabs Pane)                  |
| [ Lọc: Trang trại F01 | Chu kỳ 2026 ] | Vụ: Dưa lưới Vụ Thu 2026 (CROP-2026-01) | Giống: Dưa lưới TL3 |
| > Vụ Dưa lưới Mùa Thu 2026 [Đang chọn]| [ TAB 1: TIẾN ĐỘ ] [ TAB 2: NHẬT KÝ ] [ TAB 4: THU HOẠCH ]    |
|   - Phân khu: Nhà màng N01            | ------------------------------------------------------------- |
|   - Diện tích: 2,500 m2 (planted_area_m2)| Lịch sử Nhật ký Canh tác & Tiêu hao (farming_logs):        |
|   - Trạng thái: GROWING               | Ngày       | Hoạt động          | Vật tư tiêu hao (Auto-Backflush)|
|   - Bắt đầu: 15/08/2026               | 18/10/2026 | FERTILIZATION      | NPK Haifa 15-15-15 (25 kg)      |
|   - Dự kiến thu: 25/10/2026           | 15/10/2026 | PESTICIDE_APPLICATION | Radiant 60SC (2 gói - PHI: 7d)  |
| > Vụ Cà chua Cherry Vụ Đông 2026      |            | [!] CẢNH BÁO PHI: An toàn sau ngày 22/10/2026!  |
|   - Phân khu: Nhà màng N02            | ------------------------------------------------------------- |
|   - Trạng thái: SOWING                | [+ Ghi Nhật Ký & Xuất Vật Tư]    [+ GHI NHẬN THU HOẠCH (43)]  |
+-------------------------------------------------------------------------------------------------------+
```

---

### 2.6. Workspace F: Đường Ống Quản Trị Chất Lượng & Truy Xuất Nguồn Gốc (`WS-QA-TRACEABILITY-PIPELINE`)
*   **Bảng SQL tích hợp:** `product_batches` (#44), `product_batch_sources` (#45), `qc_inspections` (#46), `qc_inspection_items` (#47), `product_batch_transactions` (#48), `traceability_snapshots` (#49), `label_print_logs` (#50).
*   **Mã quyền RBAC:** `PERM_QC_INSPECT`, `PERM_QC_APPROVE`, `PERM_QC_RECALL`, `PERM_LABEL_PRINT`.
*   **Kiến trúc giao diện (Visual Kanban Pipeline & Slide-Over Batch Drawer):**
    *   **Bảng Kanban 6 Cột Khớp 100% Trạng Thái SQL (`product_batches.status` #44):**
        1.  `[ CỘT 1: CHỜ PHÊ DUYỆT (PENDING_APPROVAL) ]`: Các lô mới tạo từ thu hoạch (`harvest_records` #43) hoặc phối trộn đa nguồn (`product_batch_sources` #45).
        2.  `[ CỘT 2: SẴN SÀNG IN TEM (READY_TO_PRINT) ]`: Các lô đã được KCS kiểm định đạt chuẩn (**`qc_inspections.overall_result = 'PASSED'`**), hệ thống đã đóng băng hồ sơ vào `traceability_snapshots` (#49) và sinh mã truy xuất công khai `traceability_code`.
        3.  `[ CỘT 3: ĐÃ IN TEM NHÃN (PRINTED) ]`: Đã thực hiện in tem nhãn nhiệt ESC/POS dán lên thùng/hộp, ghi nhận nhật ký vào `label_print_logs` (#50).
        4.  `[ CỘT 4: ĐANG XUẤT BÁN (SELLING) ]`: Lô hàng đã nhập vào kho thành phẩm (`HARVESTED_PRODUCE` hoặc `COLD_STORAGE`), sẵn sàng cho việc lên đơn bán sỉ tại Workspace H2.
        5.  `[ CỘT NGOẠI LỆ 1: TỪ CHỐI (REJECTED) ]`: Lô kiểm định KCS không đạt, bị trả lại hoặc hủy bỏ.
        6.  `[ CỘT NGOẠI LỆ 2: THU HỒI KHẨN CẤP (RECALLED) ]`: Lô hàng bị phát hiện sự cố an toàn sau khi bán, kích hoạt lệnh thu hồi với lý do `recall_reason` và thời gian `recalled_at`.
    *   **Chốt An Toàn Phần Cứng (Hardware Guard):**
        *   Nút `[ In Tem Nhãn Nhiệt ]` chỉ mở khóa khi lô hàng ở trạng thái `READY_TO_PRINT` hoặc `PRINTED`.
        *   Tự động khóa cứng chức năng in tem nếu lô hàng chưa có biên bản KCS đạt chuẩn `PASSED` hoặc phát hiện vi phạm thời gian cách ly thuốc BVTV (PHI).
    *   **Slide-Over Drawer Chi Tiết Lô Thành Phẩm 360°:**
        *   *Thông số kho:* Kho lưu trữ (`warehouses` #26 loại `HARVESTED_PRODUCE` hoặc `COLD_STORAGE`), số lượng ban đầu `initial_quantity`, tồn kho thực tế `remaining_quantity`, số lượng đã giữ chỗ cho đơn bán **`reserved_quantity`** (kiểm tra `remaining_quantity >= reserved_quantity`), mã vạch thương phẩm quốc tế **`gtin_barcode`**, điều kiện bảo quản **`storage_conditions`**.
        *   *Bảng nguồn gốc phối trộn (`product_batch_sources` #45):* Liệt kê chi tiết tỷ lệ % sản lượng đóng góp từ các đợt thu hoạch hoặc các lô thành phẩm mẹ khác.
        *   *Lịch sử kiểm định KCS (`qc_inspections` #46 & `qc_inspection_items` #47):* Kết quả tổng thể **`overall_result`** (`'PENDING'`, `'PASSED'`, `'REJECTED'`, `'CONDITIONAL'`), điểm số kiểm định, danh sách chỉ tiêu (dư lượng nitrat, độ ngọt Brix, sâu bệnh, cảm quan), ảnh chụp mẫu kiểm định, kết luận của KCS.
        *   *Thẻ kho thành phẩm (`product_batch_transactions` #48):* Nhật ký biến động xuất nhập đóng gói, giữ chỗ đơn bán, xuất giao hàng theo thời gian thực.
        *   *Bản chụp đóng băng Traceability Snapshot (`traceability_snapshots` #49):* Xem trước giao diện người tiêu dùng sẽ nhìn thấy khi quét QR, hiển thị mã băm toàn vẹn `snapshot_hash` và thống kê số lượt quét `scan_count`.

---

### 2.7. Workspace G: Cổng Thông Tin Nhân Viên, Chấm Công GPS/Selfie & Vận Hành Hàng Ngày (`WS-EMPLOYEE-DAILY-OPS`)
*   **Bảng SQL tích hợp:** `time_attendances` (#54), `work_shifts` (#52), `shift_assignments` (#53), `farm_tasks` (#57), `farm_task_assignees` (#58), `leave_requests` (#55), `overtime_requests` (#56), `employees` (#51).
*   **Mã quyền RBAC:** `PERM_HR_ATTENDANCE`, `PERM_TASK_ASSIGN`.
*   **Kiến trúc giao diện (Mobile-First Personalized My Dashboard):**
    *   **Khối Chấm Công GPS & Selfie 2 Đầu Thông Minh (One-Tap Smart Timekeeping):**
        *   Thiết kế 2 nút hành động lớn: `[ CHẤM CÔNG VÀO CA (CHECK-IN) ]` và `[ CHẤM CÔNG HẾT CA (CHECK-OUT) ]`.
        *   *Xác thực không gian (Geofencing Guard):* Tự động lấy tọa độ GPS từ trình duyệt/di động. Tính khoảng cách đường chim bay Haversine tới tâm trang trại (`farms.latitude`, `farms.longitude`). Nếu khoảng cách vượt quá bán kính quy định **`farms.geofence_radius_m`**, giao diện cảnh báo đỏ: *"Bạn đang ở ngoài ranh giới trang trại (Khoảng cách: X mét, Giới hạn: Y mét)"* và yêu cầu nhập lý do bất khả kháng.
        *   *Xác thực hình ảnh 2 chiều:* Bật camera trước chụp ảnh selfie hiện trường: **`check_in_photo_url`** lúc vào ca và **`check_out_photo_url`** lúc tan ca.
        *   *Tự động tính toán công & phạt vi phạm:* Tự động tính số giờ làm việc thực tế **`working_hours`**, số phút đi muộn **`late_minutes`** (so với `work_shifts.start_time` cộng số phút ân hạn cho phép **`grace_late_minutes`**), số phút về sớm **`early_leave_minutes`** (so với `work_shifts.end_time`), tự động trừ thời gian nghỉ giữa ca **`break_minutes`**. Ghi nhận thông tin thiết bị **`device_info`** để chống gian lận chấm công.
    *   **Bảng Nhiệm Vụ Hiện Trường Cá Nhân (Personal Task Kanban):**
        *   Hiển thị các công việc được giao từ bảng `farm_tasks` (#57) và `farm_task_assignees` (#58).
        *   Các cột tiến độ theo chuẩn SQL **`status`**: `'TODO'` $\rightarrow$ `'IN_PROGRESS'` $\rightarrow$ `'PENDING_REVIEW'` $\rightarrow$ `'DONE'` (và `'CANCELLED'`).
        *   Phân loại công việc theo chuẩn SQL **`task_type`**: `'PLANTING'`, `'FERTILIZING'`, `'HARVESTING'`, `'FEEDING'`, `'MAINTENANCE'`, `'SANITATION'`.
        *   Mức độ ưu tiên chuẩn SQL **`priority`**: `'LOW'`, `'MEDIUM'`, `'HIGH'`, `'URGENT'`.
        *   Cho phép công nhân bấm nhận việc, ghi nhận tiến độ, đính kèm ảnh chụp hiện trường hoàn thành `photos_json`.
    *   **Khối Lịch Ca & Nộp Đơn Phép / Tăng Ca:**
        *   Lịch ca làm việc trong tuần theo phân ca từ `shift_assignments` (#53).
        *   Hiển thị quỹ phép năm còn lại từ `employees.annual_leave_quota` (#51).
        *   Modal nộp đơn xin nghỉ phép (`leave_requests` #55) và đơn đăng ký tăng ca (`overtime_requests` #56), tự động gửi thông báo (`notifications` #71) đến Quản lý trang trại để phê duyệt trực tiếp.

---

### 2.8. Workspace H1: Quản Trị Giá Thành & Phân Bổ Chi Phí Sản Xuất (`WS-COST-ACCOUNTING-ALLOCATION`)
*   **Bảng SQL tích hợp:** `farm_expenses` (#60), `cost_allocations` (#61), `cost_categories` (#59), `budgets` (#69), `budget_line_items` (#70), `harvest_records` (#43).
*   **Mã quyền RBAC:** `PERM_FINANCE_EXPENSE`, `PERM_FINANCE_REPORT`.
*   **Kiến trúc giao diện (Master-Detail Split-View Cost Accounting Console):**
    *   **Cột trái (Master Expense Ledger - Sổ Tập Hợp Chi Phí):**
        *   Tập hợp toàn bộ chi phí vận hành từ **4 nguồn dữ liệu chuẩn mực**:
            1.  `'MANUAL'`: Hóa đơn chi phí mua ngoài, tiếp khách, sửa chữa máy móc nhập thủ công.
            2.  `'INVENTORY_BACKFLUSH'`: Chi phí vật tư, phân bón, thuốc BVTV, thức ăn chăn nuôi tự động kết chuyển từ các phiếu xuất kho tiêu hao tại Workspace E.
            3.  `'PAYROLL_ALLOCATION'`: Chi phí nhân công trực tiếp được phân bổ tự động dựa trên số giờ làm việc thực tế từ chấm công Workspace G.
            4.  `'UTILITY_BILL'`: Chi phí điện, nước, xăng dầu vận hành trạm bơm, nhà màng.
        *   Bộ lọc đa chiều: Theo Khoản mục chi phí (`cost_categories` #59 với 5 loại `cost_type`: `'MATERIALS'`, `'DIRECT_LABOR'`, `'MACHINERY_FUEL'`, `'DEPRECIATION'`, `'INDIRECT_OVERHEAD'`), theo trạng thái phân bổ (`is_allocated = false`), theo khoảng thời gian phát sinh.
    *   **Cột phải (Detail Allocation & Unit Cost Pane - Bàn Phân Bổ & Tính Giá Thành):**
        *   **Bàn phân bổ chi phí đa đối tượng (`cost_allocations` #61):**
            *   Cho phép chọn đối tượng chịu chi phí: Mùa vụ trồng trọt (`CROP_SEASON` #19), Đàn vật nuôi (`LIVESTOCK_GROUP` #22), hoặc Phân khu sản xuất (`PRODUCTION_ZONE` #13).
            *   Chọn tiêu thức phân bổ: Theo tỷ lệ diện tích canh tác (m2), theo sản lượng thực thu (kg), hoặc theo tỷ lệ % chỉ định thủ công.
        *   **Bảng tính giá thành đơn vị sản xuất tự động:**
            *   Lấy tổng sản lượng thu hoạch thực tế từ hồ sơ thu hoạch (`harvest_records` #43): $\sum \text{quantity}$ (kg).
            *   Hệ thống tự động tổng hợp công thức chuẩn Agri-ERP:
                $$\text{Giá thành đơn vị (VNĐ/kg)} = \frac{\sum \text{Chi phí trực tiếp (Giống, Vật tư, Nhân công)} + \sum \text{Chi phí gián tiếp phân bổ}}{\text{Tổng sản lượng thu hoạch thực tế}}$$
            *   Hiển thị biểu đồ phân tích cấu thành giá thành (Cost Breakdown Pie Chart): % Chi phí vật tư, % Nhân công, % Khấu hao & Điện nước.
    *   **Tab Quản Lý & Cảnh Báo Ngân Sách (`budgets` #69 & `budget_line_items` #70):**
        *   So sánh trực quan giữa Chi phí Kế hoạch (Planned Budget) và Chi phí Thực tế Phát sinh (Actual Expense) theo từng hạng mục.
        *   Chỉ báo cảnh báo đỏ khi chi phí thực tế vượt ngưỡng ngân sách đã phê duyệt.

---

### 2.9. Workspace H2: Trung Tâm Bán Hàng, Giao Hàng & Thu Phí VietQR (`WS-SALES-CASHFLOW-CONSOLE`)
*   **Bảng SQL tích hợp:** `sales_orders` (#62), `sales_order_items` (#63), `sales_deliveries` (#64), `sales_delivery_items` (#65), `debt_records` (#66), `payment_transactions` (#67), `payment_allocations` (#68), `partners` (#4), `product_batches` (#44).
*   **Mã quyền RBAC:** `PERM_FINANCE_SALES_ORDER`, `PERM_FINANCE_PAYMENT`, `PERM_PAYMENT_ALLOCATE`, `PERM_DELIVERY_MANAGE`.
*   **Kiến trúc giao diện (Tabbed Sales & Cashflow Console):**
    *   **Tab 1 - Đơn Hàng & Bán Sỉ Nông Sản (`sales_orders` & `sales_order_items`):**
        *   Tạo đơn bán sỉ: Quản lý vòng đời chuẩn SQL:
            *   Trạng thái đơn **`status`**: `'PENDING'`, `'CONFIRMED'`, `'DELIVERED'`, `'COMPLETED'`, `'CANCELLED'`.
            *   Trạng thái thanh toán **`payment_status`**: `'UNPAID'`, `'PARTIALLY_PAID'`, `'PAID'`, `'REFUNDED'`.
        *   Chọn khách hàng (`partners` #4 loại `BUYER` hoặc `AGENT`), kiểm tra hạn mức công nợ tối đa `partners.credit_limit`. Nếu dư nợ hiện tại cộng giá trị đơn mới vượt quá hạn mức, hệ thống hiển thị cảnh báo yêu cầu phê duyệt đặc biệt.
        *   Chọn Lô thành phẩm đủ điều kiện KCS (`product_batches` #44 ở trạng thái `SELLING`). Khi lên đơn, hệ thống tự động tăng trường **`product_batches.reserved_quantity`** để giữ chỗ số lượng bán, ngăn ngừa bán vượt tồn kho.
    *   **Tab 2 - Quản Lý Giao Hàng & Vận Chuyển (`sales_deliveries` & `sales_delivery_items`):**
        *   Hỗ trợ quy trình giao hàng nhiều đợt (Split Shipments) cho một đơn hàng lớn.
        *   Chọn đơn vị vận chuyển đối tác **`logistics_partner_id`** (khóa ngoại liên kết `partners` #4 loại `LOGISTICS`).
        *   Nhập thông tin lái xe **`driver_name`**, biển số xe vận chuyển **`vehicle_plate`**.
        *   Tải lên ảnh chụp biên bản bàn giao có chữ ký xác nhận của bên mua **`proof_of_delivery_url`**.
        *   Quét mã vạch thương phẩm `gtin_barcode` hoặc mã truy xuất `traceability_code` khi bốc dỡ hàng lên xe.
    *   **Tab 3 - Sổ Cái Công Nợ Hai Chiều (`debt_records` #66):**
        *   Quản lý danh sách công nợ phải thu Khách hàng (`RECEIVABLE`) và công nợ phải trả Nhà cung cấp (`PAYABLE`), liên kết chứng từ gốc `sales_order_id` hoặc `warehouse_receipt_id`.
        *   Hiển thị đúng các trường tài chính chuẩn SQL: Tổng nợ **`total_debt`**, Đã trả **`paid_amount`**, Dư nợ **`remaining_debt`**, Ngày đáo hạn `due_date`, Trạng thái **`status`** (`'ACTIVE'`, `'OVERDUE'`, `'SETTLED'`, `'BAD_DEBT'`).
        *   Phân loại tuổi nợ (Aging Report): Trong hạn, quá hạn 1-30 ngày, quá hạn 31-60 ngày, quá hạn > 60 ngày.
        *   **Cơ chế Cấn Trừ Công Nợ Hai Chiều (`DEBT_OFFSET`):** Đối với các đối tác vừa mua nông sản vừa bán vật tư (loại `AGENT`), nút `[ Cấn Trừ Nợ ]` cho phép kế toán chọn 1 khoản nợ phải thu và 1 khoản nợ phải trả để đối trừ lẫn nhau mà không cần luân chuyển dòng tiền mặt.
    *   **Tab 4 - Thu Chi & Thanh Toán VietQR Tự Động (`payment_transactions` & `payment_allocations`):**
        *   Hỗ trợ 5 phương thức thanh toán: `'CASH'`, `'BANK_TRANSFER'`, `'VIETQR'`, `'E_WALLET'`, `'DEBT_OFFSET'`.
        *   **Trình Tạo Mã VietQR Thu Tiền Tự Động:**
            *   Dựa trên cấu trúc tài khoản Napas247 của Doanh nghiệp (`enterprises` #3: `bank_bin`, `bank_account_no`, `bank_account_name`), hệ thống tự động sinh mã VietQR động chuẩn EMVCo hiển thị trên màn hình thu ngân/kế toán.
            *   Nội dung chuyển khoản tự sinh chuẩn xác: **`qr_transfer_content`** (Ví dụ: `TNT01 SO62 KHACHHANG`).
        *   Tải lên ảnh chụp chứng từ ủy nhiệm chi/biên lai chuyển tiền **`proof_image_url`**.
        *   Ghi nhận người xác nhận giao dịch **`confirmed_by_user_id`** và thời gian xác nhận **`confirmed_at`**.
        *   **Phân bổ thanh toán tự động (`payment_allocations` #68):** Tự động phân bổ số tiền thanh toán để cấn trừ dần các khoản nợ tồn đọng trong `debt_records` (`remaining_debt > 0`) theo nguyên tắc nợ cũ trừ trước (FIFO Debt Clearance). Khi `remaining_debt = 0.00`, trạng thái khoản nợ tự chuyển sang `SETTLED`.
    *   **Tab 5 - Kết Toán Chu Kỳ Vận Hành Khép Kín (`WS-CYCLE-SETTLEMENT`):**
        *   Quy trình kết toán chu kỳ nông nghiệp (`operational_cycles` #16) tuân thủ luồng 3 bước:
            1.  **Maker (`ROLE_ACCOUNTANT`):** Tổng hợp doanh thu bán sỉ, toàn bộ chi phí sản xuất (vật tư backflush, nhân công, chi phí vận hành), lập Bảng kết toán chu kỳ (Cycle Settlement Sheet) ở trạng thái `DRAFT`.
            2.  **Checker (`ROLE_FARM_MANAGER`):** Thẩm định số liệu thực tế tại trại, ký duyệt xác nhận bảng kết toán (`status = 'REVIEWED'`) trước khi chuyển hồ sơ lãi về cho Ban Lãnh đạo.
            3.  **Owner (`ROLE_FARM_OWNER`):** Giám sát toàn chuỗi, giữ độc quyền bấm nút **`[ Xác Nhận Kết Toán Chu Kỳ ]`** (`SETTLED`) để chính thức kết chuyển lợi nhuận và đóng sổ niên độ.
        *   **Các Chốt Chặn Độc Quyền Của Owner:**
            *   Duyệt hạn mức tín dụng (`creditLimit`) vượt ngưỡng.
            *   Đưa đối tác vào danh sách đen (`BLACKLISTED`).
            *   Phê duyệt kế hoạch ngân sách (`budgets`).
            *   Xác nhận kết toán lợi nhuận chu kỳ (`Cycle Settlement`).

---

## ĐIỀU 3: QUY HOẠCH TRUNG TÂM CÀI ĐẶT DANH MỤC & PHÂN HỆ ĐỘC LẬP

### 3.1. Trung Tâm Cài Đặt Danh Mục Tĩnh (`/app/settings` - Master Data)
Nhằm chống loãng giao diện và bảo vệ tính chuẩn hóa của dữ liệu nền tảng, toàn bộ các bảng danh mục tĩnh, có tần suất thay đổi thấp (theo quý hoặc theo năm), do Ban Lãnh đạo hoặc Quản trị viên thiết lập, được gom độc quyền vào **Trung Tâm Cài Đặt Danh Mục** (`/app/settings`) chia thành các Tab chức năng rõ ràng:

1.  **Tab 1 - Hồ Sơ Pháp Lý & Ngân Hàng VietQR Doanh Nghiệp (`enterprises` #3):**
    *   Tên doanh nghiệp/hợp tác xã, mã số thuế `tax_number`, người đại diện pháp luật `legal_representative`, địa chỉ trụ sở `headquarter_address`, ngày thành lập `established_date`.
    *   Logo thương hiệu **`logo_url`**, hotline liên hệ **`contact_phone`**, email chính thức **`contact_email`**.
    *   Cấu trúc tài khoản ngân hàng nhận tiền Napas247: Mã BIN **`bank_bin`**, Tên ngân hàng **`bank_name`**, Số tài khoản **`bank_account_no`**, Tên chủ tài khoản **`bank_account_name`**.
    *   Danh sách chứng nhận chất lượng quốc tế (`certifications_json`: VietGAP, GlobalGAP, Organic USDA).
2.  **Tab 2 - Chu Kỳ Canh Tác & Cấu Hình Ngưỡng Vận Hành (`operational_cycles` #16, `farm_operational_settings` #17):**
    *   *Chu kỳ vận hành (`operational_cycles` #16):* Khai báo chu kỳ/niên vụ theo farm: Tên chu kỳ `name`, năm tài chính **`fiscal_year`**, ngày bắt đầu `start_date`, ngày kết thúc `end_date`, trạng thái **`status`** (`'PLANNING'`, `'ACTIVE'`, `'CLOSED'`).
    *   *Cấu hình ngưỡng vận hành trang trại (`farm_operational_settings` #17):* Cấu hình ngưỡng tưới tự động **`irrigation_threshold_json`** và cấu hình ca kíp vận hành **`work_shift_config_json`**.
3.  **Tab 3 - Danh Mục Giống Cây Trồng & Giống Vật Nuôi (`crop_types` #18, `livestock_breeds` #21):**
    *   *Giống cây trồng (`crop_types` #18):* Tên giống `name`, mã giống/phân loại **`variety_code`**, số ngày sinh trưởng tiêu chuẩn **`growth_days_standard`** (ngày), nhu cầu nước bình quân ngày **`water_need_m3_day`**, ngưỡng nhiệt độ tối ưu **`optimal_temp_min`**, **`optimal_temp_max`**.
    *   *Giống vật nuôi (`livestock_breeds` #21):* Loài **`species`** (`'CATTLE'`, `'SWINE'`, `'POULTRY'`, `'GOAT'`, `'SHEEP'`, `'AQUA'`), tên giống **`breed_name`**, số ngày nuôi tiêu chuẩn **`standard_growth_days`**, cân nặng mục tiêu **`target_weight_kg`**.
4.  **Tab 4 - Danh Mục Kho Bãi & Tiêu Chuẩn Bảo Quản (`warehouses` #26):**
    *   Khai báo danh mục kho, thuộc trang trại nào (`farm_id`), mã kho `code`, tên kho `name`, người quản lý kho **`manager_user_id`** (FK `users.id`).
    *   Phân loại kho chuẩn SQL (đầy đủ 7 loại kho):
        `'FERTILIZER'` (Kho phân bón), `'PESTICIDE'` (Kho thuốc BVTV), `'ANIMAL_FEED'` (Kho thức ăn gia súc), `'HARVESTED_PRODUCE'` (Kho nông sản sau thu hoạch), `'COLD_STORAGE'` (Kho lạnh bảo quản), `'TOOLS_EQUIPMENT'` (Kho công cụ dụng cụ), `'GENERAL'` (Kho tổng hợp).
    *   4 thông số kỹ thuật tiêu chuẩn kho: Sức chứa thiết kế **`capacity_m3`**, Diện tích mặt sàn **`floor_area_m2`**, Nhiệt độ bảo quản chuẩn **`standard_temp_c`**, Độ ẩm chuẩn **`standard_humidity_pct`** (Kiểm tra `0.00 <= standard_humidity_pct <= 100.00`). Trạng thái kho `status` (`'ACTIVE'`, `'INACTIVE'`, `'FULL'`).
5.  **Tab 5 - Danh Mục Vật Tư, Đơn Vị Quy Đổi & Định Mức Tiêu Hao (`material_categories` #27, `materials` #28, `material_unit_conversions` #29, `consumption_quotas` #30):**
    *   *Nhóm vật tư (`material_categories` #27):* Phân loại phân bón, thuốc BVTV, hạt giống, thức ăn chăn nuôi, vật tư tiêu hao; mô tả chi tiết `description`.
    *   *Mặt hàng vật tư (`materials` #28):* Mã SKU `sku_code`, mã vạch EAN-13 chuẩn **`barcode`**, tên thương mại `name`, đơn vị chuẩn **`standard_unit`** (`KG`, `GRAM`, `LITER`, `ML`, `BAG`, `BOTTLE`, `DOSE`, `PIECE`, `BOX`), hãng sản xuất **`manufacturer_name`**, hoạt chất chính **`active_ingredient`**, số ngày cách ly an toàn mặc định **`default_phi_days`**, hạn sử dụng chuẩn **`shelf_life_days`**, mức tồn kho tối thiểu an toàn `min_stock_level`, chiến lược xuất kho `dispatch_strategy` (`FEFO`, `FIFO`), trạng thái `status` (`'ACTIVE'`, `'INACTIVE'`, `'DISCONTINUED'`).
    *   *Quy đổi đơn vị tính & Mã vạch thùng/bao (`material_unit_conversions` #29):* Nhúng trực tiếp trong Modal Mặt hàng vật tư: Tên đơn vị quy đổi `unit_name` (Thùng 24 chai, Bao 50kg), mã vạch in ngoài vỏ thùng **`unit_barcode`**, hệ số quy đổi so với đơn vị chuẩn **`conversion_factor`**.
    *   *Định mức tiêu hao tiêu chuẩn - BOM (`consumption_quotas` #30):* Khai báo lượng vật tư tiêu chuẩn cần dùng cho từng giai đoạn sinh trưởng của cây trồng hoặc vật nuôi.
6.  **Tab 6 - Danh Mục Ca Làm Việc Chuẩn (`work_shifts` #52):**
    *   Mã ca, tên ca làm việc (Ca Sáng, Ca Chiều, Ca Hành Chính, Ca Đêm).
    *   Giờ bắt đầu `start_time`, giờ kết thúc `end_time`.
    *   Thời gian nghỉ giữa ca **`break_minutes`** (mặc định 60 phút).
    *   Số phút đi muộn cho phép không bị phạt **`grace_late_minutes`** (mặc định 15 phút).
7.  **Tab 7 - Danh Mục Khoản Mục Chi Phí Nông Nghiệp (`cost_categories` #59):**
    *   Mã khoản mục, tên khoản mục chi phí (Chi phí hạt giống, Chi phí phân bón, Chi phí thuốc BVTV, Chi phí nhân công trực tiếp, Chi phí điện nước trạm bơm, Chi phí khấu hao nhà màng).
    *   Phân loại khoản mục chi phí **`cost_type`** đúng 5 loại SQL:
        `'MATERIALS'`, `'DIRECT_LABOR'`, `'MACHINERY_FUEL'`, `'DEPRECIATION'`, `'INDIRECT_OVERHEAD'`.

---

### 3.2. Phân Hệ Báo Cáo & Phân Tích Thông Minh (`/app/reports` - Module 6)
Đứng độc lập hoàn toàn tại menu **"Báo Cáo & Phân Tích"**, phục vụ công tác điều hành chiến lược của Ban Giám đốc:
*   **6.1: Executive Dashboard Tổng Quan:** Tổng hợp KPI thời gian thực: Doanh thu lũy kế, Tồn kho khả dụng, Tiến độ mùa vụ, Chi phí phát sinh, Dòng tiền thuần.
*   **6.2: Báo Cáo Sản Xuất:** Tỷ lệ hoàn thành kế hoạch sản lượng, tỷ lệ sâu bệnh hao hụt, so sánh năng suất thực tế với năng suất chuẩn giống.
*   **6.3: Báo Cáo Kho & Vật Tư:** Báo cáo đối soát tiêu hao thực tế so với định mức tiêu chuẩn (BOM Variance), báo cáo tồn kho cận hạn sử dụng (Near-Expiry Alert).
*   **6.4: Báo Cáo Nhân Sự & Lao Động:** Bảng chấm công tổng hợp toàn trang trại, năng suất giờ công bình quân, thống kê giờ tăng ca OT.
*   **6.5: Báo Cáo Tài Chính & Hiệu Quả (P&L Mùa Vụ):** Báo cáo kết quả kinh doanh chi tiết theo từng mùa vụ/đàn vật nuôi, tỷ suất hoàn vốn ROI từng phân khu.
*   **6.6: Trình Dựng Báo Cáo Tùy Chỉnh & Xuất Dữ Liệu:** Hỗ trợ xuất dữ liệu Excel, PDF và gửi email báo cáo định kỳ tự động.

---

### 3.3. Phân Hệ Quản Trị Hệ Thống, An Ninh & Tích Hợp (`/app/system` - Module 7)
Chỉ mở cho Quản trị viên cấp cao (`ROLE_FARM_OWNER` hoặc IT Administrator):
*   **7.2: Quản Lý Vai Trò & Phân Quyền RBAC (`roles` #6, `permissions` #7, `role_permissions` #9):** Xem ma trận phân quyền chi tiết của hệ thống.
*   **7.3: Ranh Giới Truy Cập Dữ Liệu (The Farm Barrier Guard - `user_farm_access` #12):** Thiết lập và kiểm tra tính toàn vẹn phạm vi truy cập dữ liệu giữa các trang trại của từng người dùng.
*   **7.4: Nhật Ký Kiểm Toán & Truy Vết Bảo Mật (`audit_logs` #10):** Truy vết toàn bộ lịch sử đăng nhập, thay đổi cấu hình, can thiệp dữ liệu kèm địa chỉ IP và User-Agent.
*   **7.5: Cấu Hình Cổng Thông Báo Đa Kênh (`notifications` #71):** Thiết lập kênh gửi thông báo Web Push, Email SMTP, Zalo ZNS.
*   **7.6: Trạm Tích Hợp Thiết Bị IoT & Cảm Biến Hiện Trường:** Kết nối trạm đo thời tiết, cảm biến độ ẩm đất, nhiệt độ nhà màng qua giao thức MQTT/HTTP Webhook.

---

## ĐIỀU 4: SƠ ĐỒ LUỒNG THAO TÁC TỪ NHỎ ĐẾN LỚN (MICRO TO MACRO INTERACTION FLOWS)

### 4.1. Luồng Lớn: Chuỗi Thiết Lập 5 Chặng & Quy Tắc Smart Empty State

#### 4.1.1. Thứ Tự 5 Chặng Vận Hành Chuẩn Agri-ERP (Macro Execution Sequence)

```mermaid
sequenceDiagram
    autonumber
    actor Admin as Quản Trị Viên / Chủ Farm
    actor HR as Kế Toán / Nhân Sự
    actor Warehouse as Thủ Kho
    actor Staff as Kỹ Sư / Công Nhân
    actor Buyer as Khách Hàng / Thương Lái

    Note over Admin: CHẶNG 1: THIẾT LẬP NỀN TẢNG & MẶT BẰNG
    Admin->>Settings: 1. Khai báo Hồ sơ DN & Ngân hàng VietQR (#3)
    Admin->>Workspace A: 2. Tạo Trang trại (#11), Phân khu (#13), Vị trí (#14)
    Admin->>Settings: 3. Khai báo Kho bãi (#26), Giống (#18,#21), Vật tư & Đơn vị quy đổi (#27,#28,#29)

    Note over HR: CHẶNG 2: NHÂN SỰ & CẤP TÀI KHOẢN SAAS
    HR->>Workspace B: 4. Thêm Nhân viên (#51), Hợp đồng, Hạn mức phép
    HR->>Workspace B: 5. Gạt Switch Cấp tài khoản (#5), Gán Role (#8), Gán Farm Access (#12)
    HR->>Workspace A: 6. Phân công cán bộ quản lý Farm / Phân khu (#15)

    Note over Warehouse: CHẶNG 3: NHẬP VẬT TƯ & MUA HÀNG NCC
    Warehouse->>Workspace D: 7. Khai báo Nhà cung cấp (#4) kèm Hạn mức nợ & TK Ngân hàng
    Warehouse->>Workspace C: 8. Quét mã vạch, lập Phiếu nhập kho PURCHASE (#32,#33)
    Warehouse->>Workspace C: 9. Duyệt phiếu nhập -> Tự sinh Tồn kho (#31) & Công nợ NCC (#66)

    Note over Staff: CHẶNG 4: SẢN XUẤT, TIÊU HAO & THU HOẠCH
    Staff->>Workspace E: 10. Khởi tạo Mùa vụ (#19) hoặc Đàn nuôi (#22)
    Staff->>Workspace E: 11. Ghi nhật ký chăm sóc (#20) -> Auto-Backflush xuất kho (#34) & Ghi nhận chi phí (#60)
    Staff->>Workspace E: 12. Kiểm tra hết thời gian cách ly PHI -> Ghi nhận Thu hoạch (#43)

    Note over Buyer: CHẶNG 5: KIỂM ĐỊNH QC, XUẤT BÁN & DÒNG TIỀN
    Staff->>Workspace F: 13. Kiểm định KCS đạt PASSED (#46) -> Đóng băng Snapshot (#49) -> In tem QR (#50)
    Buyer->>Workspace H2: 14. Tạo Đơn bán sỉ (#62) -> Giữ chỗ Lô (#44) -> Giao hàng có ảnh POD (#64)
    Buyer->>Workspace H2: 15. Quét mã VietQR động thanh toán -> Kế toán xác nhận -> Tự đối soát nợ (#68)
```

#### 4.1.2. Quy Tắc Smart Empty State (Điều Hướng Tạo Dữ Liệu Thiếu Thông Minh)
Tuyệt đối cấm để form rơi vào trạng thái dropdown rỗng (trống trơn không có lựa chọn) khiến người dùng bế tắc. Áp dụng quy tắc Smart Empty State:
1.  **Khi mở Form Tạo Mùa Vụ (`CropSeasonCreateModal`):**
    *   Nếu hệ thống kiểm tra chưa có Phân khu (`production_zones` #13): Dropdown phân khu được thay bằng Banner cảnh báo vàng: *"Trang trại này chưa có Phân khu sản xuất nào"* kèm nút bấm CTA `[+ Tạo Phân Khu Mới]`. Click vào nút này sẽ mở trực tiếp Modal tạo Phân khu của Workspace A mà không làm mất dữ liệu mùa vụ đang nhập dở.
    *   Nếu chưa có Giống cây trồng (`crop_types` #18): Hiển thị nút CTA `[+ Khai Báo Giống Mới]`, mở nhanh modal nhập giống cây.
2.  **Khi mở Form Lập Phiếu Nhập Mua (`WarehouseReceiptCreateModal`):**
    *   Nếu dropdown Nhà cung cấp rỗng: Hiển thị ngay nút CTA `[+ Thêm Nhà Cung Cấp Mới]`, mở modal tạo đối tác loại `SUPPLIER` từ Workspace D.
3.  **Khi mở Form Lập Đơn Bán Sỉ (`SalesOrderCreateModal`):**
    *   Nếu chưa có Khách hàng: Hiển thị CTA `[+ Thêm Khách Hàng Tiêu Thụ]`.
    *   Nếu kho chưa có Lô thành phẩm đạt chuẩn KCS (`product_batches` trạng thái `SELLING`): Hiển thị thông báo hướng dẫn: *"Chưa có lô thành phẩm nào đủ điều kiện bán. Vui lòng kiểm định chất lượng tại Workspace F hoặc ghi nhận thu hoạch tại Workspace E"*.

---

### 4.2. Luồng Nhỏ: 4 Cơ Chế Tác Nghiệp Thành Phần Trọng Yếu (Micro Component Flows)

#### 4.2.1. Quét Barcode Vật Tư & Tự Động Quy Đổi Đơn Vị
Áp dụng trên toàn bộ các form Nhập kho, Xuất kho, Kiểm kê và Ghi nhật ký tiêu hao:

```mermaid
flowchart TD
    StartScan["Người dùng quét Barcode (Máy quét Laser hoặc Camera)"] --> CheckCode{"Kiểm tra mã quét"}
    
    CheckCode -->|Khớp materials.barcode| StandardMatch["Nhận diện Đơn Vị Chuẩn<br/>(Chai, Gói, Kg)"]
    StandardMatch --> FillStandard["- Gán material_id<br/>- entered_unit = standard_unit<br/>- conversion_factor = 1.0000<br/>- quantity = entered_quantity"]
    
    CheckCode -->|Khớp material_unit_conversions.unit_barcode| UnitMatch["Nhận diện Đơn Vị Quy Đổi<br/>(Thùng, Bao, Can)"]
    UnitMatch --> FillUnit["- Gán material_id<br/>- entered_unit = unit_name<br/>- conversion_factor = factor<br/>- Tự tính quantity = entered_quantity * factor"]
    
    CheckCode -->|Khớp warehouse_inventory.internal_batch_barcode| BatchMatch["Nhận diện Lô Nội Bộ Tại Kho"]
    BatchMatch --> FillBatch["- Định vị chính xác vị trí lô tồn kho<br/>- Điền ngày sản xuất manufacture_date<br/>- Điền hạn sử dụng expiry_date"]
    
    CheckCode -->|Không tìm thấy| ErrorState["Báo âm thanh lỗi + Mở Modal Tra Cứu Thủ Công"]
```

#### 4.2.2. Tự Động Tính & Khóa Nút Thu Hoạch Theo Thời Gian Cách Ly PHI/Withdrawal
Bảo vệ tiêu chuẩn VietGAP/GlobalGAP bằng thuật toán kiểm soát thời gian cách ly thời gian thực:
1.  **Khi ghi nhật ký sử dụng thuốc BVTV (`farming_logs` #20):**
    *   Hệ thống đọc trường `materials.default_phi_days` (#28) của vật tư được chọn.
    *   Tự động tính ngày kết thúc cách ly:
        $$\text{phi\_end\_date} = \text{log\_date} + \text{phi\_days}$$
2.  **Tại Bàn làm việc Canh tác (Workspace E):**
    *   Hệ thống liên tục kiểm tra: $\Delta t = \text{phi\_end\_date} - \text{CURRENT\_DATE}$.
    *   Nếu $\Delta t > 0$:
        *   Hiển thị Banner cảnh báo màu Đỏ rực tại đầu trang: *"CẢNH BÁO AN TOÀN SINH HỌC: Khu vực đang trong thời gian cách ly thuốc BVTV. Còn $\Delta t$ ngày (Đến hết ngày DD/MM/YYYY)!"*.
        *   Nút `[ Ghi Nhận Thu Hoạch ]` bị khóa cứng (`disabled = true`, độ mờ opacity-50, con trỏ cursor-not-allowed).
        *   Khi hover chuột vào nút bị khóa, hiển thị Tooltip giải thích: *"Không thể thu hoạch! Hoạt chất thuốc BVTV chưa phân giải hết theo quy định an toàn vệ sinh thực phẩm"*.

#### 4.2.3. Check-in / Check-out GPS & Camera Selfie Xác Thực 2 Chiều
Bảo đảm tính minh bạch 100% trong quản lý lao động nông nghiệp:

```mermaid
flowchart TD
    ClickCheckIn["Bấm [ CHẤM CÔNG VÀO CA ]"] --> GetGPS["Lấy tọa độ thiết bị (navigator.geolocation)"]
    GetGPS --> CalcDist["Tính khoảng cách Haversine tới tâm Farm (latitude, longitude)"]
    CalcDist --> CheckGeofence{"Khoảng cách <= geofence_radius_m?"}
    
    CheckGeofence -->|Hợp lệ| OpenCam["Bật Camera trước chụp ảnh Selfie"]
    CheckGeofence -->|Vượt ranh giới| WarningGeofence["Báo đỏ ngoài ranh giới + Bắt buộc nhập lý do ngoại lệ"] --> OpenCam
    
    OpenCam --> SnapPhoto["Chụp ảnh -> Tải lên Cloud sinh URL check_in_photo_url"]
    SnapPhoto --> SaveInRecord["Lưu bản ghi time_attendances (#54)"]
    
    SaveInRecord --> WorkPhase["Thời gian làm việc trong ca"]
    
    WorkPhase --> ClickCheckOut["Bấm [ CHẤM CÔNG HẾT CA ]"]
    ClickCheckOut --> GetGPSOut["Lấy tọa độ Check-out & Chụp ảnh check_out_photo_url"]
    GetGPSOut --> AutoCalcMetrics["Tự tính toán chỉ số:<br/>- working_hours = Tổng giờ - break_minutes<br/>- late_minutes = So với start_time + grace_late_minutes<br/>- early_leave_minutes = So với end_time"]
    AutoCalcMetrics --> UpdateAttendance["Cập nhật bản ghi hoàn tất"]
```

#### 4.2.4. Sinh Mã VietQR Động Chuẩn Napas247 & Đối Soát/Phân Bổ Công Nợ
1.  **Khi phát sinh giao dịch thu tiền bán sỉ hoặc chi trả tiền hàng:**
    *   Hệ thống đọc thông tin tài khoản Napas247 của bên thụ hưởng: Mã BIN ngân hàng `bank_bin`, Số tài khoản `bank_account_no`, Tên chủ tài khoản `bank_account_name`.
    *   Tự động sinh cú pháp chuyển khoản định danh:
        $$\text{qr\_transfer\_content} = \text{"TNT" + tenant\_id + " " + trans\_code}$$
    *   Sinh mã VietQR chuẩn EMVCo (Dynamic Payload chứa số tiền giao dịch chính xác `amount`).
2.  **Thao tác đối soát của Kế toán:**
    *   Khách hàng quét mã VietQR chuyển khoản nhanh bằng ứng dụng ngân hàng.
    *   Kế toán đối soát biến động số dư tài khoản ngân hàng, tải lên ảnh biên lai chuyển tiền / ủy nhiệm chi vào trường **`proof_image_url`**.
    *   Bấm `[ Xác Nhận Thanh Toán ]`: Hệ thống ghi nhận `confirmed_by_user_id` và `confirmed_at`.
3.  **Thuật toán phân bổ công nợ tự động (FIFO Debt Clearance):**
    *   Hệ thống truy vấn danh sách các khoản nợ chưa thanh toán hết (`remaining_debt > 0`) trong `debt_records` (#66) của đối tác đó, sắp xếp theo thứ tự ngày đáo hạn `due_date` tăng dần (Khoản nợ cũ nhất ưu tiên xử lý trước).
    *   Lặp qua từng khoản nợ và sinh bản ghi phân bổ trong **`payment_allocations` (#68)**:
        *   Trừ dần số tiền thanh toán vào `remaining_debt` của từng khoản nợ cho đến khi số tiền thanh toán bằng 0.
        *   Tự động cập nhật trạng thái khoản nợ sang `SETTLED` (nếu `remaining_debt = 0.00`) hoặc giữ `ACTIVE` / `OVERDUE` (nếu còn nợ một phần).

---

## ĐIỀU 5: BẢNG ÁNH XẠ PHỦ KÍN 100% 72 BẢNG SQL VÀO GIAO DIỆN UI

Dưới đây là bảng đối soát chi tiết, chứng minh **toàn bộ 72 bảng dữ liệu** trong file [V1_0__init_system_core.sql](file:///d:/Projects/Farm_Management/backend/src/main/resources/db/migration/V1_0__init_system_core.sql) đều được quy hoạch chính xác vào các màn hình và thành phần giao diện Frontend:

| STT | Tên Bảng SQL (`V1_0`) | Vị Trí Giao Diện Quy Hoạch (UI Shell / Workspace / Route) | Thành Phần UI Cụ Thể (Component / Modal / Drawer) | Mẫu Tác Nghiệp (UI Pattern) |
| :---: | :--- | :--- | :--- | :--- |
| **1** | `tenants` | `PlatformShell` (`/platform/tenants`) | `TenantManagementTable`, `TenantFormModal` | Master Table & CRUD Modal |
| **2** | `tenant_subscriptions`| `PlatformShell` (`/platform/subscriptions`) | `SubscriptionPlanCards`, `SubscriptionExtendModal` | Card Grid & Quota Progress Bar |
| **3** | `enterprises` | Master Data (`/app/settings?tab=enterprise`) | `EnterpriseProfileForm`, `VietQRBankConfigCard` | Single-Window Config Form |
| **4** | `partners` | Workspace D (`/app/partners`) | `PartnerDirectoryTable`, `PartnerFormModal` | Tabbed Directory (tax_code, status 3 types) |
| **5** | `users` | Workspace B (`/app/hr`) & `/app/system/users` | `UserProvisioningTab`, `UserTable`, `ForcePasswordModal`| Slide-Over Tab & Auth Guard |
| **6** | `roles` | Phân hệ Hệ thống (`/app/system/roles`) | `RoleMatrixView`, `RoleDetailDrawer` | Permission Matrix Table |
| **7** | `permissions` | Phân hệ Hệ thống (`/app/system/roles`) | `PermissionBadgeList`, `Can` Guard Component | Tag List & RBAC Wrapper (30 codes) |
| **8** | `user_roles` | Workspace B Drawer Tab 2 & `/app/system/users` | `RoleSelectorDropdown`, `UserRoleBadges` | Form Selector & Status Badges |
| **9** | `role_permissions` | Phân hệ Hệ thống (`/app/system/roles`) | `RolePermissionCheckboxMatrix` | Two-Dimensional Checkbox Grid |
| **10**| `audit_logs` | Phân hệ Hệ thống (`/app/system/audit-logs`) | `AuditTrailTimelineTable`, `AuditPayloadDiffModal`| Filterable Timeline & JSON Diff View |
| **11**| `farms` | Workspace A (`/app/geography`) & TopBar | `FarmContextSwitcher`, `FarmDetailCard` | farm_type (4 types), geofence_radius_m |
| **12**| `user_farm_access` | Workspace B Drawer Tab 2 & TopBar | `FarmAccessCheckboxList`, TopBar Filter Query | Multi-Select Checkboxes |
| **13**| `production_zones` | Workspace A (`/app/geography`) | `ProductionZoneTreeItem`, `MapLayoutGeoJSONEditor` | zone_type (6 types), status (4 types) |
| **14**| `zone_locations` | Workspace A (`/app/geography`) | `LocationGridList`, `ZoneLocationFormModal` | code, name, description, status (4 types) |
| **15**| `farm_assignments` | Workspace A (`/app/geography`) Detail Pane | `StaffAssignmentPanel`, `AssignStaffModal` | Bound Personnel List & 8 Roles SQL (Bổ sung ACCOUNTANT) |
| **16**| `operational_cycles` | Master Data (`/app/settings?tab=cycles`) | `OperationalCycleTable`, `CycleFormModal` | Fiscal Year & status (PLANNING, ACTIVE, CLOSED) |
| **17**| `farm_operational_settings`| Master Data (`/app/settings?tab=farm-settings`) | `FarmOperationalThresholdForm` | irrigation_threshold_json & shift_config |
| **18**| `crop_types` | Master Data (`/app/settings?tab=crops`) | `CropTypeCatalogGrid`, `CropTypeFormModal` | variety_code, growth_days_standard Specs |
| **19**| `crop_seasons` | Workspace E (`/app/farming`) Master Column | `CropSeasonMasterList`, `CropSeasonCreateModal` | planted_area_m2, seed_qty, yields & status |
| **20**| `farming_logs` | Workspace E (`/app/farming`) Detail Tab 2 | `FarmingLogTimeline`, `FarmingLogCompositeForm` | activity_type (7 types), phi_days & FEFO |
| **21**| `livestock_breeds` | Master Data (`/app/settings?tab=breeds`) | `LivestockBreedGrid`, `BreedFormModal` | species (6 types), breed_name & target_weight |
| **22**| `livestock_groups` | Workspace E (`/app/farming`) Master Column | `LivestockGroupMasterList`, `GroupCreateModal` | Master Group Item & Head Count Badge |
| **23**| `livestock_individuals`| Workspace E (`/app/farming`) Master Column | `RFIDIndividualTable`, `IndividualDetailModal` | RFID Filterable Table & Ear-tag Card |
| **24**| `livestock_weight_logs`| Workspace E (`/app/farming`) Detail Tab 3 | `WeightGrowthLineChart`, `WeightLogEntryModal` | Recharts Line Graph & Daily Weight Log|
| **25**| `livestock_events` | Workspace E (`/app/farming`) Detail Tab 2 | `VetEventTimeline`, `VetEventCompositeModal` | event_type (7 types) & withdrawal_days |
| **26**| `warehouses` | Master Data (`/app/settings?tab=warehouses`) | `WarehouseDirectoryCards`, `WarehouseFormModal` | 7 Types, Specs & manager_user_id Link |
| **27**| `material_categories`| Master Data (`/app/settings?tab=materials`) | `MaterialCategoryList`, `CategoryFormModal` | Category Sidebar & Quick CRUD Modal |
| **28**| `materials` | Master Data (`/app/settings?tab=materials`) | `MaterialDataTable`, `MaterialCompositeModal` | standard_unit, Barcode, PHI & Dispatch |
| **29**| `material_unit_conversions`| Master Data & Workspace C Forms | `UnitConversionSubTable`, `BarcodeConversionInput`| Nested Form Table & Auto-Calc Input |
| **30**| `consumption_quotas` | Master Data (`/app/settings?tab=quotas`) | `BOMQuotaMatrixTable`, `QuotaFormModal` | Standard BOM Table by Growth Stage |
| **31**| `warehouse_inventory` | Workspace C (`/app/inventory?tab=stock`) | `RealTimeStockLedgerTable`, `ExpiryBadge` | Real-time Table & FEFO Expiry Warning |
| **32**| `warehouse_receipts` | Workspace C (`/app/inventory?tab=receipts`) | `ReceiptConsoleTable`, `ReceiptCreateModal` | 4 Receipt Types (PURCHASE, RETURN, etc.) |
| **33**| `warehouse_receipt_items`| Workspace C Receipt Detail Drawer | `ReceiptItemDynamicForm`, `BarcodeScanLine` | Dynamic Form Array & Multi-Barcode Scan|
| **34**| `warehouse_issues` | Workspace C (`/app/inventory?tab=issues`) | `IssueConsoleTable`, `IssueApprovalModal` | 5 Issue Types (incl Backflush) & Ledger |
| **35**| `warehouse_issue_items`| Workspace C Issue Detail Drawer | `IssueItemDynamicForm`, `FEFOLotPicker` | Dynamic Form Array & FEFO Auto Picker |
| **36**| `warehouse_transfers` | Workspace C (`/app/inventory?tab=transfers`)| `TransferConsoleTable`, `TransferCreateModal` | Source/Dest Pair Table & Route Map |
| **37**| `warehouse_transfer_items`| Workspace C Transfer Detail Drawer | `TransferItemSubTable` | Item Transfer Discrepancy Checker |
| **38**| `warehouse_inventory_transactions`| Workspace C Stock Ledger Modal | `StockLedgerAuditView`, `MaterialCardHistory` | Immutable Stock Ledger & Filter Sheet |
| **39**| `stocktakes` | Workspace C (`/app/inventory?tab=stocktakes`)| `StocktakeBatchTable`, `StocktakeCreateModal` | Batch Inventory Audit Table & Status |
| **40**| `stocktake_items` | Workspace C Stocktake Sheet Modal | `DiscrepancyReconciliationSheet` | Book vs Physical Count Diff Sheet |
| **41**| `farming_log_supplies`| Workspace E Detail Tab 2 Material Form | `LogSupplyDynamicRowPicker` | Embedded FEFO Material Consumed Rows |
| **42**| `livestock_event_supplies`| Workspace E Detail Tab 2 Vet Form | `VetSupplyDynamicRowPicker` | Embedded Medicine/Feed Consumed Rows |
| **43**| `harvest_records` | Workspace E Detail Tab 4 Harvest Console | `HarvestRecordTable`, `HarvestEntryModal` | quality_grade (4 types) & harvested_by_user_id |
| **44**| `product_batches` | Workspace F (`/app/qa-traceability`) | `QAPipelineKanbanView`, `BatchDetailDrawer` | 6-Stage Visual Kanban & Detail Drawer |
| **45**| `product_batch_sources`| Workspace F Batch Detail Drawer | `BatchMultiSourceTable`, `SourceRatioChart` | Multi-Harvest Source Contribution Table|
| **46**| `qc_inspections` | Workspace F QC Inspection Modal | `QCInspectionCertificateView`, `QCSignOffModal` | overall_result (PENDING, PASSED, etc.) |
| **47**| `qc_inspection_items` | Workspace F QC Inspection Modal | `QCInspectionChecklistForm` | Standard Lab/Visual Testing Checklist |
| **48**| `product_batch_transactions`| Workspace F Batch Detail Drawer | `FinishedGoodsStockLedgerTable` | Packaged Produce Movement Ledger |
| **49**| `traceability_snapshots`| Workspace F & PublicTraceShell (`/trace/:code`)| `TraceabilityPublicPortal`, `HashShieldBadge` | Public Portal & SHA-256 Verified View |
| **50**| `label_print_logs` | Workspace F Thermal Print Modal | `ThermalLabelPreview`, `ESCPrintHistoryDrawer` | Monochrome Label Preview & Print Log |
| **51**| `employees` | Workspace B (`/app/hr`) | `EmployeeDirectoryTable`, `Employee360Drawer` | employee_code, position, joined_date, status |
| **52**| `work_shifts` | Master Data (`/app/settings?tab=shifts`) | `WorkShiftCards`, `ShiftFormModal` | Shift Catalog Card & Time Range Input |
| **53**| `shift_assignments` | Workspace G (`/app/my-dashboard`) & HR | `WeeklyShiftCalendarView`, `ShiftScheduleModal`| Drag & Drop Weekly Shift Scheduler |
| **54**| `time_attendances` | Workspace G (`/app/my-dashboard`) | `OneTapTimekeepingModal`, `SelfieCameraView` | Mobile-First GPS/Camera Clock-In Modal |
| **55**| `leave_requests` | Workspace G (`/app/my-dashboard`) | `LeaveRequestFormModal`, `LeaveApprovalDrawer` | Leave Application Form & Balance Widget|
| **56**| `overtime_requests` | Workspace G (`/app/my-dashboard`) | `OTRequestFormModal`, `OTApprovalDrawer` | Overtime Request & Manager Sign-Off |
| **57**| `farm_tasks` | Workspace G (`/app/my-dashboard`) | `PersonalTaskKanban`, `TaskDetailModal` | status (5 types), task_type (6), priority (4) |
| **58**| `farm_task_assignees`| Workspace G Task Modal | `TaskAssigneeChipSelector` | Multi-Avatar Worker Assignment Selector|
| **59**| `cost_categories` | Master Data (`/app/settings?tab=cost-categories`)| `CostCategoryTable`, `CostCategoryModal` | cost_type (5 types: MATERIALS, LABOR, etc.) |
| **60**| `farm_expenses` | Workspace H1 (`/app/cost-accounting`) Left | `MasterExpenseLedgerTable`, `ExpenseEntryModal` | 4-Source Cost Table & Invoice Uploader |
| **61**| `cost_allocations` | Workspace H1 Right Allocation Pane | `CostAllocationMatrix`, `BatchAllocateModal` | Allocation Matrix by Crop/Batch/Zone |
| **62**| `sales_orders` | Workspace H2 (`/app/sales-cashflow?tab=orders`)| `SalesOrderTable`, `SalesOrderWizardModal` | status (5 types) & payment_status (4 types) |
| **63**| `sales_order_items` | Workspace H2 Sales Order Form | `OrderItemRowTable`, `BatchReservedPicker` | Order Item Table & Stock Reserving Form|
| **64**| `sales_deliveries` | Workspace H2 (`/app/sales-cashflow?tab=deliveries`)| `DeliveryShipmentTable`, `DispatchModal` | Logistics Tracking & POD Camera Upload |
| **65**| `sales_delivery_items`| Workspace H2 Delivery Dispatch Form | `DeliveryDispatchItemPicker`, `GTINScanner` | Multi-Lot Dispatch Form & Barcode Scan |
| **66**| `debt_records` | Workspace H2 (`/app/sales-cashflow?tab=debt`) | `DebtAgingReportTable`, `OffsetDebtModal` | total_debt, remaining_debt & status (4 types)|
| **67**| `payment_transactions`| Workspace H2 (`/app/sales-cashflow?tab=payments`)| `CashflowTransactionTable`, `VietQRModal` | Transaction History & Dynamic VietQR |
| **68**| `payment_allocations`| Workspace H2 VietQR Payment Modal | `PaymentAllocationDrawer`, `FIFODebtSettlement`| Automated FIFO Debt Settlement View |
| **69**| `budgets` | Workspace H1 (`/app/cost-accounting?tab=budgets`)| `BudgetPlanTable`, `BudgetCreateModal` | Seasonal Budget Table & Approval Status|
| **70**| `budget_line_items` | Workspace H1 Budget Detail View | `BudgetVarianceAnalysisChart`, `LineItemTable` | Planned vs Actual Expense Variance Bar |
| **71**| `notifications` | TenantAppShell Global TopBar | `NotificationBellButton`, `NotificationDrawer` | Badge Counter & Categorized Dropdown |
| **72**| `refresh_tokens` | `AuthShell` & Phân hệ An Ninh | `TokenRotationManager`, `ActiveSessionsTable` | In-memory / Cookie Sync & Session View |

---

## ĐIỀU 6: MA TRẬN ĐỐI SOÁT 100% SƠ ĐỒ PHÂN CẤP CHỨC NĂNG (MODULE 1.1 -> 7.7)

Toàn bộ cây chức năng từ Module 1.1 đến Module 7.7 trong tài liệu phân cấp chức năng của dự án được đối soát chính xác theo bảng sau:

| Mã Chức Năng | Tên Phân Hệ Nghiệp Vụ Trong Sơ Đồ | Vị Trí Quy Hoạch Giao Diện | Cơ Chế Hợp Nhất Chống Phân Mảnh (Anti-Siloed Pattern) |
| :--- | :--- | :--- | :--- |
| **1.1 (1.1.1 - 1.1.3)** | Doanh nghiệp, logo, thông tin pháp lý & cấu hình | Master Data (`/app/settings?tab=enterprise`) | Form cấu hình hệ thống cấp tổ chức tích hợp VietQR Napas247 |
| **1.2 (1.2.1 - 1.2.8)** | Quản lý trang trại, tọa độ GPS, diện tích | Workspace A (`WS-PRODUCTION-GEOGRAPHY`) | Cột trái Master Tree & Chi tiết trang trại kèm Geofence Radius |
| **1.3 (1.3.1 - 1.3.4)** | Phân khu, lô đất, chuồng trại, sơ đồ mặt bằng | Workspace A (`WS-PRODUCTION-GEOGRAPHY`) | Cây địa lý đa cấp & Trình trực quan sơ đồ GeoJSON mặt bằng |
| **1.4 (1.4.1 - 1.4.5)** | Phân công quản lý trang trại & phân khu | Workspace A (`WS-PRODUCTION-GEOGRAPHY`) | Panel phân công tại chỗ cấp Farm/Zone với 8 role chuẩn SQL (kể cả ACCOUNTANT) |
| **1.5 (1.5.1 - 1.5.4)** | Chu kỳ mùa vụ, lứa nuôi, năm tài chính, ĐVT | Master Data (`/app/settings?tab=cycles`) | Quản trị vòng đời chu kỳ và niên độ chuẩn toàn hệ thống |
| **1.6 (1.6.1 - 1.6.3)** | Danh bạ Nhà cung cấp & Khách hàng tiêu thụ | Workspace D (`WS-ORGANIZATION-PARTNERS`) | Tabbed Directory kèm Checkbox đa vai trò và Hạn mức tín dụng |
| **2.1.1** | Kế hoạch trồng trọt tổng thể niên vụ | Master Data (`/app/settings?tab=crops`) | Khai báo mục tiêu sản lượng và định mức mùa vụ dài hạn |
| **2.1.2 - 2.1.4** | Hoạt động chăm sóc, sinh trưởng & sâu bệnh | Workspace E (`WS-FARMING-OPERATIONS`) | Bàn làm việc Trồng trọt + Xuất kho tự động (Auto-Backflush) |
| **2.1.5** | Quản lý thu hoạch nông sản | Workspace E (`WS-FARMING-OPERATIONS`) | Form thu hoạch $\rightarrow$ Kích hoạt Lô KCS (3.9) & Giá thành (5.4) |
| **2.2.1 - 2.2.6** | Toàn bộ Chăn nuôi: Đàn, thú y, thức ăn, chuồng | Workspace E (`WS-FARMING-OPERATIONS`) | Chuyển Sector Switcher sang Chăn Nuôi kèm thẻ tai RFID & ADG |
| **3.1** | Khai báo kho, vị trí lưu trữ, phân loại kho | Master Data (`/app/settings?tab=warehouses`)| Quản lý 7 loại kho chuẩn SQL, diện tích, nhiệt độ, độ ẩm thiết kế |
| **3.2** | Danh mục mặt hàng vật tư, SKU, HSD, min stock | Master Data (`/app/settings?tab=materials`) | Bảng danh mục SKU chuẩn hóa, mã vạch EAN-13, hoạt chất & PHI |
| **3.3 - 3.7** | Nhập, Xuất, Điều chuyển, Kiểm kê & Sổ kho | Workspace C (`WS-INVENTORY-TRANSACTION-HUB`)| Console giao dịch thống nhất đa chứng từ + Quét đa mã vạch |
| **3.8** | Quản lý định mức tiêu hao tiêu chuẩn (BOM) | Master Data (`/app/settings?tab=quotas`) | Ma trận định mức tiêu chuẩn kỹ thuật theo từng giai đoạn |
| **3.9 - 3.12** | Lô thành phẩm, Kiểm định KCS, In tem & Cổng QR| Workspace F (`WS-QA-TRACEABILITY-PIPELINE`)| Kanban 6 cột, Chốt an toàn phần cứng in tem, Cổng QR Snapshot |
| **4.1** | Hồ sơ nhân viên, hợp đồng, biên chế trang trại | Workspace B (`WS-HR-PERSONNEL-360`) | Tab 1 trong Unified Slide-over Drawer kèm Quỹ phép năm |
| **4.2** | Quản lý phân công công việc hiện trường | Workspace G (`WS-EMPLOYEE-DAILY-OPS`) | Bảng Kanban công việc cá nhân 3 cột & Check-list hiện trường |
| **4.3** | Quản lý chấm công Check-in GPS & Selfie 2 đầu | Workspace G (`WS-EMPLOYEE-DAILY-OPS`) | Khối Chấm công thông minh 1 chạm lớn kèm Camera xác thực |
| **4.4 - 4.5** | Quản lý ca làm việc, lịch trực, nghỉ phép & OT | Workspace G (`WS-EMPLOYEE-DAILY-OPS`) | Lịch ca làm việc tuần & Form nộp đơn xin nghỉ/tăng ca trực tuyến |
| **4.6** | Tổng hợp ngày công, giờ làm & dữ liệu lương | Workspace B (`WS-HR-PERSONNEL-360`) | Tab 3 Bảng tổng hợp công, giờ OT và dữ liệu tính lương |
| **5.1 - 5.2** | Ghi nhận chi phí & Phân bổ mùa vụ/lứa nuôi | Workspace H1 (`WS-COST-ACCOUNTING-ALLOCATION`)| Split-View Master-Detail tập hợp 4 nguồn chi phí & Bàn phân bổ |
| **5.3** | Quản lý doanh thu & Đơn bán sỉ nông sản | Workspace H2 (`WS-SALES-CASHFLOW-CONSOLE`)| Tab Đơn hàng & Bán sỉ liên kết Lô KCS và Giữ chỗ tồn kho |
| **5.4** | Tính giá thành sản xuất (Đơn vị / Sản lượng) | Workspace H1 (`WS-COST-ACCOUNTING-ALLOCATION`)| Bảng tính giá thành tự động sau thu hoạch (VNĐ/kg) |
| **5.5** | Quản lý công nợ NCC & Khách hàng | Workspace H2 (`WS-SALES-CASHFLOW-CONSOLE`)| Sổ cái công nợ tuổi nợ & Cơ chế Cấn trừ nợ hai chiều (DEBT_OFFSET)|
| **5.6 - 5.7** | Quản lý ngân sách & Đối soát kế hoạch - thực tế| Workspace H1 (`WS-COST-ACCOUNTING-ALLOCATION`)| Kế hoạch ngân sách mùa vụ và cảnh báo vượt chi theo thời gian thực |
| **6.1 - 6.6** | Toàn bộ phân hệ Báo cáo & Phân tích Dashboard | Module 6 Độc Lập (`/app/reports`) | Trung tâm Phân tích dữ liệu điều hành và Xuất báo cáo chuyên sâu |
| **7.1** | Cấp phát tài khoản SaaS, tự sinh user/pass | Workspace B (`WS-HR-PERSONNEL-360`) | Tab 2 Cấp tài khoản bằng Switch Toggle kèm Must Change Password |
| **7.2 - 7.7** | RBAC, Farm Barrier, Audit Log, IoT, Backup | Module 7 Độc Lập (`/app/system`) | Bàn điều khiển quản trị an ninh, giám sát Audit và Trạm IoT |

---

## ĐIỀU 7: CHECKLIST NGHIỆM THU UI BẮT BUỘC TRƯỚC KHI MERGE CODE (FRONTEND REVIEW GATE)

Trước khi gửi bất kỳ Pull Request nào hoặc báo cáo hoàn thành tính năng Frontend, lập trình viên BẮT BUỘC phải tự kiểm tra và vượt qua **12 tiêu chí sống còn** sau:

- [ ] **1. Tiêu chí 4 Application Shells:** Ứng dụng đã phân tách triệt để 4 Shell (`AuthShell`, `PlatformShell`, `TenantAppShell`, `PublicTraceShell`) với router guard nghiêm ngặt chưa?
- [ ] **2. Tiêu chí Must Change Password Guard:** Sau khi đăng nhập, nếu `users.must_change_password == true`, hệ thống có cưỡng chế chuyển hướng sang `/force-change-password` và chặn mọi route khác không?
- [ ] **3. Tiêu chí Universal Farm Context:** TopBar có `FarmContextSwitcher` chỉ hiển thị các Farm trong `user_farm_access` của user và đồng bộ `activeFarmId` vào Zustand Store không?
- [ ] **4. Tiêu chí Anti-Siloed & Single-Window:** Thao tác tạo/sửa đối tượng có bị phân tán sang nhiều trang URL khác nhau không? (Bắt buộc gom vào 1 Drawer/Modal đa tab).
- [ ] **5. Tiêu chí Context Preservation:** Khi đổi Farm/Zone/Mùa vụ, các form con có tự động thừa hưởng ID ngữ cảnh đang chọn không (loại bỏ dropdown cha thừa thãi)?
- [ ] **6. Tiêu chí Atomic Action & Auto-Backflushing:** Nhật ký canh tác có tự động kích hoạt tạo phiếu xuất kho tiêu hao và ghi nhận chi phí sản xuất trong cùng một luồng không?
- [ ] **7. Tiêu chí Hardware Gate & PHI Guard:** Nút In tem nhãn nhiệt và Nút Thu hoạch có bị khóa cứng (`disabled`) khi chưa đạt KCS `PASSED` hoặc chưa hết thời gian cách ly PHI không?
- [ ] **8. Tiêu chí Multi-Barcode Scanning:** Trình quét mã vạch có nhận diện chính xác cả mã vạch chuẩn, mã vạch thùng quy đổi và mã vạch lô nội bộ để tự tính số lượng chuẩn không?
- [ ] **9. Tiêu chí Mobile-First GPS & Selfie:** Workspace G có nút Check-in/Check-out lớn, đo khoảng cách hàng rào địa lý `geofence_radius_m` và chụp ảnh selfie xác thực 2 đầu không?
- [ ] **10. Tiêu chí VietQR & Cấn Trừ Nợ:** Giao diện thanh toán có sinh mã VietQR động từ tài khoản Napas247, tải ảnh biên lai và hỗ trợ cấn trừ hai chiều `DEBT_OFFSET` không?
- [ ] **11. Tiêu chí Smart Empty State:** Khi form thiếu dữ liệu cha (như chưa có Phân khu, Giống, NCC), UI có hiển thị nút CTA dẫn thẳng tới nơi tạo dữ liệu thiếu thay vì để dropdown rỗng không?
- [ ] **12. Tiêu chí Phủ Kín 72 Bảng SQL & RBAC:** Toàn bộ 72 bảng trong file `V1_0__init_system_core.sql` đã được ánh xạ vào đúng vị trí UI và các nút chức năng được bọc trong component `<Can>` kiểm tra quyền RBAC chưa?

---
*Văn kiện này là Hiến pháp tối thượng của dự án Nền tảng Nông nghiệp Số Farm SaaS. Mọi hành vi lập trình phân mảnh, vi phạm nguyên tắc hợp nhất ngữ cảnh, làm sai lệch cấu trúc 4 Shell hoặc bỏ sót bất kỳ bảng nào trong 72 bảng cơ sở dữ liệu đều bị coi là vi phạm nghiêm trọng tiêu chuẩn kỹ thuật của toàn dự án!*
