# ĐẶC TẢ MÁY TRẠNG THÁI & VÒNG ĐỜI DỮ LIỆU HỆ THỐNG AGRI-ERP
## (MASTER STATE MACHINES & LIFECYCLE SPECIFICATION)

> **Mã văn kiện:** `SPEC-STATE-002`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Ràng Buộc Trạng Thái Vận Hành & Khóa Cứng Dữ Liệu Toàn Hệ Thống.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Tôn chỉ:** *"Mọi thực thể nghiệp vụ cốt lõi đều tuân thủ máy trạng thái hữu hạn (FSM) - Chuyển trạng thái đơn hướng có điều kiện - Khóa cứng bất biến khi hoàn tất - Cấm tuyệt đối xóa vật lý"*.

---

## 1. TỔNG QUAN MA TRẬN 29 THỰC THỂ CÓ TRẠNG THÁI (STATUS / STATE MATRIX)

Hệ thống quản lý trạng thái vận hành của 29 thực thể bảng thông qua các Check Constraints và các trường trạng thái chuyên biệt:

| STT | Bảng SQL | Trường Trạng Thái | Danh Mục Giá Trị Hợp Lệ (Check Constraint) | Kiểu Vòng Đời |
| :---: | :--- | :--- | :--- | :--- |
| 1 | `tenants` (#1) | `status` | `'ACTIVE'`, `'SUSPENDED'`, `'INACTIVE'` | Tổ chức |
| 2 | `partners` (#4) | `status` | `'ACTIVE'`, `'INACTIVE'`, `'BLACKLISTED'` | Danh bạ B2B |
| 3 | `users` (#5) | `status` | `'ACTIVE'`, `'LOCKED'`, `'INACTIVE'` | Người dùng |
| 4 | `farms` (#11) | `status` | `'ACTIVE'`, `'INACTIVE'`, `'MAINTENANCE'` | Cơ sở |
| 5 | `production_zones` (#13) | `status` | `'ACTIVE'`, `'FALLOW'`, `'QUARANTINE'`, `'MAINTENANCE'` | Địa lý sản xuất |
| 6 | `zone_locations` (#14) | `status` | `'ACTIVE'`, `'OCCUPIED'`, `'EMPTY'`, `'MAINTENANCE'` | Lô đất / Chuồng |
| 7 | `operational_cycles` (#16) | `status` | `'PLANNING'`, `'ACTIVE'`, `'CLOSED'` | Chu kỳ tài chính |
| 8 | `crop_seasons` (#19) | `status` | `'SOIL_PREPARATION'`, `'SOWING'`, `'GROWING'`, `'HARVESTING'`, `'CLOSED'`, `'CANCELLED'` | Vụ mùa |
| 9 | `livestock_groups` (#22) | `status` | `'ACTIVE'`, `'QUARANTINED'`, `'SOLD'`, `'CULLED'` | Đàn vật nuôi |
| 10 | `livestock_individuals` (#23) | `health_status` | `'HEALTHY'`, `'SICK'`, `'INJURED'`, `'QUARANTINED'`, `'DECEASED'`, `'SOLD'` | Cá thể RFID |
| 11 | `warehouses` (#26) | `status` | `'ACTIVE'`, `'INACTIVE'`, `'FULL'` | Kho bãi |
| 12 | `materials` (#28) | `status` | `'ACTIVE'`, `'INACTIVE'`, `'DISCONTINUED'` | Vật tư |
| 13 | `warehouse_receipts` (#32) | `status` | `'DRAFT'`, `'APPROVED'`, `'COMPLETED'`, `'CANCELLED'` | Chứng từ kho |
| 14 | `warehouse_issues` (#34) | `status` | `'DRAFT'`, `'APPROVED'`, `'COMPLETED'`, `'CANCELLED'` | Chứng từ kho |
| 15 | `warehouse_transfers` (#36)| `status` | `'DRAFT'`, `'PENDING'`, `'IN_TRANSIT'`, `'COMPLETED'`, `'CANCELLED'` | Điều chuyển |
| 16 | `stocktakes` (#39) | `status` | `'DRAFT'`, `'IN_PROGRESS'`, `'COMPLETED'`, `'CANCELLED'` | Kiểm kê kho |
| 17 | `product_batches` (#44) | `status` | `'PENDING_APPROVAL'`, `'READY_TO_PRINT'`, `'PRINTED'`, `'SELLING'`, `'REJECTED'`, `'RECALLED'` | Lô thành phẩm |
| 18 | `qc_inspections` (#46) | `overall_result` | `'PENDING'`, `'PASSED'`, `'REJECTED'`, `'CONDITIONAL'` | Kiểm định KCS |
| 19 | `employees` (#51) | `status` | `'ACTIVE'`, `'ON_LEAVE'`, `'RESIGNED'`, `'TERMINATED'` | Hồ sơ nhân sự |
| 20 | `shift_assignments` (#53) | `status` | `'SCHEDULED'`, `'COMPLETED'`, `'ABSENT'`, `'CANCELLED'` | Phân ca |
| 21 | `time_attendances` (#54) | `status` | `'VALID'`, `'LATE'`, `'EARLY_DEPARTURE'`, `'OUT_OF_RANGE'`, `'ABSENT'` | Chấm công GPS |
| 22 | `leave_requests` (#55) | `status` | `'PENDING'`, `'APPROVED'`, `'REJECTED'`, `'CANCELLED'` | Đơn nghỉ phép |
| 23 | `overtime_requests` (#56) | `status` | `'PENDING'`, `'APPROVED'`, `'REJECTED'`, `'CANCELLED'` | Đơn làm thêm |
| 24 | `farm_tasks` (#57) | `status` | `'TODO'`, `'IN_PROGRESS'`, `'PENDING_REVIEW'`, `'DONE'`, `'CANCELLED'` | Nhiệm vụ |
| 25 | `farm_expenses` (#60) | `status` | `'DRAFT'`, `'CONFIRMED'`, `'CANCELLED'` | Chi phí |
| 26 | `sales_orders` (#62) | `status` | `'PENDING'`, `'CONFIRMED'`, `'DELIVERED'`, `'COMPLETED'`, `'CANCELLED'` | Đơn bán sỉ |
| 27 | `sales_orders` (#62) | `payment_status` | `'UNPAID'`, `'PARTIALLY_PAID'`, `'PAID'`, `'REFUNDED'` | Thanh toán đơn |
| 28 | `sales_deliveries` (#64) | `status` | `'DRAFT'`, `'DISPATCHED'`, `'DELIVERED'`, `'CANCELLED'` | Giao hàng |
| 29 | `debt_records` (#66) | `status` | `'ACTIVE'`, `'OVERDUE'`, `'SETTLED'`, `'BAD_DEBT'` | Sổ nợ |
| 30 | `payment_transactions` (#67)| `status` | `'PENDING'`, `'COMPLETED'`, `'CANCELLED'` | Giao dịch tiền |
| 31 | `budgets` (#69) | `status` | `'DRAFT'`, `'ACTIVE'`, `'CLOSED'`, `'REVISED'` | Ngân sách |

---

## 2. NHÓM 1: MÁY TRẠNG THÁI CHỨNG TỪ KHO VẬN (WAREHOUSE DOCUMENTS FSM)

Áp dụng cho: `warehouse_receipts` (#32), `warehouse_issues` (#34), `warehouse_transfers` (#36), `stocktakes` (#39).

### 2.1. Vòng đời Phiếu Nhập kho (`warehouse_receipts`) & Phiếu Xuất kho (`warehouse_issues`)

```mermaid
stateDiagram-v2
    [*] --> DRAFT: Maker (Thủ kho ROLE_WAREHOUSE_STAFF tạo chứng từ)
    DRAFT --> APPROVED: Checker (Giám đốc trại ROLE_FARM_MANAGER phê duyệt)
    APPROVED --> COMPLETED: Thủ kho hoàn tất bàn giao & thực xuất/nhập
    DRAFT --> COMPLETED: Hệ thống duyệt tự động (Chỉ riêng Auto-Backflush)
    DRAFT --> CANCELLED: Hủy phiếu khi còn là bản nháp
    APPROVED --> CANCELLED: Hủy phiếu trước khi điều động hàng
    COMPLETED --> [*]: ĐÓNG BĂNG BẤT BIẾN (IMMUTABLE)
    CANCELLED --> [*]: Lưu vết lịch sử kèm lý do hủy
```

#### Quy tắc Chuyển Trạng thái & Chốt chặn Maker - Checker:
1.  **Khởi tạo `DRAFT` (Maker):**
    *   Thủ kho (`ROLE_WAREHOUSE_STAFF`) tạo phiếu nhập mua (`receipt_type = 'PURCHASE'`), phiếu xuất (`issue_type = 'INTERNAL_USE'`), điều chuyển, kiểm kê.
    *   Cho phép chỉnh sửa các trường: danh sách mặt hàng, số lượng `quantity`, đơn vị `entered_unit`, số lô `batch_number`, ngày chứng từ, ghi chú.
    *   Tại trạng thái `DRAFT`: **Tuyệt đối chưa tác động vào số lượng tồn kho** trong `warehouse_inventory` và chưa ghi Sổ cái `warehouse_inventory_transactions`.
2.  **Chuyển sang `APPROVED` (Checker):**
    *   **Chốt chặn an ninh:** Bắt buộc có quyền `PERM_INVENTORY_RECEIPT` hoặc `PERM_INVENTORY_ISSUE` của Giám đốc trang trại (`ROLE_FARM_MANAGER`).
    *   **Luật Chống Tự Duyệt:** Thủ kho tạo phiếu (`created_by_user_id`) không được tự kích hoạt chuyển trạng thái sang `APPROVED`.
    *   Ghi nhận `approved_by` và `approved_at = CURRENT_TIMESTAMP`. Khóa chỉnh sửa danh sách mặt hàng và đơn giá.
3.  **Chuyển sang `COMPLETED` (Thời điểm Tác động Sổ sách Kho):**
    *   Thực hiện kiểm đếm và bàn giao vật tư tại cửa kho.
    *   Hệ thống thực hiện trong một Transaction nguyên tử:
        *   Cập nhật `warehouse_inventory`: Cộng tồn kho khả dụng và tồn kho thực tế nếu là Nhập (`direction = 'IN'`), hoặc trừ tồn kho nếu là Xuất (`direction = 'OUT'`).
        *   Ghi nhận bút toán bất biến vào Sổ cái thẻ kho `warehouse_inventory_transactions` với `reference_doc_type`, `reference_doc_id`, `reference_item_id`, `direction`, `quantity`, `balance_before`, `balance_after`.
        *   Nếu là Nhập mua hàng (`receipt_type = 'PURCHASE'`): Tự động phát sinh một khoản nợ phải trả trong `debt_records` với `debt_type = 'PAYABLE'`, `warehouse_receipt_id = warehouse_receipts.id`, `total_debt = warehouse_receipts.total_amount`.
    *   **QUY TẮC KHÓA CỨNG (IMMUTABILITY):** Ngay khi chuyển sang `COMPLETED`, hệ thống **KHÓA TUYỆT ĐỐI** mọi thao tác `UPDATE` và `DELETE`. Cấm sửa số lượng, đơn giá, số lô hay xóa phiếu. Nếu thực tế có sai lệch, bắt buộc phải tạo Phiếu Trả hàng hoặc Phiếu Kiểm kê/Điều chỉnh.
4.  **Chuyển sang `CANCELLED` (Hủy chứng từ):**
    *   Chỉ cho phép hủy khi phiếu đang ở trạng thái `DRAFT` hoặc `APPROVED` (chưa chuyển sang `COMPLETED`).
    *   Bắt buộc phải ghi nhận người hủy `cancelled_by`, thời gian hủy `cancelled_at`, và lý do hủy chi tiết **`cancellation_reason`** (không được để trống).

### 2.2. Vòng đời Phiếu Điều chuyển Kho (`warehouse_transfers` #36)
`DRAFT` $\rightarrow$ `PENDING` $\rightarrow$ `IN_TRANSIT` $\rightarrow$ `COMPLETED` (hoặc `CANCELLED`):
*   `DRAFT`: Lập kế hoạch điều chuyển giữa Kho xuất `from_warehouse_id` và Kho nhận `to_warehouse_id`.
*   `PENDING`: Trình duyệt lệnh điều động liên trại/liên kho.
*   `IN_TRANSIT`: Kho xuất đã xuất hàng ra khỏi cửa kho. Ghi nhận `transferred_by_user_id` và `dispatched_at`. Tồn kho tại kho xuất bị trừ, hàng được đưa vào trạng thái "Đang trung chuyển".
*   `COMPLETED`: Kho nhận đã kiểm đếm và nhận hàng nhập kho. Ghi nhận `received_by_user_id` và `received_at`. Tồn kho tại kho nhận được cộng vào `warehouse_inventory`. Khóa cứng chứng từ.

### 2.3. Vòng đời Phiếu Kiểm kê Kho (`stocktakes` #39)
`DRAFT` $\rightarrow$ `IN_PROGRESS` $\rightarrow$ `COMPLETED` (hoặc `CANCELLED`):
*   `DRAFT`: Tạo danh sách kiểm kê tại một kho `warehouse_id`.
*   `IN_PROGRESS`: Khóa tạm thời các hoạt động xuất/nhập tại kho đó. Tổ kiểm kê nhập số lượng thực tế kiểm đếm `actual_quantity` trong bảng `stocktake_items` (#40).
*   `COMPLETED`: Quản lý kho duyệt biên bản (`approved_by`, `approved_at`). Hệ thống tự động cân chỉnh tồn kho thực tế: Ghi bút toán `STOCKTAKE_ADJUST_IN` hoặc `STOCKTAKE_ADJUST_OUT` vào Sổ cái `warehouse_inventory_transactions`. Khóa cứng biên bản.

---

## 3. NHÓM 2: MÁY TRẠNG THÁI SẢN XUẤT NÔNG VỤ (PRODUCTION FSM)

### 3.1. Vòng đời Mùa vụ Trồng trọt (`crop_seasons` #19)

```mermaid
stateDiagram-v2
    [*] --> SOIL_PREPARATION: Lập kế hoạch & Chuẩn bị đất canh tác
    SOIL_PREPARATION --> SOWING: Bắt đầu xuống giống / Cấy cây non
    SOWING --> GROWING: Cây bén rễ & Phát triển sinh khối
    GROWING --> HARVESTING: Cây bắt đầu cho thu hoạch đợt đầu
    HARVESTING --> CLOSED: Thu hoạch dứt điểm & Tổng kết vụ mùa
    SOIL_PREPARATION --> CANCELLED: Hủy kế hoạch vụ mùa
    SOWING --> CANCELLED: Thiên tai, ngập úng, dịch bệnh hủy vụ
    GROWING --> CANCELLED: Rủi ro bất khả kháng
    CLOSED --> [*]: Đóng sổ phân bổ chi phí & tính giá thành
    CANCELLED --> [*]: Lưu vết báo cáo tổn thất
```

#### Quy tắc Nghiệp vụ Trọng yếu:
1.  **`SOIL_PREPARATION` (Làm đất):** Đăng ký kế hoạch mùa vụ, phân bổ diện tích `planted_area_m2`. Ghi nhận nhật ký cày bừa, khử vôi, bón lót (`activity_type = 'SOIL_TILLAGE'`).
2.  **`SOWING` (Xuống giống):** Gieo hạt hoặc cấy cây mô. Ghi nhận lượng giống `seed_quantity` và ngày bắt đầu `start_date`.
3.  **`GROWING` (Chăm sóc sinh trưởng):** Ghi nhật ký tưới nước, bón thúc, tỉa cành, phòng trừ sâu bệnh. Hệ thống bắt đầu kích hoạt cơ chế tính ngày cách ly thuốc BVTV `phi_end_date`.
4.  **`HARVESTING` (Thu hoạch):** Bắt đầu thu hoạch nông sản.
    *   **QUY TẮC BẮT BUỘC:** Hệ thống **CHỈ CHO PHÉP TẠO BIÊN BẢN THU HOẠCH (`harvest_records` #43)** khi mùa vụ đang ở trạng thái **`GROWING`** hoặc **`HARVESTING`**. Tuyệt đối cấm ghi thu hoạch khi đang ở `SOIL_PREPARATION`, `SOWING`, `CLOSED` hoặc `CANCELLED`.
    *   Nếu thu hoạch trong khi `today < Max(farming_logs.phi_end_date)`: Backend chặn bằng lỗi `SAFETY_VIOLATION_PHI_ACTIVE`.
5.  **`CLOSED` (Đóng mùa vụ):** Toàn bộ sản lượng thực tế được chốt vào `actual_yield_kg`. Hệ thống khóa chức năng ghi nhật ký và khóa tạo biên bản thu hoạch mới. Kích hoạt module Kế toán chạy thuật toán phân bổ chi phí và tính giá thành đơn vị sản phẩm nông nghiệp.
6.  **Cơ chế Tự Động Hủy Công Việc Khi Mùa Vụ Đóng (`CLOSED` / `CANCELLED`):**
    *   Khi một mùa vụ chuyển sang trạng thái `CLOSED` hoặc `CANCELLED`, Backend Service tự động kích hoạt luồng xử lý Cascade:
    *   Toàn bộ các nhiệm vụ hiện trường (`farm_tasks` #57) gắn liền với mùa vụ này (`crop_season_id = season.id`) đang ở trạng thái `TODO` hoặc `IN_PROGRESS` sẽ **tự động chuyển trạng thái sang `status = 'CANCELLED'`** với lý do hệ thống:
        `"Tự động hủy do Mùa vụ đã đóng (CLOSED) hoặc bị hủy (CANCELLED)"`.
    *   Hệ thống gửi thông báo thu hồi nhiệm vụ (`notifications` #71) đến các nhân viên hiện trường được phân công (`farm_task_assignees`).

### 3.2. Vòng đời Đàn/Lứa Chăn nuôi (`livestock_groups` #22) & Cá thể (`livestock_individuals` #23)

```mermaid
stateDiagram-v2
    [*] --> ACTIVE: Nhập đàn mới / Sinh sản tại trại
    ACTIVE --> QUARANTINED: Phát hiện triệu chứng bệnh / Cách ly theo dõi
    QUARANTINED --> ACTIVE: Đã điều trị khỏi & Hết thời gian cách ly
    ACTIVE --> SOLD: Xuất chuồng bán thương phẩm
    ACTIVE --> CULLED: Loại thải / Thanh lý / Giết mổ
    QUARANTINED --> CULLED: Dịch bệnh buộc phải tiêu hủy
    SOLD --> [*]: Chốt doanh thu bán buôn
    CULLED --> [*]: Ghi nhận tổn thất / Thu hồi vốn
```

#### Quy tắc Khóa Xuất bán & Tự động Hủy Công việc:
*   Khi phát hiện gia súc/gia cầm có dấu hiệu dịch bệnh hoặc mới nhập từ vùng khác về: Đàn/cá thể chuyển sang `status = 'QUARANTINED'`.
*   **QUY TẮC KHÓA BÁN:** Khi một đàn đang ở trạng thái `QUARANTINED`:
    *   Cấm tuyệt đối đưa vào Đơn bán hàng (`sales_order_items`).
    *   Cấm tạo biên bản thu hoạch/giết mổ (`harvest_records` hoặc `livestock_events.event_type = 'SLAUGHTER'`).
    *   Chỉ được phép thực hiện các sự kiện điều trị thú y (`'MEDICAL_TREATMENT'`, `'VACCINATION'`).
*   Đối với Cá thể gắn chip RFID (`livestock_individuals`), vòng đời sức khỏe `health_status` tuân thủ: `'HEALTHY'` $\longleftrightarrow$ `'SICK'` / `'INJURED'` / `'QUARANTINED'` $\rightarrow$ `'DECEASED'` / `'SOLD'`.
*   **Cơ chế Tự Động Hủy Công Việc Khi Đàn Xuất Bán (`SOLD` / `CULLED`):**
    *   Khi đàn nuôi chuyển sang trạng thái `SOLD` hoặc `CULLED`, tất cả các nhiệm vụ (`farm_tasks` #57) thuộc đàn (`livestock_group_id = group.id`) đang ở `TODO` hoặc `IN_PROGRESS` sẽ **tự động chuyển trạng thái sang `status = 'CANCELLED'`** với lý do:
        `"Tự động hủy do Đàn vật nuôi đã xuất bán (SOLD) hoặc thanh lý (CULLED)"`.

### 3.3. Vòng đời Phân khu Sản xuất (`production_zones` #13)

```mermaid
stateDiagram-v2
    [*] --> MAINTENANCE: Farm Manager tạo mới phân khu (Chờ Owner duyệt)
    MAINTENANCE --> ACTIVE: Farm Owner phê duyệt kích hoạt đưa vào sản xuất
    ACTIVE --> FALLOW: Nghỉ đất / Khử trùng chuồng trại luân canh
    FALLOW --> ACTIVE: Hoàn tất nghỉ đất, bắt đầu xuống giống / thả đàn mới
    ACTIVE --> QUARANTINE: Phát hiện dịch hại / dịch bệnh động thực vật
    QUARANTINE --> ACTIVE: Khử trùng triệt để & kiểm định an toàn
    ACTIVE --> MAINTENANCE: Sửa chữa nhà màng, trạm bơm, hạ tầng
    MAINTENANCE --> [*]: Ngừng khai thác vĩnh viễn
```

#### Quy tắc Phê duyệt Cấp bậc (Hierarchical Zone Activation):
1.  **Khởi tạo `MAINTENANCE` (Chờ duyệt):**
    *   Khi Quản lý trang trại (`ROLE_FARM_MANAGER`) tạo một phân khu mới, hệ thống bắt buộc đặt trạng thái mặc định là `'MAINTENANCE'`.
    *   Tại trạng thái này: Cấm tạo mùa vụ (`crop_seasons`), cấm nhập đàn nuôi (`livestock_groups`), và cấm gán vị trí canh tác.
2.  **Kích hoạt `ACTIVE` (Chủ đầu tư phê duyệt):**
    *   **Chỉ duy nhất Chủ đầu tư (`ROLE_FARM_OWNER`)** mới có thẩm quyền bấm nút `[ Phê Duyệt Kích Hoạt Phân Khu ]` (`PUT /api/v1/farms/{fId}/zones/{id}/activate`).
    *   Sau khi Owner duyệt kích hoạt sang `ACTIVE`, phân khu mới xuất hiện trong các dropdown để lên kế hoạch mùa vụ và điều phối sản xuất.

---

## 4. NHÓM 3: MÁY TRẠNG THÁI QA, KIỂM ĐỊNH & THÀNH PHẨM (QA & PRODUCT BATCH FSM)

### 4.1. Vòng đời Biên bản Kiểm định KCS (`qc_inspections` #46)
Cột `overall_result` đại diện cho kết luận kiểm tra chất lượng theo chuẩn Maker-Checker:
*   `PENDING` (Đang chờ kiểm định): Trạng thái khởi tạo khi kỹ thuật viên lấy mẫu KCS `sample_size`.
*   `PASSED` (Đạt chuẩn chất lượng): Tất cả các chỉ tiêu kiểm tra (`qc_inspection_items`) đều nằm trong ngưỡng an toàn. Lô hàng đủ điều kiện cấp mã truy xuất và in tem QR.
*   `REJECTED` (Không đạt chuẩn): Phát hiện dư lượng hóa chất vượt ngưỡng, nấm mốc hoặc sâu bệnh. Lô hàng bị từ chối xuất xưởng.
*   `CONDITIONAL` (Đạt có điều kiện): Cần xử lý bổ sung (ví dụ: rửa sạch lại, sấy thêm nhiệt độ, đóng gói lại bao bì) trước khi được đánh giá lại lần 2.

### 4.2. Vòng đời Lô Thành phẩm Đóng gói (`product_batches` #44)

```mermaid
stateDiagram-v2
    [*] --> PENDING_APPROVAL: Gom nguồn thu hoạch & Đóng gói lô
    PENDING_APPROVAL --> READY_TO_PRINT: KCS duyệt PASSED & Cấp traceability_code
    PENDING_APPROVAL --> REJECTED: KCS duyệt REJECTED (Hỏng/Dư lượng hóa chất)
    READY_TO_PRINT --> PRINTED: Thủ kho đã in tem QR dán lên sản phẩm
    PRINTED --> SELLING: Đưa vào kho thành phẩm & Mở bán sỉ
    SELLING --> RECALLED: Phát hiện sự cố an toàn thực phẩm trên thị trường
    PRINTED --> RECALLED: Thu hồi trước khi rời kho
    RECALLED --> [*]: Lưu vết biên bản thu hồi & Tiêu hủy
    REJECTED --> [*]: Phong tỏa & Xử lý hủy
```

#### Quy tắc Chuyển Trạng thái Lô Thành phẩm:
1.  **`PENDING_APPROVAL`:** Khởi tạo khi tạo lô mới gom từ `harvest_records` qua `product_batch_sources`. Khóa chức năng in tem và khóa bán sỉ.
2.  **`READY_TO_PRINT`:** Kích hoạt ngay khi biên bản QC đạt `PASSED`. Hệ thống tự động sinh mã UUID/NanoID duy nhất cho `traceability_code` và đóng băng toàn bộ dữ liệu lịch sử vào `traceability_snapshots` (#49).
3.  **`PRINTED`:** Đánh dấu sau khi thủ kho thực hiện in tem nhãn QR qua máy in công nghiệp (Ghi nhận vào `label_print_logs` #50).
4.  **`SELLING`:** Cho phép chọn lô này trong các dòng chi tiết đơn đặt hàng (`sales_order_items.product_batch_id`) và xuất kho giao hàng (`sales_delivery_items.product_batch_id`).
5.  **`RECALLED` (Thu hồi Khẩn cấp):**
    *   Áp dụng quyền khẩn cấp `PERM_QC_RECALL` bởi Ban Giám đốc.
    *   Bắt buộc phải ghi nhận người ra lệnh thu hồi `recalled_by_user_id`, thời gian `recalled_at`, và nguyên nhân chi tiết **`recall_reason`**.
    *   Khi lô bị `RECALLED`: Hệ thống lập tức phong tỏa toàn bộ số tồn kho còn lại (`remaining_quantity`), ngừng cho phép xuất hàng, và trên trang quét mã QR của người tiêu dùng sẽ hiện thông báo cảnh báo ĐỎ: *"Cảnh báo an toàn: Lô sản phẩm này đã có lệnh thu hồi từ nhà sản xuất!"*.

---

## 5. NHÓM 4: MÁY TRẠNG THÁI TÀI CHÍNH, BÁN HÀNG & CÔNG NỢ (COMMERCE & FINANCE FSM)

### 5.1. Đồng bộ Trạng thái Đơn Bán sỉ (`sales_orders` #62)
Đơn bán sỉ vận hành song song hai máy trạng thái: Trạng thái Vận đơn (`status`) và Trạng thái Thanh toán (`payment_status`):

#### 1. Trạng thái Vận đơn (`sales_orders.status`):
*   `PENDING` (Chờ xử lý): Nhân viên kinh doanh tạo đơn đặt hàng sỉ cho khách đối tác (`partner_id`).
*   `CONFIRMED` (Đã xác nhận): Kế toán/Quản lý duyệt đơn hàng, thực hiện giữ chỗ hàng tồn kho:
    $$\text{product\_batches.reserved\_quantity} = \text{reserved\_quantity} + \text{order\_quantity}$$
*   `DELIVERED` (Đang giao hàng): Đã xuất ít nhất một phiếu giao hàng (`sales_deliveries` #64) và hàng đã bàn giao cho đối tác vận chuyển.
*   `COMPLETED` (Đã hoàn tất): Toàn bộ số lượng đặt hàng đã được giao đủ (`sales_order_items.shipped_quantity == sales_order_items.quantity`) và khách hàng đã ký biên bản nhận hàng. Khóa cứng đơn hàng.
*   `CANCELLED` (Đã hủy): Hủy đơn hàng trước khi giao. Giải phóng số lượng đã đặt trước:
    $$\text{product\_batches.reserved\_quantity} = \text{reserved\_quantity} - \text{order\_quantity}$$

#### 2. Trạng thái Thanh toán (`sales_orders.payment_status`):
Tự động đồng bộ dựa trên số tiền tích lũy:
*   `UNPAID`: Khi `paid_amount == 0.00` và `debt_amount == final_amount`.
*   `PARTIALLY_PAID`: Khi `0.00 < paid_amount < final_amount`.
*   `PAID`: Khi `paid_amount == final_amount` và `debt_amount == 0.00`.
*   `REFUNDED`: Khi đơn hàng bị hủy/trả hàng và tiền đã hoàn lại cho khách hàng.

### 5.2. Vòng đời Sổ Nợ (`debt_records` #66)
*   `ACTIVE`: Khoản nợ mới phát sinh từ Đơn bán sỉ (Phải thu - `RECEIVABLE`) hoặc Phiếu nhập mua vật tư (Phải trả - `PAYABLE`), còn trong hạn thanh toán (`today <= due_date`).
*   `OVERDUE`: Ngày hiện tại đã vượt quá hạn thanh toán (`today > due_date`) mà nợ chưa trả hết (`remaining_debt > 0.00`). Hệ thống tự động cảnh báo công nợ quá hạn trên Dashboard Tài chính.
*   `SETTLED` (Đã tất toán): Toàn bộ nợ đã được thanh toán hết (`remaining_debt == 0.00`, `paid_amount == total_debt`). Khóa cứng hồ sơ nợ.
*   `BAD_DEBT` (Nợ khó đòi / Nợ xấu): Đối tác mất khả năng thanh toán hoặc giải thể, kế toán duyệt chuyển sang nợ xấu để lập quỹ dự phòng rủi ro.

### 5.3. Vòng đời Giao dịch Thanh toán (`payment_transactions` #67)
*   `PENDING`: Ghi nhận phiếu thu/chi tạm tính hoặc giao dịch chuyển khoản VietQR đang chờ tiền về tài khoản ngân hàng.
*   `COMPLETED`: Tiền đã vào tài khoản thực tế, kế toán xác nhận (`confirmed_by_user_id`, `confirmed_at`). Kích hoạt tạo bản ghi phân bổ thanh toán `payment_allocations` (#68), tự động trừ số nợ còn lại trong `debt_records` và cập nhật `paid_amount` trên `sales_orders`.
*   `CANCELLED`: Giao dịch bị hủy do nhầm lẫn hoặc giao dịch ngân hàng không thành công.

---

## 6. NHÓM 5: MÁY TRẠNG THÁI NHÂN SỰ & ĐIỀU PHỐI (HR & WORKFORCE FSM)

### 6.1. Vòng đời Nhân sự (`employees` #51)
*   `ACTIVE`: Nhân viên đang làm việc bình thường tại trang trại.
*   `ON_LEAVE`: Nhân viên đang trong kỳ nghỉ phép đã được duyệt (`leave_requests`).
*   `RESIGNED`: Nhân viên đã thôi việc có thông báo và bàn giao công việc hoàn tất.
*   `TERMINATED`: Nhân viên bị chấm dứt hợp đồng lao động do vi phạm kỷ luật hoặc hết hạn hợp đồng.

### 6.2. Phân loại Chấm công GPS Thực địa (`time_attendances.status` #54)
Được đánh giá tự động dựa trên thời gian và tọa độ GPS khi bấm Check-in:
*   `VALID` (Hợp lệ): Check-in đúng giờ và khoảng cách GPS so với tâm trang trại $\le$ `farms.geofence_radius_m`.
*   `LATE` (Đi muộn): Check-in sau giờ bắt đầu ca làm việc (`late_minutes > 0`).
*   `EARLY_DEPARTURE` (Về sớm): Check-out trước giờ kết thúc ca làm việc (`early_leave_minutes > 0`).
*   `OUT_OF_RANGE` (Ngoài phạm vi): Tọa độ check-in nằm ngoài bán kính quy định của trang trại (`gps_distance_m > farms.geofence_radius_m`). Hệ thống vẫn ghi nhận lịch sử kèm ảnh chụp selfie nhưng gắn nhãn cảnh báo để người quản lý duyệt thủ công (`is_adjusted = true`).
*   `ABSENT` (Vắng mặt): Không có bản ghi check-in trong ngày làm việc đã được phân ca.

### 6.3. Vòng đời Điều phối Nhiệm vụ Hiện trường (`farm_tasks` #57)
*   `TODO` (Cần làm) $\rightarrow$ `IN_PROGRESS` (Đang thực hiện) $\rightarrow$ `PENDING_REVIEW` (Chờ nghiệm thu) $\rightarrow$ `DONE` (Hoàn thành) / `CANCELLED` (Hủy bỏ).

---

## 7. DANH MỤC 6 BẢNG BẤT BIẾN TUYỆT ĐỐI (IMMUTABLE LEDGERS)

Hệ thống quy định 6 bảng đóng vai trò là Sổ cái Kế toán và Nhật ký Kiểm toán Bất biến (Append-Only Ledgers). Đối với các bảng này:
*   **QUY TẮC CỐT TỬ:** **CHỈ CHO PHÉP CÂU LỆNH `INSERT`**. 
*   **CẤM TUYỆT ĐỐI** mọi câu lệnh `UPDATE` và `DELETE` vật lý tại tầng Service, Repository, DTO và Database Triggers. Bất kỳ nỗ lực sửa đổi nào đối với các bảng này đều bị coi là hành vi xâm phạm tính toàn vẹn dữ liệu kế toán và kiểm toán.

| STT | Tên Bảng Sổ Cái | Ý Nghĩa Nghiệp Vụ Bất Biến | Căn Cứ Idempotency / Toàn Vẹn |
| :---: | :--- | :--- | :--- |
| **1** | **`audit_logs`** (#10) | Nhật ký vết kiểm toán mọi hành động truy cập, thêm, sửa, xóa, đăng nhập của toàn bộ người dùng và hệ thống. Lưu vết JSON `old_value`, `new_value`, IP, User-Agent, thời gian thực thi. | Bất biến phục vụ an ninh mạng và điều tra sự cố. |
| **2** | **`warehouse_inventory_transactions`** (#38) | Sổ cái Thẻ kho ghi nhận mọi biến động xuất, nhập, điều chuyển, kiểm kê vật tư. Ghi nhận `direction`, `quantity`, `balance_before`, `balance_after`. | Khóa chống trùng: `uk_inv_trans_item_idempotent (reference_doc_type, reference_item_id, direction)`. |
| **3** | **`product_batch_transactions`** (#48) | Sổ cái Biến động Lô thành phẩm đóng gói (Xuất bán, nhập kho thu hoạch, hủy hỏng, thu hồi). Ghi nhận `direction`, `quantity`, `balance_before`, `balance_after`. | Đẳng thức toán học: `chk_batch_trans_balance_math`. |
| **4** | **`traceability_snapshots`** (#49) | Bản chụp Đóng băng Dữ liệu Truy xuất Nguồn gốc Lô thành phẩm khi KCS duyệt ĐẠT. Lưu trữ thông tin doanh nghiệp, nhật ký canh tác, VietGAP, biên bản KCS dạng JSON đóng băng. | Mã băm bảo mật SHA-256 `snapshot_hash` chống giả mạo. |
| **5** | **`label_print_logs`** (#50) | Nhật ký Lịch sử In Tem Nhãn QR Truy xuất. Ghi nhận người in `printed_by_user_id`, số lượng in `print_quantity`, kích thước tem `label_size`, model máy in `printer_model`, thời gian in `printed_at`. | Ràng buộc số lượng in `chk_label_print_qty: print_quantity > 0`. |
| **6** | **`payment_allocations`** (#68) | Sổ cái Phân bổ Dòng tiền Thanh toán vào từng Hồ sơ Nợ cụ thể. Ghi nhận số tiền trích từ giao dịch `payment_id` để trừ vào khoản nợ `debt_record_id`. | Khóa duy nhất: `uk_payment_allocations_pay_debt (payment_id, debt_record_id)`. |

---
*Văn kiện `SPEC-STATE-002` là quy chuẩn bắt buộc để lập trình Máy trạng thái và Bộ chặn Immutability trong toàn bộ mã nguồn Farm SaaS.*
