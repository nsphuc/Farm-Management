# ĐẶC TẢ NGHIỆP VỤ LÕI & QUY TẮC MIỀN HỆ THỐNG AGRI-ERP
## (MASTER BUSINESS SPECIFICATION & DOMAIN RULES)

> **Mã văn kiện:** `SPEC-CORE-001`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Là Khung Tham Chiếu Nghiệp Vụ Cốt Lõi Cho Toàn Bộ Dự Án.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Phạm vi ràng buộc:** 100% Logic Nghiệp vụ Backend (Spring Boot Services), Database Triggers/Constraints, REST API DTOs, và Giao diện Người dùng (React Workspaces).

---

## 1. RANH GIỚI HỆ THỐNG & MÔ HÌNH TỔ CHỨC PHÂN CẤP (ORGANIZATIONAL BOUNDARIES)

### 1.1. Bản chất Phần mềm B2B Multi-Tenant Đa Trang trại & Mô hình Phân cấp 4 Cấp (4-Tier Hierarchy)
*   Hệ thống Farm SaaS là nền tảng quản trị nguồn lực nông nghiệp (Agri-ERP) theo mô hình **B2B Multi-Tenant**, phục vụ các Doanh nghiệp, Tập đoàn Nông nghiệp, Hợp tác xã (HTX) và Liên minh trang trại sở hữu nhiều cơ sở sản xuất trên các địa bàn địa lý phân tán.
*   Cơ cấu tổ chức và điều hành của hệ thống được chuẩn hóa thành **4 Cấp bậc (4-Tier Governance Model)**:
    1.  **Cấp 1 (`SYSTEM` Scope): Quản trị Nền tảng SaaS (`ROLE_SUPER_ADMIN`):** Quản lý định danh các khách hàng thuê (`tenants` #1), các gói đăng ký tài nguyên (`tenant_subscriptions` #2) và nhật ký an ninh toàn hệ thống. Tuyệt đối không can thiệp vào dữ liệu sản xuất của khách hàng.
    2.  **Cấp 2 (`TENANT` Scope): Doanh nghiệp / Chủ chuỗi Trang trại (`ROLE_FARM_OWNER`):** Đại diện pháp nhân (`enterprises` #3), độc quyền tạo trang trại mới (`PERM_FARM_CREATE`), tuyển dụng và bổ nhiệm Giám đốc trang trại (`ROLE_FARM_MANAGER`), duyệt hạn mức công nợ khách hàng, duyệt kế hoạch ngân sách đầu tư (`budgets`), và là người có thẩm quyền tối cao ký xác nhận kết toán chu kỳ (`Cycle Settlement Confirmation`).
    3.  **Cấp 3 (`FARM` Scope): Ban Giám đốc Cơ sở Thực địa (`ROLE_FARM_MANAGER`):** Điều hành trực tiếp tại trang trại (`farms` #11), quy hoạch phân khu (`production_zones` #13), quản lý kho (`warehouses` #26), tuyển dụng nhân sự Cấp 4 tại trại, và đóng vai trò **Checker** phê duyệt toàn bộ chứng từ phát sinh tại trại (phiếu kho, phiếu chi, đơn bán sỉ, kiểm định KCS, thu hồi lô, và ký duyệt kết toán chu kỳ trước khi trình Owner).
    4.  **Cấp 4 (`FARM` Scope): Đội ngũ Chuyên môn Thực thi Hiện trường (Maker):**
        *   `ROLE_TECHNICAL_STAFF`: Lên lịch/phác đồ mùa vụ, thú y, lấy mẫu KCS hiện trường (Maker), giao việc kỹ thuật.
        *   `ROLE_WAREHOUSE_STAFF`: Quản lý thẻ kho FIFO/FEFO, lập phiếu nhập/xuất/chuyển/kiểm kê (Maker), in tem nhãn nhiệt QR, xuất xe giao hàng.
        *   `ROLE_ACCOUNTANT`: (Scope tại trại) Lập phiếu chi, đơn bán sỉ, phiếu thanh toán VietQR, phân bổ công nợ FIFO, đối chiếu sổ kho, lập báo cáo tài chính và bảng kết toán chu kỳ.
        *   `ROLE_FIELD_STAFF`: Chấm công GPS cá nhân, nhận nhiệm vụ, ghi nhật ký chăm sóc, ghi nhận sản lượng thu hoạch thực tế.

```mermaid
graph TD
    subgraph "CẤP 1: SYSTEM (Platform Level)"
        SA[ROLE_SUPER_ADMIN: Quản trị nền tảng SaaS - tenants #1, subscriptions #2]
    end

    subgraph "CẤP 2: TENANT (Enterprise Level)"
        FO[ROLE_FARM_OWNER: Chủ đầu tư chuỗi - enterprises #3, farms #11, budgets #69, Cycle Settlement]
    end

    subgraph "CẤP 3: FARM (Facility Management - Checker)"
        FM[ROLE_FARM_MANAGER: Giám đốc trại - zones #13, Checker kho, chi tiêu, bán hàng, KCS, ký kết toán]
    end

    subgraph "CẤP 4: FARM (Specialized Execution - Maker)"
        TS[ROLE_TECHNICAL_STAFF: Phác đồ mùa vụ, thú y, Maker KCS]
        WS[ROLE_WAREHOUSE_STAFF: Maker phiếu kho, in tem QR, xuất xe]
        AC[ROLE_ACCOUNTANT: Maker phiếu chi, đơn bán, VietQR, công nợ]
        FS[ROLE_FIELD_STAFF: Chấm công GPS, nhật ký canh tác, thu hoạch]
    end

    SA --> FO --> FM --> TS & WS & AC & FS
```

### 1.2. Phân định Trách nhiệm Cấp Tổ chức (`tenants` & `enterprises`)
*   **Bảng `tenants` (#1):** Quản lý định danh thuê bao nền tảng (`code`, `name`), trạng thái dịch vụ `status` (`'ACTIVE'`, `'SUSPENDED'`, `'INACTIVE'`), và gói đăng ký (`tenant_subscriptions` #2 với giới hạn `max_farms`, `max_users`).
*   **Bảng `enterprises` (#3):** Lưu trữ thông tin hồ sơ pháp lý và thương mại chính thức của doanh nghiệp (Quan hệ 1-1 với `tenants` qua khóa `tenant_id UNIQUE`):
    *   *Thông tin pháp lý:* Mã số thuế `tax_number`, người đại diện pháp luật `legal_representative`, địa chỉ trụ sở `headquarter_address`, ngày thành lập `established_date`, logo công ty `logo_url`.
    *   *Tích hợp Thanh toán VietQR Quốc gia:* Lưu thông tin thụ hưởng thanh toán tập trung gồm Mã định danh ngân hàng `bank_bin` (VD: `970415` - VietinBank), tên ngân hàng `bank_name`, số tài khoản ngân hàng `bank_account_no`, tên chủ tài khoản `bank_account_name`. Khi khách hàng thanh toán đơn bán sỉ (`sales_orders`), hệ thống tự động trích xuất thông tin VietQR của `enterprises` để tạo chuỗi mã QR chuẩn NAPAS 24/7.
    *   *Chứng chỉ Chất lượng:* `certifications_json` lưu trữ danh sách chứng chỉ nông nghiệp cấp doanh nghiệp (VietGAP, GlobalGAP, Organic, ISO 22000) phục vụ tự động đính kèm vào tem nhãn truy xuất nguồn gốc.

### 1.3. Phân định Cấp Cơ sở Vận hành Thực địa (`farms`)
*   **Bảng `farms` (#11):** Đại diện cho một trang trại vật lý độc lập thuộc một tenant cụ thể:
    *   *Loại hình trang trại (`farm_type`):* Hệ thống chuẩn hóa 3 loại hình trang trại duy nhất: `'CROP'` (Trồng trọt), `'LIVESTOCK'` (Chăn nuôi), và `'MIXED'` (Hỗn hợp Trồng trọt & Chăn nuôi). Loại bỏ hoàn toàn thủy sản (`AQUACULTURE` / `AQUA` / `POND`) khỏi quy trình tác nghiệp.
    *   *Quy mô & Tọa độ Địa lý:* Tổng diện tích `total_area_m2`, tọa độ tâm trang trại gồm Vĩ độ `latitude` (DECIMAL 10,8) và Kinh độ `longitude` (DECIMAL 11,8).
    *   *Bán kính Rào chắn Chấm công GPS (`geofence_radius_m`):* Giá trị mặc định `300` mét (Check constraint `geofence_radius_m > 0`). Được sử dụng làm căn cứ toán học tính toán khoảng cách check-in/check-out của công nhân viên (`time_attendances.gps_distance_m`).
    *   *Giám đốc Trang trại:* `manager_user_id` liên kết với bảng `users` (#5).
*   **Rào chắn Dữ liệu Bất biến (The Farm Barrier Guard):** 
    *   Bảng `farms` sở hữu khóa duy nhất tổ hợp `UNIQUE KEY uk_farms_tenant_id (tenant_id, id)`.
    *   Tất cả 40+ bảng vận hành thực địa (Kho, Mùa vụ, Đàn nuôi, Chấm công, Thu hoạch, Đơn hàng) đều mang cặp khóa ngoại composite `(tenant_id, farm_id)` trỏ trực tiếp về `farms(tenant_id, id)`. Tuyệt đối ngăn chặn dữ liệu của Trang trại A bị truy cập chéo bởi nhân sự chỉ được phân quyền tại Trang trại B.

---

## 2. QUY TẮC SẢN XUẤT & TIÊU HAO TỰ ĐỘNG (ATOMIC AUTO-BACKFLUSHING)

### 2.1. Phân hệ Canh tác Trồng trọt & Chăn nuôi Thực địa
*   **Trồng trọt:**
    *   Giống cây trồng (`crop_types` #18): Mã giống `variety_code`, tên giống `name`, thời gian sinh trưởng chuẩn `growth_days_standard`, nhu cầu nước `water_need_m3_day`, dải nhiệt độ tối ưu `optimal_temp_min` - `optimal_temp_max`.
    *   Mùa vụ (`crop_seasons` #19): Gắn liền với phân khu canh tác `zone_id` (#13) và chu kỳ vận hành `operational_cycle_id` (#16). Quản lý diện tích gieo trồng **`planted_area_m2`**, lượng giống gieo `seed_quantity`, sản lượng ước tính `estimated_yield_kg` và sản lượng thực tế `actual_yield_kg`.
    *   Nhật ký Canh tác (`farming_logs` #20): Ghi nhận tác vụ hiện trường với đúng 7 loại hoạt động theo `chk_farming_logs_activity`: `'SOIL_TILLAGE'` (Làm đất), `'IRRIGATION'` (Tưới tiêu), `'FERTILIZATION'` (Bón phân), `'PESTICIDE_APPLICATION'` (Phun thuốc BVTV), `'PRUNING'` (Tỉa cành), `'WEEDING'` (Làm cỏ), `'HARVESTING'` (Thu hoạch).
*   **Chăn nuôi:**
    *   Giống vật nuôi (`livestock_breeds` #21): Loài `species` (`'CATTLE'`, `'SWINE'`, `'POULTRY'`, `'GOAT'`, `'SHEEP'`, `'AQUA'`), tên giống `breed_name`, chu kỳ nuôi chuẩn `standard_growth_days`, trọng lượng đích `target_weight_kg`.
    *   Đàn/Lứa nuôi (`livestock_groups` #22) & Cá thể đeo thẻ RFID (`livestock_individuals` #23).
    *   Sự kiện Thú y & Chăm sóc (`livestock_events` #25): Ghi nhận với đúng 7 loại sự kiện theo `chk_livestock_events_type`: `'VACCINATION'` (Tiêm phòng), `'WEIGHT_CHECK'` (Cân trọng lượng), `'BREEDING'` (Phối giống), `'BIRTH'` (Sinh sản), `'MEDICAL_TREATMENT'` (Điều trị bệnh), `'TRANSFER'` (Điều chuyển chuồng), `'SLAUGHTER'` (Giết mổ/Thanh lý).

### 2.2. Cơ chế Tự động Xuất kho Nguyên tử (Atomic Material Backflushing)
Nhằm triệt tiêu hoàn toàn độ trễ giữa thực tế sử dụng vật tư trên đồng ruộng/chuồng trại và số liệu sổ sách kho:
1.  **Khai báo Vật tư Tiêu hao:** Khi kỹ sư hoặc công nhân ghi nhật ký canh tác (`farming_logs`) hoặc sự kiện thú y (`livestock_events`), nếu có tiêu hao vật tư (phân bón, thuốc BVTV, thức ăn chăn nuôi, vắc-xin), danh sách vật tư bắt buộc phải được ghi chi tiết vào bảng:
    *   `farming_log_supplies` (#41) đối với trồng trọt.
    *   `livestock_event_supplies` (#42) đối với chăn nuôi.
2.  **Thông tin Tiêu hao Bắt buộc:** Mỗi dòng vật tư sử dụng phải chỉ định rõ `material_id` (#28), kho xuất hàng `warehouse_id` (#26), số lô cụ thể `batch_number`, số lượng thực tế sử dụng `actual_quantity`, đơn vị `unit`, đơn giá vốn xuất kho `unit_price`, và thành tiền `total_price`.
3.  **Kích hoạt Tự động Phiếu Xuất kho (`warehouse_issues` #34):**
    *   Backend tự động tạo một Phiếu xuất kho trong `warehouse_issues` với loại xuất `issue_type = 'PRODUCTION_BACKFLUSH'`, cờ đánh dấu hệ thống tự sinh `is_backflushed = TRUE`, liên kết `farming_log_id` hoặc `livestock_event_id`, và chuyển trạng thái ngay sang `status = 'COMPLETED'`.
    *   Tự động sinh các dòng chi tiết `warehouse_issue_items` (#35) tương ứng với từng mặt hàng tiêu hao, gán ngược khóa ngoại `warehouse_issue_item_id` vào `farming_log_supplies` hoặc `livestock_event_supplies`.
    *   Trừ trực tiếp số lượng tồn kho khả dụng và tồn kho thực tế trong `warehouse_inventory` (#31) theo đúng số lô `batch_number`.
    *   Ghi nhận bút toán thẻ kho vào Sổ cái biến động kho `warehouse_inventory_transactions` (#38) với `direction = 'OUT'` và `transaction_type = 'OUTWARD'`.
    *   Tự động hạch toán chi phí sản xuất trực tiếp vào `farm_expenses` (#60) với nguồn phát sinh `expense_source = 'INVENTORY_BACKFLUSH'`, liên kết chứng từ gốc `reference_id = warehouse_issues.id`.
4.  **Tính Nguyên tử Tuyệt đối (Database Transaction Atomicity):** Toàn bộ chuỗi thao tác (Ghi nhật ký $\rightarrow$ Trừ tồn kho $\rightarrow$ Ghi thẻ kho $\rightarrow$ Tạo phiếu xuất kho $\rightarrow$ Hạch toán chi phí) **BẮT BUỘC PHẢI THỰC THI TRONG CÙNG MỘT TRANSACTION**. Nếu bất kỳ bước nào thất bại (ví dụ: kho không đủ tồn khả dụng - `INSUFFICIENT_STOCK`), toàn bộ transaction phải bị rollback và nhật ký không được lưu.
5.  **Cơ chế Chống ghi trùng Lặp (Idempotency Guard):**
    *   Bảng `warehouse_issues` sở hữu 2 cột sinh ảo phục vụ khóa chống trùng:
        ```sql
        active_farming_backflush BIGINT GENERATED ALWAYS AS (CASE WHEN status <> 'CANCELLED' AND farming_log_id IS NOT NULL THEN farming_log_id ELSE NULL END) VIRTUAL,
        active_livestock_backflush BIGINT GENERATED ALWAYS AS (CASE WHEN status <> 'CANCELLED' AND livestock_event_id IS NOT NULL THEN livestock_event_id ELSE NULL END) VIRTUAL,
        UNIQUE KEY uk_wh_issue_farm_log_wh (active_farming_backflush, warehouse_id),
        UNIQUE KEY uk_wh_issue_live_event_wh (active_livestock_backflush, warehouse_id)
        ```
    *   Đảm bảo một nhật ký canh tác hoặc sự kiện chăn nuôi không bao giờ có thể sinh ra 2 phiếu xuất kho hợp lệ tại cùng một kho vật tư.

---

## 3. QUY TẮC KHO BÃI & ĐA MÃ VẠCH / ĐƠN VỊ QUY ĐỔI (WAREHOUSE & MULTI-BARCODE)

### 3.1. Đơn vị Chuẩn (`standard_unit`) vs Đơn vị Nhập/Xuất Thực tế (`entered_unit`)
*   **Đơn vị Chuẩn Lưu kho (`materials.standard_unit` #28):** Là đơn vị đo lường cơ sở nhỏ nhất để quản lý tồn kho, định giá giá thành, và chạy thuật toán cân bằng vật liệu (VD: `KG`, `LITER`, `PIECE`). Toàn bộ số lượng lưu trữ trong `warehouse_inventory.quantity_on_hand` và Sổ cái `warehouse_inventory_transactions.quantity` **LUÔN LUÔN ĐƯỢC TÍNH THEO `standard_unit`**.
*   **Đơn vị Nhập/Xuất Thực tế (`entered_unit`):** Được lưu tại `warehouse_receipt_items.entered_unit` (#33) và `warehouse_issue_items.entered_unit` (#35). Đại diện cho đơn vị bao bì thương mại thực tế khi giao dịch với Nhà cung cấp hoặc xuất dùng tại hiện trường (VD: `BAG` 25kg, `BOX` 24 chai, `CAN` 5 lít).
*   **Hệ số Quy đổi (`conversion_factor`):** Định nghĩa tỷ lệ toán học giữa Đơn vị thực tế và Đơn vị chuẩn:
    $$\text{Số lượng quy chuẩn (quantity)} = \text{Số lượng thực nhập/xuất (entered_quantity)} \times \text{Hệ số quy đổi (conversion_factor)}$$
    *(Ràng buộc SQL: `chk_unit_conv_factor: conversion_factor > 0.0000`)*.

### 3.2. Cơ chế Quét Đa Mã Vạch Tự động Nhận diện Bao bì
Hệ thống hỗ trợ quét mã vạch 1D/2D bằng máy quét công nghiệp hoặc camera di động thông qua cấu trúc liên kết giữa 2 bảng:
1.  **Mã Vạch Chuẩn Mặt hàng (`materials.barcode`):**
    *   Đại diện cho mã vạch của đơn vị chuẩn (`standard_unit`).
    *   Khóa duy nhất: `UNIQUE KEY uk_materials_tenant_barcode (tenant_id, barcode)`.
    *   Khi thủ kho quét `materials.barcode`: Hệ thống tự động chọn mặt hàng, gán `entered_unit = standard_unit`, và đặt `conversion_factor = 1.0000`.
2.  **Mã Vạch Bao bì Đơn vị Quy đổi (`material_unit_conversions.unit_barcode` #29):**
    *   Đại diện cho mã vạch dán trên quy cách đóng gói riêng biệt (VD: Mã vạch dán trên Bao 25kg, Thùng 12 hộp).
    *   Khóa duy nhất: `UNIQUE KEY uk_unit_conv_tenant_barcode (tenant_id, unit_barcode)`.
    *   Khi thủ kho quét `material_unit_conversions.unit_barcode`: Hệ thống tự động nhận diện chính xác `material_id`, tự động điền `entered_unit = unit_name`, tự động áp dụng `conversion_factor`, và đánh dấu cờ `is_purchase_unit` (nếu nhập kho) hoặc `is_dispatch_unit` (nếu xuất kho). Thủ kho chỉ cần nhập số lượng bao/thùng, hệ thống tự động quy về đơn vị lưu kho cơ sở.

### 3.3. Chiến lược Xuất kho Ưu tiên Hạn Dùng (FEFO / FIFO)
*   Cột `materials.dispatch_strategy` bắt buộc tuân theo `chk_materials_dispatch`:
    *   `'FEFO'` *(First Expired, First Out - Hết hạn trước, Xuất trước):* Áp dụng bắt buộc đối với Hóa chất, Thuốc BVTV, Vắc-xin, Thuốc thú y, Phân bón sinh học. Thuật toán gợi ý xuất kho sẽ tự động sắp xếp các lô tồn kho (`warehouse_inventory`) theo thứ tự `expiry_date ASC` (Ưu tiên lô có ngày hết hạn gần nhất).
    *   `'FIFO'` *(First In, First Out - Nhập trước, Xuất trước):* Áp dụng đối với Dụng cụ, Bao bì, Vật tư tiêu hao cơ khí, Đất sạch, Giá thể. Sắp xếp các lô tồn kho theo thứ tự ngày nhập `created_at ASC`.

---

## 4. QUY TẮC AN TOÀN SINH HỌC & THỜI GIAN CÁCH LY (PHI / WITHDRAWAL PERIOD)

### 4.1. Quy tắc Thời gian Cách ly Thuốc BVTV (Pre-Harvest Interval - PHI)
*   **Định nghĩa:** PHI là số ngày tối thiểu bắt buộc phải cách ly từ ngày phun thuốc bảo vệ thực vật cuối cùng cho đến ngày được phép thu hoạch sản phẩm cây trồng, nhằm đảm bảo dư lượng thuốc phân hủy dưới ngưỡng an toàn theo quy chuẩn VietGAP/GlobalGAP.
*   **Công thức Tính toán Tự động:**
    1.  Mỗi loại thuốc BVTV được khai báo thời gian cách ly mặc định tại bảng `materials.default_phi_days` (#28).
    2.  Khi ghi nhận nhật ký phun thuốc (`farming_logs` #20 với `activity_type = 'PESTICIDE_APPLICATION'`), hệ thống tự động lấy `materials.default_phi_days` làm giá trị đề xuất cho `farming_logs.phi_days` (có thể điều chỉnh tăng nếu thời tiết mưa ít).
    3.  Backend tự động tính toán Ngày kết thúc cách ly an toàn:
        $$\text{phi\_end\_date} = \text{farming\_logs.log\_date} + \text{farming\_logs.phi\_days}$$
*   **Chốt chặn An toàn Thu hoạch (Harvest Block Gate):**
    *   Khi người dùng tạo Biên bản Thu hoạch (`harvest_records` #43 với `source_type = 'CROP_SEASON'`) tại một mùa vụ:
    *   Backend tự động truy vấn tất cả các nhật ký canh tác của mùa vụ đó (`farming_logs` liên kết qua `season_id`):
        $$\text{MaxPHIDate} = \max(\text{farming\_logs.phi\_end\_date})$$
    *   **ĐIỀU KIỆN CHẶN:** Nếu ngày thu hoạch thực tế `harvest_records.harvest_date < MaxPHIDate`:
        *   Backend **LẬP TỨC TỪ CHỐI** yêu cầu tạo biên bản thu hoạch bằng ngoại lệ `SAFETY_VIOLATION_PHI_ACTIVE` (HTTP 400).
        *   Frontend hiển thị Cảnh báo Đỏ: *"Mùa vụ đang trong thời gian cách ly thuốc BVTV (Còn X ngày, đến ngày dd/MM/yyyy). Nghiêm cấm thu hoạch để đảm bảo an toàn thực phẩm!"*.

### 4.2. Quy tắc Thời gian Ngưng thuốc Thú y (Withdrawal Period)
*   **Định nghĩa:** Thời gian ngưng thuốc là khoảng thời gian từ khi ngừng sử dụng thuốc thú y/kháng sinh cho đàn nuôi hoặc cá thể cho đến khi được phép khai thác thịt, trứng, sữa hoặc xuất chuồng giết mổ.
*   **Công thức Tính toán Tự động:**
    1.  Khi ghi nhận sự kiện điều trị hoặc dùng vắc-xin (`livestock_events` #25 với `event_type IN ('MEDICAL_TREATMENT', 'VACCINATION')`), trường `withdrawal_days` được khai báo (Check constraint: `withdrawal_days >= 0`).
    2.  Backend tự động tính toán:
        $$\text{withdrawal\_end\_date} = \text{livestock\_events.event\_date} + \text{livestock\_events.withdrawal\_days}$$
*   **Chốt chặn An toàn Xuất chuồng / Thu hoạch Chăn nuôi:**
    *   Cấm tuyệt đối việc tạo biên bản thu hoạch (`harvest_records` với `source_type = 'LIVESTOCK_GROUP'`) hoặc tạo sự kiện giết mổ (`event_type = 'SLAUGHTER'`) nếu ngày hiện tại nhỏ hơn `withdrawal_end_date`.

---

## 5. QUY TẮC QA & TRUY XUẤT NGUỒN GỐC ĐA NGUỒN (QA & MULTI-SOURCE TRACEABILITY)

### 5.1. Mô hình Lô Thành phẩm Đa Nguồn (`product_batch_sources`)
Một Lô thành phẩm đóng gói xuất xưởng (`product_batches` #44) không nhất thiết chỉ đến từ một vụ mùa duy nhất. Hệ thống Agri-ERP cho phép hợp nhất nhiều nguồn nguyên liệu thô vào cùng một lô thành phẩm đóng gói thông qua bảng trung gian `product_batch_sources` (#45):
*   Ràng buộc toàn vẹn nguồn nguyên liệu theo `chk_batch_source_valid`:
    *   *Nguồn 1: Thu hoạch từ Biên bản Thu hoạch cụ thể* (`source_type = 'HARVEST_RECORD'` AND `harvest_record_id IS NOT NULL`).
    *   *Nguồn 2: Gom chung từ toàn bộ Mùa vụ Trồng trọt* (`source_type = 'CROP_SEASON'` AND `crop_season_id IS NOT NULL`).
    *   *Nguồn 3: Gom từ Đàn/Lứa Chăn nuôi* (`source_type = 'LIVESTOCK_GROUP'` AND `livestock_group_id IS NOT NULL`).
*   Mỗi nguồn đóng góp một sản lượng cụ thể `contributed_quantity > 0.00`, bảo đảm nguyên tắc bảo toàn vật chất:
    $$\text{product\_batches.initial\_quantity} = \sum \text{product\_batch\_sources.contributed\_quantity}$$

```mermaid
graph TD
    H1[harvest_records: Đợt hái 1 - 500kg] -->|source_type: HARVEST_RECORD| PBS[product_batch_sources]
    H2[harvest_records: Đợt hái 2 - 300kg] -->|source_type: HARVEST_RECORD| PBS
    PBS --> PB[product_batches: Lô Xoài Cát Chu Xuất Khẩu - 800kg]
    PB --> QC[qc_inspections: Kiểm định KCS Maker-Checker]
    QC -->|overall_result = PASSED| TS[traceability_snapshots: Đóng băng Dữ liệu Truy xuất]
    TS --> LP[label_print_logs: In Tem QR Truy xuất Quốc gia]
```

### 5.2. Quy trình Kiểm định Chất lượng (Maker-Checker KCS)
*   Mọi lô thành phẩm khi mới tạo lập mặc định ở trạng thái `product_batches.status = 'PENDING_APPROVAL'`. Tại trạng thái này, lô hàng **BỊ KHÓA HOÀN TOÀN**: Không được in tem truy xuất, không được đưa vào đơn bán hàng (`sales_order_items`), và không được xuất kho giao hàng.
*   **Quy trình Maker-Checker:**
    1.  *Maker (Kỹ thuật viên KCS):* Tiến hành lấy mẫu kiểm định (`qc_inspections` #46) với dung lượng mẫu `sample_size`, đơn vị mẫu `sample_unit`. Đánh giá các chỉ tiêu cảm quan, vi sinh, dư lượng hóa chất (`qc_inspection_items` #47). Đưa ra kết quả tổng thể `overall_result` (`'PENDING'`, `'PASSED'`, `'REJECTED'`, `'CONDITIONAL'`).
    2.  *Checker (Chủ trang trại / Trưởng phòng QA - `ROLE_FARM_OWNER`):* Phê duyệt biên bản KCS. Người thực hiện kiểm định **KHÔNG ĐƯỢC TỰ DUYỆT** kết quả của chính mình.
*   **Xử lý theo Kết quả Kiểm định:**
    *   Nếu `overall_result = 'PASSED'`: Lô thành phẩm được cập nhật `status = 'READY_TO_PRINT'`, ghi nhận người duyệt `approved_by_user_id` và thời gian duyệt `approved_at`. Hệ thống tự động sinh mã định danh truy xuất nguồn gốc duy nhất toàn cầu **`traceability_code`** (UUID v4 / NanoID 64 ký tự).
    *   Nếu `overall_result = 'REJECTED'`: Lô thành phẩm bị chuyển sang `status = 'REJECTED'`, ghi nhận `rejected_by_user_id` và `rejection_reason`. Toàn bộ lô bị phong tỏa và chỉ có thể lập biên bản hủy hoặc chuyển làm phân bón hữu cơ.

### 5.3. Cơ chế Đóng băng Bản chụp Truy xuất (`traceability_snapshots` #49)
Nhằm bảo đảm tính toàn vẹn và chống chối bỏ dữ liệu khi người tiêu dùng quét mã QR:
1.  **Thời điểm Kích hoạt:** Ngay khi lô thành phẩm được duyệt `PASSED`, hệ thống tự động trích xuất toàn bộ dữ liệu lịch sử sản xuất của lô hàng và lưu thành một bản ghi bất biến trong bảng `traceability_snapshots` (#49).
2.  **Cấu trúc Dữ liệu Đóng băng:**
    *   `enterprise_info_json`: Bản chụp thông tin doanh nghiệp, mã số thuế, địa chỉ trụ sở, thông tin liên hệ.
    *   `vietgap_cert_json`: Bản chụp các chứng chỉ chất lượng còn hiệu lực của doanh nghiệp/trang trại tại thời điểm thu hoạch.
    *   `farming_timeline_json`: Toàn bộ cây tiến trình lịch sử canh tác (Ngày làm đất, ngày gieo hạt, danh sách phân bón đã bón, danh sách thuốc BVTV đã phun kèm số ngày cách ly đã tuân thủ).
    *   `harvest_info_json`: Thông tin chi tiết ngày thu hoạch, khu vực thu hoạch, người thu hoạch.
    *   `qc_inspection_json`: Toàn bộ biên bản kiểm định chất lượng, người kiểm định, chỉ tiêu đạt chuẩn.
    *   `snapshot_hash`: Chuỗi mã băm bảo mật SHA-256 tính toán từ toàn bộ nội dung JSON trên.
3.  **Tính Bất biến Tuyệt đối:** Khi dữ liệu đã được ghi vào `traceability_snapshots`, mọi thay đổi sau đó đối với bảng nhật ký canh tác (`farming_logs`) hay thông tin mùa vụ gốc **KHÔNG LÀM THAY ĐỔI** nội dung bản chụp truy xuất này. Khi người tiêu dùng hoặc cơ quan thanh tra quét mã QR công khai trên bao bì sản phẩm, hệ thống chỉ đọc dữ liệu từ `traceability_snapshots` và tăng bộ đếm lượt quét `scan_count`.

---

## 6. QUY TẮC QUẢN TRỊ NHÂN SỰ, PHÂN CA, CHẤM CÔNG GPS/SELFIE 2 ĐẦU & GIAO VIỆC HIỆN TRƯỜNG

Áp dụng cho: `employees` (#51), `work_shifts` (#52), `shift_assignments` (#53), `time_attendances` (#54), `leave_requests` (#55), `overtime_requests` (#56), `farm_tasks` (#57), `farm_task_assignees` (#58).

### 6.1. Quy tắc Hồ Sơ Nhân Sự & Phân Ranh Phạm Vi Công Tác
1.  **Tiêu chuẩn Pháp lý Lao động:** Ngày sinh `employees.date_of_birth` bắt buộc thỏa mãn độ tuổi lao động tối thiểu $\ge 18$ tuổi. Quỹ ngày phép năm mặc định `annual_leave_quota = 12.0` ngày/năm (hoặc tùy chỉnh theo thâm niên/loại hợp đồng `contract_type` IN `'FULL_TIME'`, `'PART_TIME'`, `'SEASONAL'`, `'INTERN'`).
2.  **Liên kết Tài khoản SaaS Tùy chọn (1-1 Mapping):** 
    *   Hồ sơ nhân viên (`employees`) không bắt buộc phải có tài khoản đăng nhập hệ thống (`user_id` có thể là `NULL` đối với công nhân thời vụ chỉ cần chấm công điểm danh).
    *   Khi nhân viên được bổ nhiệm làm quản lý, thủ kho hoặc kỹ thuật viên, Quản trị viên thực hiện hành động Cấp tài khoản (Account Provisioning), hệ thống liên kết 1-1 qua `employees.user_id = users.id`.
3.  **Phân định Nhân sự Văn phòng vs Nhân sự Hiện trường:**
    *   *Nhân sự cấp Doanh nghiệp / Văn phòng (`employees.farm_id IS NULL`):* Ban Giám đốc, Kế toán tổng hợp, Chuyên viên nhân sự toàn tenant.
    *   *Nhân sự cấp Cơ sở Hiện trường (`employees.farm_id IS NOT NULL`):* Kỹ sư nông vụ, thủ kho trại, công nhân thu hoạch, bác sĩ thú y trực thuộc quản lý của một Trang trại cụ thể.

### 6.2. Quy tắc Phân Ca & Chấm Công GPS/Selfie 2 Đầu (Check-in / Check-out Guard)
1.  **Cấu trúc Ca làm việc (`work_shifts` #52):** Định nghĩa giờ bắt đầu `start_time`, giờ kết thúc `end_time`, thời gian nghỉ giữa ca `break_minutes`, và thời gian ân hạn đi muộn `grace_late_minutes` (ví dụ: 15 phút).
2.  **Chấm công GPS & Camera Selfie Bắt buộc 2 Đầu:**
    *   *Check-in đầu ca:* Nhân viên mở App di động, chụp ảnh selfie trực tiếp từ camera trước `check_in_photo_url` (chặn tải ảnh từ thư viện để chống chấm công hộ). Hệ thống lấy tọa độ GPS thực tế (`gps_latitude`, `gps_longitude`), tính khoảng cách Haversine `gps_distance_m` so với tâm trang trại `farms`. Nếu `gps_distance_m <= farms.geofence_radius_m`: Đạt chuẩn `VALID`. Nếu ngoài bán kính: Gán `status = 'OUT_OF_RANGE'`.
    *   *Check-out cuối ca:* Chụp ảnh selfie ra ca `check_out_photo_url`, ghi nhận tọa độ ra ca (`check_out_latitude`, `check_out_longitude`, `check_out_distance_m`).
3.  **Công thức Tính Toán Giờ Công Tự Động:**
    $$\text{working\_hours} = \max\left(0, \frac{\text{DATEDIFF\_MINUTES}(\text{check\_in\_time}, \text{check\_out\_time}) - \text{break\_minutes}}{60}\right)$$
    $$\text{late\_minutes} = \max(0, \text{DATEDIFF\_MINUTES}(\text{start\_time}, \text{check\_in\_time}) - \text{grace\_late\_minutes})$$
    $$\text{early\_leave\_minutes} = \max(0, \text{DATEDIFF\_MINUTES}(\text{check\_out\_time}, \text{end\_time}))$$
4.  **Cơ chế Điều chỉnh Công Có Kiểm toán (Audited Adjustment):** Khi có sự cố quên check-out hoặc lỗi GPS, Quản lý trang trại có thẩm quyền điều chỉnh giờ công. Bản ghi chấm công lưu vết chặt chẽ: `is_adjusted = TRUE`, ghi nhận người duyệt `adjusted_by_user_id`, lý do điều chỉnh bắt buộc `adjustment_reason`, cùng dấu thời gian nguyên bản `original_check_in` và `original_check_out`.

### 6.3. Quy tắc Nghỉ Phép, Làm Thêm Giờ & Giao Việc Hiện Trường Đa Nhân Sự
1.  **Quản lý Nghỉ phép (`leave_requests` #55):** Khi đơn xin nghỉ phép chuyển sang `status = 'APPROVED'`, hệ thống tự động trừ số ngày nghỉ `total_days` vào quỹ phép năm còn lại `employees.annual_leave_quota`. Cấm duyệt nếu số ngày nghỉ vượt quá quỹ phép khả dụng (trừ trường hợp nghỉ không hưởng lương).
2.  **Làm thêm giờ (`overtime_requests` #56):** Định nghĩa số giờ làm thêm `total_hours` và hệ số lương làm thêm `ot_multiplier` theo Bộ luật Lao động: `1.5` (ngày thường), `2.0` (ngày nghỉ hàng tuần), `3.0` (ngày lễ, tết).
3.  **Điều phối Công việc Đa Nhân sự (`farm_tasks` #57 & `farm_task_assignees` #58):**
    *   Mỗi công việc thuộc một loại hình cụ thể `task_type` (`PLANTING`, `FERTILIZING`, `HARVESTING`, `FEEDING`, `MAINTENANCE`, `SANITATION`) và mức độ ưu tiên `priority` (`LOW`, `MEDIUM`, `HIGH`, `URGENT`).
    *   Giao việc hỗ trợ mô hình nhóm: Trưởng nhóm phụ trách chính lưu tại `farm_tasks.assigned_to_employee_id`, đồng thời danh sách thành viên phối hợp được lưu tại bảng chi tiết `farm_task_assignees` với vai trò `role_in_task` (`LEADER` hoặc `MEMBER`).

---

## 7. QUY TẮC TẬP HỢP CHI PHÍ, PHÂN BỔ ĐA ĐỐI TƯỢNG, TÍNH GIÁ THÀNH & NGÂN SÁCH

Áp dụng cho: `cost_categories` (#59), `farm_expenses` (#60), `cost_allocations` (#61), `budgets` (#69), `budget_line_items` (#70).

### 7.1. Phân loại Chi phí & 4 Nguồn Phát sinh Nghiệp vụ
*   **Hệ thống Nhóm Chi phí Chuẩn Nông nghiệp (`cost_categories` #59):** Bắt buộc thuộc 5 nhóm chi phí theo `chk_cost_categories_type`:
    1.  `'MATERIALS'`: Chi phí nguyên vật liệu trực tiếp (hạt giống, phân bón, thuốc BVTV, thức ăn chăn nuôi).
    2.  `'DIRECT_LABOR'`: Chi phí nhân công trực tiếp (công nhân làm đất, chăm sóc, thu hoạch).
    3.  `'MACHINERY_FUEL'`: Chi phí máy móc cơ giới, dầu máy cày, điện chạy quạt thông gió nhà màng.
    4.  `'DEPRECIATION'`: Khấu hao tài sản cố định (nhà kính, hệ thống tưới nhỏ giọt, chuồng trại).
    5.  `'INDIRECT_OVERHEAD'`: Chi phí quản lý chung gián tiếp tại trang trại.
*   **Bốn Nguồn Phát sinh Chi phí (`farm_expenses.expense_source`):**
    *   `'INVENTORY_BACKFLUSH'`: Tự động hạch toán khi phát sinh phiếu xuất kho tiêu hao từ nhật ký sản xuất (`reference_id = warehouse_issues.id`).
    *   `'PAYROLL_ALLOCATION'`: Tự động trích xuất từ bảng lương nhân sự theo kỳ công.
    *   `'UTILITY_BILL'`: Hóa đơn tiền điện, tiền nước tưới, thuê dịch vụ nông nghiệp bên ngoài.
    *   `'MANUAL'`: Bút toán chi phí phát sinh thủ công có hóa đơn chứng từ kèm theo.
*   **Cờ Đủ điều kiện Tính Giá thành (`unit_cost_eligible`):** Chỉ các khoản chi phí có `unit_cost_eligible = TRUE` mới được thuật toán kế toán đưa vào tập hợp chi phí cấu thành giá vốn sản phẩm nông nghiệp.

### 7.2. Quy tắc Phân bổ Chi phí Chung Đa Đối tượng (`cost_allocations` #61)
Một khoản chi phí chung phát sinh tại trang trại (ví dụ: Hóa đơn tiền điện chạy trạm bơm nước 20.000.000 VNĐ) có thể được phân bổ cho nhiều đối tượng chịu phí thông qua bảng `cost_allocations`:
*   *Đối tượng phân bổ (`target_type`):* Có thể phân bổ cho một Mùa vụ cụ thể (`CROP_SEASON`), một Đàn nuôi (`LIVESTOCK_GROUP`), hoặc phân bổ cho toàn bộ một Phân khu sản xuất (`PRODUCTION_ZONE`).
*   *Đẳng thức bảo toàn phân bổ chi phí:*
    $$\sum_{i=1}^{m} \text{cost\_allocations.allocated\_amount}_i \le \text{farm\_expenses.amount}$$
    *(Hệ thống nghiêm cấm phân bổ vượt quá 100% giá trị của chứng từ chi phí gốc)*.

### 7.3. Thuật toán Tính Giá thành Thực tế Đơn vị Sản lượng (Unit Costing)
Khi kết thúc một vụ mùa canh tác (`crop_seasons.status = 'CLOSED'`) hoặc xuất chuồng một đàn vật nuôi (`livestock_groups.status = 'SOLD'`):
$$\text{Giá thành đơn vị (VNĐ/kg)} = \frac{\text{Tổng chi phí trực tiếp} + \sum \text{Chi phí phân bổ hợp lệ}}{\text{Tổng sản lượng thu hoạch thực tế (actual\_yield\_kg)}}$$
Giá thành này là căn cứ hạch toán giá vốn hàng bán (COGS) khi xuất bán cho khách hàng B2B.

### 7.4. Quy tắc Kiểm soát Ngân sách Dự toán (`budgets` & `budget_line_items`)
1.  Đầu mỗi năm tài chính hoặc chu kỳ vận hành (`operational_cycles`), Giám đốc phê duyệt Ngân sách dự toán cho từng Trang trại theo từng nhóm chi phí `cost_categories`.
2.  Mỗi khi có một khoản chi phí `farm_expenses` chuyển sang trạng thái `status = 'CONFIRMED'`, hệ thống tự động cộng dồn vào `budget_line_items.spent_amount`.
3.  **Cảnh báo & Chốt chặn Ngân sách:**
    *   Khi $\text{spent\_amount} \ge 0.85 \times \text{allocated\_amount}$: Bật cảnh báo Vàng trên Dashboard tài chính.
    *   Khi $\text{spent\_amount} > \text{allocated\_amount}$: Bật cảnh báo Đỏ vượt ngân sách. Nếu bật cờ kiểm soát cứng ngân sách, hệ thống từ chối phê duyệt các bút toán chi phí mới của nhóm danh mục đó.

### 7.5. Chu Trình Kết Toán Tài Chính Khép Kín Theo Chu Kỳ Vận Hành (`operational_cycles` #16)
Khi kết thúc một vụ mùa canh tác hoặc niên độ sản xuất, quy trình kết toán lợi nhuận được thực thi khép kín qua 3 chặng nghiêm ngặt:
1.  **Chặng 1 (Maker - Kế toán Trang trại `ROLE_ACCOUNTANT`):**
    *   Tổng hợp doanh thu thuần từ các đơn bán sỉ đã giao hàng (`sales_orders` hoàn tất), tổng chi phí trực tiếp phát sinh từ xuất kho tiêu hao (`INVENTORY_BACKFLUSH`), chi phí nhân công (`PAYROLL_ALLOCATION`), hóa đơn chi phí ngoài (`MANUAL`), và chi phí khấu hao/chung.
    *   Lập Bảng kết toán chu kỳ vận hành (Cycle Settlement Sheet) ở trạng thái `status = 'DRAFT'`.
2.  **Chặng 2 (Checker - Giám đốc Trang trại `ROLE_FARM_MANAGER`):**
    *   Thẩm định đối soát số liệu kế toán với thực tế sản xuất tại trại (sản lượng thực thu tại các phân khu, tồn kho nguyên vật liệu cuối kỳ, tài sản trang thiết bị).
    *   Ký xác nhận bảng kết toán chu kỳ, chuyển trạng thái sang `status = 'REVIEWED'` và trình lên Chủ đầu tư chuỗi.
3.  **Chặng 3 (Owner Approval - Chủ đầu tư Chuỗi Trang trại `ROLE_FARM_OWNER`):**
    *   Giám sát và kiểm toán toàn chuỗi, giữ độc quyền bấm nút **`[ Xác Nhận Kết Toán Chu Kỳ ]`** (`status = 'SETTLED'`).
    *   Khi phê duyệt: Hệ thống tự động chuyển chu kỳ sang `operational_cycles.status = 'CLOSED'`, kết chuyển lợi nhuận thuần về báo cáo tài chính cấp Doanh nghiệp, và khóa toàn bộ các chứng từ thuộc chu kỳ này chống mọi hành vi sửa đổi dữ liệu hồi tố.

---

## 8. QUY TẮC BÁN SỈ B2B, GIỮ CHỖ LÔ, GIAO HÀNG NHIỀU ĐỢT & CÔNG NỢ VIETQR HAI CHIỀU

Áp dụng cho: `partners` (#4), `sales_orders` (#62), `sales_order_items` (#63), `sales_deliveries` (#64), `sales_delivery_items` (#65), `debt_records` (#66), `payment_transactions` (#67), `payment_allocations` (#68).

### 8.1. Kiểm soát Tín dụng Đối tác & Cơ chế Giữ chỗ Tồn kho (Stock Reservation)
1.  **Kiểm tra Hạn mức Tín dụng B2B (`credit_limit`):** Khách hàng thu mua (`partner_type IN ('BUYER', 'AGENT')`) được cấp hạn mức tín dụng và thời hạn thanh toán `payment_term_days`. Khi nhân viên kinh doanh tạo đơn bán sỉ (`sales_orders`), hệ thống kiểm tra:
    $$\text{Dư nợ hiện tại của khách} + \text{Giá trị đơn hàng mới} \le \text{partners.credit\_limit}$$
    Nếu vượt hạn mức, đơn hàng bị chặn ở trạng thái `PENDING` và yêu cầu Giám đốc phê duyệt ngoại lệ.
2.  **Cơ chế Giữ chỗ Tồn kho Bất biến (Atomic Reservation):**
    *   Ngay khi Đơn bán sỉ chuyển sang trạng thái `CONFIRMED`, hệ thống tự động tăng số lượng đặt trước trong kho thành phẩm:
        $$\text{product\_batches.reserved\_quantity} = \text{reserved\_quantity} + \text{order\_quantity}$$
    *   Đảm bảo: $\text{Tồn khả dụng (Available)} = \text{remaining\_quantity} - \text{reserved\_quantity} \ge 0.00$. Ngăn chặn tuyệt đối tình trạng 2 nhân viên cùng bán vượt quá số lượng hàng có trong kho.
    *   Nếu đơn hàng bị hủy (`status = 'CANCELLED'`), số lượng `reserved_quantity` được giải phóng hoàn lại tồn khả dụng.

### 8.2. Quy trình Giao Hàng Nhiều Đợt (Split Delivery) & Trừ Kho Thực Tế
Một đơn hàng lớn có thể chia làm nhiều chuyến xe giao hàng theo từng đợt thông qua bảng `sales_deliveries` và `sales_delivery_items`:
1.  **Thông tin Vận chuyển Bắt buộc:** Mỗi phiếu giao hàng chỉ định đối tác vận tải `logistics_partner_id`, tên tài xế `driver_name`, biển số xe `vehicle_plate`, và ảnh chụp biên bản giao nhận có chữ ký bên mua `proof_of_delivery_url`.
2.  **Trừ Kho & Giải phóng Giữ chỗ:** Khi phiếu giao hàng chuyển sang `status = 'DISPATCHED'`:
    *   Trừ trực tiếp số lượng tồn thực tế: $\text{product\_batches.remaining\_quantity} -= \text{delivery\_qty}$.
    *   Giải phóng số lượng giữ chỗ tương ứng: $\text{product\_batches.reserved\_quantity} -= \text{delivery\_qty}$.
    *   Ghi nhận Sổ cái xuất kho thành phẩm `product_batch_transactions` với `transaction_type = 'SALE_DISPATCH'`, `direction = 'OUT'`.
    *   Cộng dồn số lượng đã giao thực tế vào chi tiết đơn hàng: $\text{sales\_order_items.shipped\_quantity} += \text{delivery\_qty}$.

### 8.3. Sổ Nợ Hai Chiều, Sinh VietQR Tự Động & Cấn Trừ Nợ Đối Tác (`DEBT_OFFSET`)
1.  **Tự động Phát sinh Công nợ Gốc:**
    *   Khi giao hàng hoàn tất: Tự động ghi vào `debt_records` với `debt_type = 'RECEIVABLE'`, `sales_order_id = sales_orders.id`, ngày đáo hạn $\text{due\_date} = \text{delivery\_date} + \text{partners.payment\_term\_days}$.
    *   Khi nhập mua vật tư: Tự động ghi vào `debt_records` với `debt_type = 'PAYABLE'`, `warehouse_receipt_id = warehouse_receipts.id`.
2.  **Thanh toán Tự động qua Mã VietQR Động Chuẩn Napas247:**
    *   Hệ thống trích xuất thông tin ngân hàng thụ hưởng từ bảng `enterprises` (#3): `bank_bin`, `bank_account_no`, `bank_account_name`.
    *   Tự động sinh chuỗi mã VietQR thanh toán gắn liền với mã đơn hàng: Nội dung chuyển khoản chuẩn `SO [order_code]`, số tiền chuyển chính xác bằng dư nợ còn lại `sales_orders.debt_amount`.
3.  **Cơ chế Phân bổ Dòng tiền (`payment_allocations` #68):** Khi nhận tiền chuyển khoản, Kế toán tạo giao dịch `payment_transactions` (#67), hệ thống cho phép phân bổ linh hoạt số tiền này để trừ dần cho một hoặc nhiều hồ sơ nợ `debt_records`.
4.  **Cơ chế Cấn Trừ Công Nợ Hai Chiều (`payment_method = 'DEBT_OFFSET'`):**
    *   Đối với các đối tác vừa cung cấp vật tư vừa bao tiêu nông sản (loại `AGENT`), Kế toán chọn chức năng `[ Cấn Trừ Công Nợ ]`.
    *   Hệ thống cho phép chọn 1 khoản nợ phải thu (`RECEIVABLE`) và 1 khoản nợ phải trả (`PAYABLE`) để triệt tiêu số dư chéo nhau mà không cần phát sinh giao dịch chuyển tiền mặt thực tế qua ngân hàng.

---

## 9. QUY TẮC QUẢN TRỊ GÓI THUÊ BAO NỀN TẢNG, THÔNG BÁO TỰ ĐỘNG & KIỂM TOÁN HỆ THỐNG

Áp dụng cho: `tenants` (#1), `tenant_subscriptions` (#2), `audit_logs` (#10), `notifications` (#71), `refresh_tokens` (#72).

### 9.1. Ràng buộc Giới hạn Gói Thuê Nền tảng (Platform Subscription Quotas)
Mỗi Tenant hoạt động trên nền tảng Farm SaaS gắn liền với một gói thuê bao `tenant_subscriptions` có thời hạn `valid_from` đến `valid_to`:
1.  **Chốt chặn Giới hạn Trang trại (`max_farms`):** Khi người dùng thực hiện tạo thêm một Trang trại mới (`farms` #11), Backend kiểm tra:
    $$\text{COUNT(farms thuộc tenant)} < \text{tenant\_subscriptions.max\_farms}$$
    Nếu đã đạt giới hạn, hệ thống chặn lại và ném lỗi `SUBSCRIPTION_LIMIT_EXCEEDED_FARMS` (HTTP 403), hướng dẫn người dùng nâng cấp gói thuê bao.
2.  **Chốt chặn Giới hạn Tài khoản Người dùng (`max_users`):** Khi phân quyền hoặc tạo thêm người dùng (`users` #5), Backend kiểm tra:
    $$\text{COUNT(users thuộc tenant)} < \text{tenant\_subscriptions.max\_users}$$
    Chặn tạo mới nếu vượt quá số lượng tài khoản được phép sử dụng.

### 9.2. Quy tắc Kích hoạt Thông báo Tự động (Event-Driven Notifications)
Bảng `notifications` (#71) lưu trữ thông báo thời gian thực gửi đến từng người dùng theo các sự kiện trọng yếu:
*   *Cảnh báo tồn kho chạm đáy:* Khi số lượng tồn kho khả dụng $\le$ `materials.min_stock_level`: Gửi thông báo loại `WARNING` cho Thủ kho và Chủ trại.
*   *Cảnh báo hàng cận date:* Khi ngày hết hạn của lô vật tư $\le \text{today} + \text{materials.expiry\_alert\_days}$: Gửi thông báo loại `ALERT` yêu cầu ưu tiên xuất dùng (FEFO).
*   *Cảnh báo công nợ quá hạn:* Khi ngày hiện tại vượt quá `debt_records.due_date` mà nợ chưa tất toán: Gửi thông báo loại `WARNING` cho Kế toán và Chủ trại.
*   *Thông báo giao việc mới:* Khi nhân viên được phân công vào `farm_tasks`: Gửi thông báo loại `TASK` đến tài khoản của nhân viên đó.
*   *Thông báo kết quả kiểm định KCS:* Khi biên bản QC được duyệt `PASSED` hoặc `REJECTED`: Gửi thông báo loại `QC` cho Quản lý kho và Kỹ thuật viên trưởng.

### 9.3. Quy tắc Kiểm toán Toàn vẹn & Thu hồi Phiên Bảo Mật
1.  **Kiểm toán Bất biến (`audit_logs` #10):** 100% các hành vi nhạy cảm (Cấp quyền, Đổi mật khẩu, Duyệt KCS, Thu hồi lô hàng, Phê duyệt hủy chứng từ kho, Phân bổ dòng tiền) bắt buộc ghi log bất đồng bộ kèm bản chụp JSON dữ liệu cũ `old_value` và dữ liệu mới `new_value`.
2.  **Quản lý Vòng đời Phiên (`refresh_tokens` #72):** Khi người dùng Đổi mật khẩu hoặc Đăng xuất, toàn bộ Refresh Token của tài khoản đó phải được đánh dấu `revoked = TRUE`. Nếu phát hiện hành vi Token Replay, hệ thống lập tức cưỡng chế hủy toàn bộ phiên đang hoạt động của người dùng trên mọi thiết bị.

---
*Văn kiện `SPEC-CORE-001` (Phiên bản Hoàn thiện Đầy đủ 9 Mục) phủ kín 100% 72 bảng cơ sở dữ liệu và là kim chỉ nam tối cao cho toàn bộ nghiệp vụ nền tảng Farm SaaS.*
