# TỪ ĐIỂN DỮ LIỆU NGHIỆP VỤ, SƠ ĐỒ ERD & ĐẶC TẢ SCHEMA 15 CỘT JSON
## (MASTER DATA DICTIONARY, ERD RELATIONSHIPS & 15-JSON SCHEMA SPECIFICATION)

> **Mã văn kiện:** `SPEC-DATA-015`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Là Từ Điển Bách Khoa Toàn Thư Của 72 Bảng Dữ Liệu Lõi.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Tôn chỉ:** *"Không duy trì 2 bản DDL song song - Khóa cứng cấu trúc 15 cột JSON - Xác định rõ ràng chủ quyền Đọc/Ghi (Read/Write Ownership)"*.

---

## 1. SƠ ĐỒ QUAN HỆ THỰC THỂ (MERMAID ERD) THEO 10 PHÂN HỆ

Sơ đồ dưới đây phản ánh kiến trúc **The Farm Barrier Guard** với các **Khóa ngoại tổ hợp (Composite Foreign Keys)** xuyên suốt 72 bảng, ngăn chặn triệt để hiện tượng lẫn lộn dữ liệu giữa các trang trại ở cấp độ Database Engine:

```mermaid
erDiagram
    %% 1. PLATFORM & ENTERPRISES
    tenants ||--o{ tenant_subscriptions : "has"
    tenants ||--|| enterprises : "defines_legal_profile"
    tenants ||--o{ partners : "owns"
    farms ||--o{ partners : "belongs_to_farm"

    %% 2. AUTH & SECURITY
    tenants ||--o{ users : "owns"
    users ||--o{ user_roles : "assigned"
    roles ||--o{ user_roles : "defines"
    roles ||--o{ role_permissions : "grants"
    permissions ||--o{ role_permissions : "includes"
    users ||--o{ refresh_tokens : "issued"
    tenants ||--o{ audit_logs : "records"

    %% 3. GEOGRAPHY & INFRASTRUCTURE
    tenants ||--o{ farms : "contains"
    farms ||--o{ user_farm_access : "authorizes"
    farms ||--o{ production_zones : "divides_into"
    production_zones ||--o{ zone_locations : "subdivides"
    farms ||--o{ farm_assignments : "assigns_staff"
    farms ||--o{ operational_cycles : "schedules"
    farms ||--o{ farm_operational_settings : "configures"

    %% 4. MASTER DATA
    tenants ||--o{ crop_types : "catalogs"
    tenants ||--o{ livestock_breeds : "catalogs"
    farms ||--o{ warehouses : "operates"
    tenants ||--o{ material_categories : "classifies"
    material_categories ||--o{ materials : "groups"
    materials ||--o{ material_unit_conversions : "converts_units"
    tenants ||--o{ consumption_quotas : "standardizes"
    tenants ||--o{ work_shifts : "defines_shifts"
    tenants ||--o{ cost_categories : "categorizes_costs"

    %% 5. WAREHOUSE & INVENTORY
    warehouses ||--o{ warehouse_inventory : "stores_stock"
    materials ||--o{ warehouse_inventory : "stock_item"
    warehouses ||--o{ warehouse_receipts : "receives_into"
    warehouse_receipts ||--o{ warehouse_receipt_items : "contains"
    warehouses ||--o{ warehouse_issues : "issues_from"
    warehouse_issues ||--o{ warehouse_issue_items : "contains"
    warehouses ||--o{ warehouse_transfers : "transfers_out_in"
    warehouse_transfers ||--o{ warehouse_transfer_items : "contains"
    warehouses ||--o{ stocktakes : "audits_stock"
    stocktakes ||--o{ stocktake_items : "records_diff"
    warehouse_inventory ||--o{ warehouse_inventory_transactions : "tracks_ledger"

    %% 6. CROPS & LIVESTOCK OPERATIONS
    crop_types ||--o{ crop_seasons : "planted_in"
    production_zones ||--o{ crop_seasons : "located_at"
    crop_seasons ||--o{ farming_logs : "logs_activities"
    farming_logs ||--o{ farming_log_supplies : "auto_backflushes"
    livestock_breeds ||--o{ livestock_groups : "bred_as"
    production_zones ||--o{ livestock_groups : "housed_in"
    livestock_groups ||--o{ livestock_individuals : "identifies_rfid_tags"
    livestock_groups ||--o{ livestock_weight_logs : "tracks_adg"
    livestock_groups ||--o{ livestock_events : "logs_treatments"
    livestock_events ||--o{ livestock_event_supplies : "auto_backflushes"

    %% 7. HARVEST, QA & TRACEABILITY
    crop_seasons ||--o{ harvest_records : "harvests_crops"
    livestock_groups ||--o{ harvest_records : "harvests_meat"
    warehouses ||--o{ product_batches : "stores_batches"
    harvest_records ||--o{ product_batch_sources : "batches_from"
    product_batches ||--o{ product_batch_sources : "packaged_into"
    product_batches ||--o{ qc_inspections : "inspects_qa"
    qc_inspections ||--o{ qc_inspection_items : "tests_metrics"
    product_batches ||--o{ product_batch_transactions : "tracks_batch_flow"
    product_batches ||--|| traceability_snapshots : "freezes_qr_data"
    product_batches ||--o{ label_print_logs : "prints_labels"

    %% 8. WORKFORCE & HR
    tenants ||--o{ employees : "employs"
    employees ||--o{ shift_assignments : "assigned_shifts"
    employees ||--o{ time_attendances : "checks_in_gps"
    employees ||--o{ leave_requests : "requests_leave"
    employees ||--o{ overtime_requests : "requests_ot"
    farms ||--o{ farm_tasks : "schedules_tasks"
    farm_tasks ||--o{ farm_task_assignees : "assigns_team"
    employees ||--o{ farm_task_assignees : "receives_task"

    %% 9. FINANCE, COSTING & SALES
    farms ||--o{ farm_expenses : "incurs_expenses"
    cost_categories ||--o{ farm_expenses : "groups_expenses"
    farm_expenses ||--o{ cost_allocations : "allocates_to_targets"
    partners ||--o{ sales_orders : "places_orders"
    sales_orders ||--o{ sales_order_items : "orders_items"
    product_batches ||--o{ sales_order_items : "reserves_stock"
    sales_orders ||--o{ sales_deliveries : "dispatches_shipments"
    sales_deliveries ||--o{ sales_delivery_items : "delivers_items"
    partners ||--o{ debt_records : "owes_receivable_payable"
    sales_orders ||--o{ debt_records : "generates_receivable"
    partners ||--o{ payment_transactions : "makes_payments"
    payment_transactions ||--o{ payment_allocations : "settles_debts"
    debt_records ||--o{ payment_allocations : "settled_by"
    operational_cycles ||--o{ budgets : "forecasts_budget"
    budgets ||--o{ budget_line_items : "breaks_down_budget"

    %% 10. NOTIFICATIONS
    users ||--o{ notifications : "receives_alert"
```

---

## 2. NGUYÊN TẮC PHÂN ĐỊNH 3 THÀNH PHẦN DỮ LIỆU & QUY TẮC ĐỌC/GHI 72 BẢNG

Để bảo vệ tính toàn vẹn tuyệt đối và triệt tiêu mọi mâu thuẫn giữa DDL SQL, Mã nguồn Backend và Giao diện Frontend, toàn bộ dữ liệu trong hệ thống được phân định minh bạch thành 3 thành phần độc lập:
1. **Cột Vật Lý Thực Tế trong SQL (`Physical DB Columns`):** Là 100% các cột được định nghĩa trực tiếp trong file DDL [`V1_0__init_system_core.sql`](file:///d:/Projects/Farm_Management/backend/src/main/resources/db/migration/V1_0__init_system_core.sql), được quản lý bởi các JPA Entity với annotation `@Column`. Mọi câu truy vấn SQL/JPQL bắt buộc chỉ được sử dụng các cột này.
2. **Quy Tắc Nghiệp Vụ & Ràng Buộc Dữ Liệu (`Business Rules & Database Constraints`):** Bao gồm các mệnh đề `CHECK CONSTRAINT`, `FOREIGN KEY`, `UNIQUE KEY` trong SQL kết hợp cùng các tầng kiểm thực logic nghiệp vụ tại Application Service (ví dụ: Maker-Checker KCS, kiểm tra cách ly PHI/Withdrawal, bán kính Geofence chấm công).
3. **Thuộc Tính Suy Luận / Tính Toán Do Backend Tạo Ra (`Backend-Calculated / Computed Attributes`):** Là các trường thông tin **KHÔNG CÓ CỘT VẬT LÝ RIÊNG TRONG BẢNG SQL**, mà được tầng Service Backend tự động tính toán, tổng hợp (Aggregation) hoặc suy luận tại thời điểm xử lý nghiệp vụ để trả ra trong Response DTO. Ví dụ:
   - `user_farm_access`: SQL lưu trữ quan hệ phân quyền nhiều-nhiều qua `(user_id, farm_id)`. Thuộc tính `is_primary` hoàn toàn là trạng thái phiên làm việc (Session/UI State) do Frontend lưu trữ trong LocalStorage để ghi nhớ trang trại mặc định người dùng đang thao tác.
   - `crop_seasons`: Các chỉ số `days_elapsed`, `days_remaining` được Backend tính toán động từ `start_date` và `expected_harvest_date`.
   - `partners`: Số nợ hiện tại `current_debt` là giá trị tổng hợp động (Dynamic Aggregate) từ bảng `debt_records`.
   - `livestock_weight_logs`: Tăng trọng bình quân ngày (`ADG - Average Daily Gain`) là chỉ số toán học suy luận từ 2 mốc cân liên tiếp.

Bảng dưới đây quy định thẩm quyền thao tác dữ liệu, phân loại tính chất bảng (Biến động, Bất biến, Sổ cái) và nêu bật các cột kỹ thuật vật lý cùng ràng buộc chuẩn xác 100% theo DDL SQL:

| # | Tên Bảng (`table_name`) | Phân Hệ | Giải Nghĩa Kinh Doanh & Mục Đích Lưu Trữ | Cột Đặc Biệt / Ràng Buộc Nổi Bật (Chuẩn SQL DDL) | Service Được Ghi (`Write Owner`) | Tính Chất Dữ Liệu |
| :---: | :--- | :--- | :--- | :--- | :--- | :---: |
| **1** | `tenants` | Platform | Khách thuê tổ chức (Công ty/HTX) dùng chung nền tảng SaaS | `status IN ('ACTIVE', 'SUSPENDED', 'INACTIVE')`, `subscription_plan IN ('FREE', 'STARTER', 'PROFESSIONAL', 'ENTERPRISE')` | `TenantManagementService` | MUTABLE |
| **2** | `tenant_subscriptions`| Platform | Gói dịch vụ bản quyền SaaS của khách thuê | Khóa hạn mức: `max_farms > 0`, `max_users > 0` | `SubscriptionService` | MUTABLE |
| **3** | `enterprises` | Platform | Hồ sơ pháp nhân, ngân hàng VietQR & chứng nhận | `certifications_json JSON`, `bank_bin`, `bank_account_no` | `EnterpriseProfileService` | MUTABLE |
| **4** | `partners` | Commercial | Danh bạ Nhà cung cấp, Khách hàng, Logistics, Đại lý thuộc trang trại | Khóa ngoại Farm: `farm_id` (`fk_partners_farm` theo `V1_1`), `credit_limit >= 0`, `payment_term_days >= 0`, `status IN ('ACTIVE', 'INACTIVE', 'BLACKLISTED')` | `PartnerService` | MUTABLE |
| **5** | `users` | Auth | Tài khoản đăng nhập hệ thống của nhân viên/quản lý | `password_hash`, `must_change_password` | `UserService`, `AuthService` | MUTABLE |
| **6** | `roles` | Auth | Danh mục 7 vai trò chuẩn 4 cấp hệ thống (Seed data Flyway `V1_4`) | Cấp 1 (`SYSTEM`): `ROLE_SUPER_ADMIN`; Cấp 2 (`TENANT`): `ROLE_FARM_OWNER`; Cấp 3 (`FARM`): `ROLE_FARM_MANAGER`; Cấp 4 (`FARM`): `ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_ACCOUNTANT`, `ROLE_FIELD_STAFF` | Chỉ đọc (Flyway Migration Seed) | READ-ONLY |
| **7** | `permissions` | Auth | Danh mục 30 quyền hạn nghiệp vụ chuẩn (Seed data) | `code`: `PERM_TENANT_MANAGE` ... `PERM_FINANCE_*`| Chỉ đọc (Flyway Migration Seed) | READ-ONLY |
| **8** | `user_roles` | Auth | Bảng gán quyền theo phạm vi SYSTEM / TENANT / FARM | Cột ảo: `assigned_scope_farm_id` VIRTUAL | `UserRoleAssignmentService` | MUTABLE |
| **9** | `role_permissions` | Auth | Bảng ánh xạ quyền hạn mặc định cho từng Role | Composite PK `(role_id, permission_id)` | Chỉ đọc (Flyway Migration Seed) | READ-ONLY |
| **10**| `audit_logs` | Audit | Sổ cái kiểm toán bất biến vết thay đổi dữ liệu | `old_value JSON`, `new_value JSON`, `ip_address`| `AuditLogAsyncListener` | **APPEND-ONLY** |
| **11**| `farms` | Geography | Thực thể trang trại, tâm tọa độ GPS & Geofence | `geofence_radius_m > 0` (`chk_farms_geofence`) | `FarmManagementService` | MUTABLE |
| **12**| `user_farm_access` | Geography | Danh sách trang trại được cấp phép truy cập | Composite PK `(user_id, farm_id)`, `granted_at`, `granted_by` | `UserFarmAccessService` | MUTABLE |
| **13**| `production_zones` | Geography | Phân khu sản xuất (Vườn mở, Nhà màng, Chuồng, Ao) | `map_layout_json JSON`, `area_m2 > 0` | `ZoneManagementService` | MUTABLE |
| **14**| `zone_locations` | Geography | Vị trí lô đất, luống gieo, ô chuồng nuôi cụ thể | `code`, `name`, `status IN ('ACTIVE', 'OCCUPIED', 'EMPTY', 'MAINTENANCE')` | `ZoneLocationService` | MUTABLE |
| **15**| `farm_assignments` | Geography | Lịch sử phân công nhân sự phụ trách Farm/Zone | `assigned_from`, `assigned_to` (`assigned_to >= assigned_from`), `role_in_farm IN ('MANAGER', 'SUPERVISOR', 'WORKER', 'TECHNICIAN', 'ACCOUNTANT')` | `FarmAssignmentService` | MUTABLE |
| **16**| `operational_cycles` | Geography | Chu kỳ sản xuất / Năm tài chính vận hành | `name`, `fiscal_year`, `start_date <= end_date`, `status IN ('PLANNING', 'ACTIVE', 'CLOSED')` | `OperationalCycleService` | MUTABLE |
| **17**| `farm_operational_settings`| Geography | Tham số cấu hình cảm biến, ngưỡng tưới & chấm công | `irrigation_threshold_json`, `work_shift_config_json`| `FarmSettingsService` | MUTABLE |
| **18**| `crop_types` | MasterData | Danh mục chủng loại giống cây trồng canh tác | `growth_days_standard > 0` | `CropMasterService` | MUTABLE |
| **19**| `crop_seasons` | Crop | Mùa vụ gieo trồng trên một hoặc nhiều lô đất | `status IN ('SOIL_PREPARATION', 'SOWING', 'GROWING', 'HARVESTING', 'CLOSED', 'CANCELLED')` | `CropSeasonService` | MUTABLE |
| **20**| `farming_logs` | Crop | Nhật ký hoạt động canh tác (Bón phân, phun thuốc...) | `supplies_used_json`, `image_urls_json`, `phi_days` | `FarmingLogService` | MUTABLE |
| **21**| `livestock_breeds` | MasterData | Danh mục giống vật nuôi theo loài (Heo, Bò, Gà...) | `species IN ('CATTLE', 'SWINE', 'POULTRY', 'GOAT', 'SHEEP', 'AQUA')` | `LivestockMasterService` | MUTABLE |
| **22**| `livestock_groups` | Livestock | Đàn / Lứa vật nuôi xuất nhập theo chuồng trại | `initial_quantity > 0`, `current_quantity >= 0` | `LivestockGroupService` | MUTABLE |
| **23**| `livestock_individuals` | Livestock | Quản lý cá thể vật nuôi gắn mã định danh RFID | `rfid_tag_code UNIQUE (tenant_id, rfid_tag_code)`, `gender IN ('MALE', 'FEMALE', 'CASTRATED')` | `LivestockIndividualService`| MUTABLE |
| **24**| `livestock_weight_logs`| Livestock | Nhật ký cân nặng định kỳ để tính tăng trọng ADG | `target_type IN ('INDIVIDUAL', 'GROUP')`, `weight_kg > 0.00` | `LivestockWeightService` | **APPEND-ONLY** |
| **25**| `livestock_events` | Livestock | Nhật ký thú y, tiêm phòng, dịch bệnh và biến động | `event_type IN ('VACCINATION', 'WEIGHT_CHECK', 'BREEDING', 'BIRTH', 'MEDICAL_TREATMENT', 'TRANSFER', 'SLAUGHTER')` | `LivestockEventService` | MUTABLE |
| **26**| `warehouses` | MasterData | Kho lưu trữ vật tư nông nghiệp & bảo quản thành phẩm| `warehouse_type`: `FERTILIZER`, `COLD_STORAGE`... | `WarehouseService` | MUTABLE |
| **27**| `material_categories`| MasterData | Nhóm phân loại vật tư (Phân bón, Thuốc BVTV, Cám...) | `code UNIQUE (tenant_id, code)` | `MaterialCategoryService` | MUTABLE |
| **28**| `materials` | MasterData | Danh mục mặt hàng vật tư nông nghiệp & SKU | `min_stock_level >= 0`, `default_phi_days >= 0` | `MaterialService` | MUTABLE |
| **29**| `material_unit_conversions`| MasterData| Quy cách đóng gói bao bì & tỷ lệ chuyển đổi đơn vị | `conversion_factor > 0`, `unit_barcode UNIQUE` | `UnitConversionService` | MUTABLE |
| **30**| `consumption_quotas`| MasterData | Định mức tiêu hao kỹ thuật thức ăn / phân bón | `standard_quantity > 0` | `QuotaService` | MUTABLE |
| **31**| `warehouse_inventory` | Inventory | Số dư tồn kho tức thời theo Kho, Mặt hàng, Số lô | `quantity_on_hand >= 0`, `reserved_quantity >= 0` | `InventoryTransactionService`| MUTABLE (Lock) |
| **32**| `warehouse_receipts` | Inventory | Chứng từ phiếu nhập kho mua hàng / nhận điều chuyển | `receipt_type`, `total_amount >= 0` | `InventoryReceiptService` | MUTABLE |
| **33**| `warehouse_receipt_items`| Inventory| Chi tiết từng mặt hàng nhập kho kèm giá và hạn dùng | `quantity > 0`, `conversion_factor > 0` | `InventoryReceiptService` | MUTABLE |
| **34**| `warehouse_issues` | Inventory | Chứng từ phiếu xuất kho sản xuất / điều chuyển / hủy | Cột ảo: `active_farming_backflush`, `active_livestock_backflush` | `InventoryIssueService` | MUTABLE |
| **35**| `warehouse_issue_items` | Inventory| Chi tiết mặt hàng xuất kho và số lô tương ứng | `quantity > 0`, `unit_price >= 0` | `InventoryIssueService` | MUTABLE |
| **36**| `warehouse_transfers` | Inventory | Phiếu điều chuyển hàng nội bộ liên kho / liên trại | `status IN ('DRAFT', 'PENDING', 'IN_TRANSIT', 'COMPLETED', 'CANCELLED')` | `InventoryTransferService` | MUTABLE |
| **37**| `warehouse_transfer_items`| Inventory| Chi tiết số lượng hàng hóa gửi đi trong lệnh chuyển | `quantity > 0` | `InventoryTransferService` | MUTABLE |
| **38**| `warehouse_inventory_transactions`| Inventory| Sổ cái thẻ kho lịch sử biến động xuất nhập tồn | `direction IN ('IN', 'OUT')`, `quantity > 0`, `balance_before >= 0`, `balance_after >= 0` | `InventoryTransactionService`| **APPEND-ONLY** |
| **39**| `stocktakes` | Inventory | Phiếu kiểm kê kho định kỳ / đột xuất | `status IN ('DRAFT', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')` | `StocktakeService` | MUTABLE |
| **40**| `stocktake_items` | Inventory | Bảng chi tiết chênh lệch tồn sổ sách vs kiểm đếm | `difference_quantity = (actual_quantity - book_quantity)` | `StocktakeService` | MUTABLE |
| **41**| `farming_log_supplies` | Crop | Danh mục vật tư trừ kho thực tế từ nhật ký canh tác | `actual_quantity > 0`, liên kết `warehouse_issues` | `FarmingLogService` | MUTABLE |
| **42**| `livestock_event_supplies`| Livestock | Danh mục thuốc/vật tư trừ kho từ sự kiện thú y | `actual_quantity > 0`, liên kết `warehouse_issues` | `LivestockEventService` | MUTABLE |
| **43**| `harvest_records` | Quality | Biên bản thu hoạch thực tế nông sản / thịt xuất bán | `quantity > 0.00`, `quality_grade IN ('GRADE_A', 'GRADE_B', 'STANDARD', 'REJECT')` | `HarvestService` | MUTABLE |
| **44**| `product_batches` | Quality | Lô thành phẩm đóng gói chuẩn bị dán tem QR xuất bán | `traceability_code UUID`, `remaining_quantity`, `reserved_quantity` | `ProductBatchService` | MUTABLE (Lock) |
| **45**| `product_batch_sources` | Quality | Bảng ánh xạ nguồn gốc Lô gom từ các phiếu thu hoạch | `contributed_quantity > 0.00` | `ProductBatchService` | MUTABLE |
| **46**| `qc_inspections` | Quality | Biên bản kiểm định chất lượng KCS mẫu sản phẩm | `overall_result IN ('PENDING', 'PASSED', 'REJECTED', 'CONDITIONAL')`, Chống tự duyệt | `QcInspectionService` | MUTABLE |
| **47**| `qc_inspection_items` | Quality | Chi tiết các chỉ tiêu kiểm nghiệm (Vi sinh, Nitrate...)| `parameter_name`, `standard_threshold`, `measured_value`, `is_passed` | `QcInspectionService` | MUTABLE |
| **48**| `product_batch_transactions`| Quality| Sổ cái lịch sử biến động số lượng của Lô thành phẩm | `direction IN ('IN', 'OUT')`, `quantity > 0`, `balance_before >= 0`, `balance_after >= 0` | `BatchTransactionService` | **APPEND-ONLY** |
| **49**| `traceability_snapshots`| Quality | Bản chụp đóng băng toàn bộ dữ liệu QR truy xuất | 5 cột JSON: `enterprise_info`, `vietgap_cert`... | `TraceabilitySnapshotService`| **IMMUTABLE SNAPSHOT** |
| **50**| `label_print_logs` | Quality | Nhật ký ghi nhận các lần in tem nhãn nhiệt ESC/POS | `print_quantity > 0`, `label_size IN ('50x50', '35x22')` | `LabelPrintService` | **APPEND-ONLY** |
| **51**| `employees` | HR | Hồ sơ nhân sự 360°, hợp đồng và quỹ phép năm | `date_of_birth >= 18 tuổi`, `annual_leave_quota` | `EmployeeManagementService` | MUTABLE |
| **52**| `work_shifts` | HR | Danh mục ca làm việc (Giờ vào, ra, nghỉ trưa, trễ) | `start_time`, `end_time`, `grace_late_minutes` | `WorkShiftService` | MUTABLE |
| **53**| `shift_assignments` | HR | Bảng phân ca làm việc cho nhân viên theo ngày | `work_date`, Unique Key `uk_employee_shift_date (employee_id, work_date, shift_id)` | `ShiftAssignmentService` | MUTABLE |
| **54**| `time_attendances` | HR | Bảng chấm công 2 đầu GPS Geofence + Selfie | `is_adjusted`, `original_check_in`, `check_out` | `TimeAttendanceService` | MUTABLE |
| **55**| `leave_requests` | HR | Đơn xin nghỉ phép của người lao động | `status IN ('PENDING', 'APPROVED', 'REJECTED', 'CANCELLED')` | `LeaveManagementService` | MUTABLE |
| **56**| `overtime_requests` | HR | Đơn đăng ký làm thêm giờ và phê duyệt hệ số OT | `ot_multiplier IN (1.5, 2.0, 3.0)` | `OvertimeManagementService` | MUTABLE |
| **57**| `farm_tasks` | HR | Nhiệm vụ công việc hiện trường giao cho nhân sự | `deadline`, `priority`, `photos_json JSON`, `status IN ('TODO', 'IN_PROGRESS', 'PENDING_REVIEW', 'DONE', 'CANCELLED')` | `FarmTaskService` | MUTABLE |
| **58**| `farm_task_assignees` | HR | Bảng phân bổ nhóm nhân viên thực hiện nhiệm vụ | `role_in_task IN ('LEADER', 'MEMBER')` | `FarmTaskService` | MUTABLE |
| **59**| `cost_categories` | Finance | 5 nhóm chi phí kế toán (Nhân công, Vật tư, Khấu hao...)| `cost_type IN ('MATERIALS', 'DIRECT_LABOR', 'MACHINERY_FUEL', 'DEPRECIATION', 'INDIRECT_OVERHEAD')` | `CostAccountingService` | MUTABLE |
| **60**| `farm_expenses` | Finance | Tập hợp chi phí phát sinh từ 4 nguồn nghiệp vụ | `expense_source`, `unit_cost_eligible BOOLEAN` | `ExpenseTrackingService` | MUTABLE |
| **61**| `cost_allocations` | Finance | Bàn phân bổ chi phí chung vào Mùa vụ / Đàn / Khu | $\sum \text{allocated\_amount} \le \text{amount}$ | `CostAllocationService` | MUTABLE |
| **62**| `sales_orders` | Commercial | Đơn bán sỉ nông sản B2B có kiểm soát hạn mức nợ | `status IN ('PENDING', 'CONFIRMED', 'DELIVERED', 'COMPLETED', 'CANCELLED')`, `final_amount`, `paid_amount`, `debt_amount` | `SalesOrderService` | MUTABLE |
| **63**| `sales_order_items` | Commercial | Chi tiết lô thành phẩm và số lượng giữ chỗ trong đơn| `quantity > 0`, `unit_price > 0` | `SalesOrderService` | MUTABLE |
| **64**| `sales_deliveries` | Commercial | Phiếu giao hàng nhiều đợt xuất kho giao khách | `delivery_code UNIQUE`, `proof_of_delivery_url` | `SalesDeliveryService` | MUTABLE |
| **65**| `sales_delivery_items`| Commercial | Chi tiết số lượng thực tế giao từ các lô thành phẩm | Trừ `remaining_quantity`, giảm `reserved_quantity` | `SalesDeliveryService` | MUTABLE |
| **66**| `debt_records` | Finance | Sổ phụ theo dõi công nợ 2 chiều (Phải thu & Phải trả)| `debt_type IN ('RECEIVABLE', 'PAYABLE')` | `DebtManagementService` | MUTABLE (Lock) |
| **67**| `payment_transactions` | Finance | Phiếu thu / chi thanh toán (Tiền mặt, VietQR, Cấn trừ)| `payment_method IN ('CASH','BANK_TRANSFER'...)` | `PaymentTransactionService` | MUTABLE |
| **68**| `payment_allocations` | Finance | Sổ cái phân bổ số tiền thanh toán để cấn trừ nợ | $\sum \text{allocated\_amount} \le \text{amount}$ | `PaymentAllocationService` | **APPEND-ONLY** |
| **69**| `budgets` | Finance | Dự toán ngân sách chu kỳ sản xuất / năm tài chính | `total_budget_amount > 0` | `BudgetManagementService` | MUTABLE |
| **70**| `budget_line_items` | Finance | Chi tiết hạn mức dự toán theo từng nhóm chi phí | `spent_amount <= allocated_amount` (Cảnh báo 90%)| `BudgetManagementService` | MUTABLE |
| **71**| `notifications` | System | Thông báo đẩy trong ứng dụng cho người dùng | `is_read`, `action_url`, `type IN ('INFO', 'WARNING', 'ALERT', 'TASK', 'QC', 'SYSTEM')` | `NotificationService` | MUTABLE |
| **72**| `refresh_tokens` | Auth | Bảng quản lý và thu hồi phiên đăng nhập Refresh Token | `token VARCHAR(255) UNIQUE`, `revoked BOOLEAN` | `TokenProviderService` | MUTABLE |

---

## 3. ĐẶC TẢ CẤU TRÚC JSON CHUẨN (JSON SCHEMA) CHO TOÀN BỘ 15 CỘT KIỂU `JSON`

Do MySQL không tự động xác thực tên trường bên trong kiểu dữ liệu `JSON`, toàn bộ 15 cột dưới đây **BẮT BUỘC PHẢI TUÂN THỦ CHÍNH XÁC 100% CẤU TRÚC KEYS VÀ DATA TYPE** đã quy định:

```mermaid
graph TD
    subgraph "15 CỘT KIỂU JSON TRONG HỆ THỐNG"
        J1["enterprises.certifications_json (#3)"]
        J2a["audit_logs.old_value (#10)"]
        J2b["audit_logs.new_value (#10)"]
        J3["production_zones.map_layout_json (#13)"]
        J4["farm_operational_settings (#17):<br/>irrigation_threshold_json & work_shift_config_json"]
        J5["farming_logs (#20):<br/>supplies_used_json & image_urls_json"]
        J6["livestock_events.details_json (#25)"]
        J7["traceability_snapshots (#49):<br/>enterprise_info, vietgap_cert, farming_timeline,<br/>harvest_info, qc_inspection_json"]
        J8["farm_tasks.photos_json (#57)"]
    end
```

### 3.1. Cột `enterprises.certifications_json` (#3)
*   **Mô tả:** Mảng chứa danh sách các chứng chỉ tiêu chuẩn chất lượng (VietGAP, GlobalGAP, OCOP, Organic) của pháp nhân.
```json
[
  {
    "certCode": "VIETGAP-TT-2026",
    "certName": "Chứng nhận Thực hành Nông nghiệp Tốt VietGAP Trồng trọt",
    "standardType": "TCVN 11892-1:2017",
    "certNumber": "VIETGAP-088-2026-ĐTP",
    "issuedBy": "Trung tâm Chứng nhận Phù hợp Quacert",
    "issuedDate": "2026-01-01",
    "expiryDate": "2029-01-01",
    "documentUrl": "https://cdn.greenfarm.vn/certs/vietgap-cert.pdf"
  }
]
```

### 3.2a. Cột `audit_logs.old_value` (#10)
*   **Mô tả:** Bản chụp định dạng Key-Value lưu trữ các trường dữ liệu trước khi bị thay đổi trong câu lệnh `UPDATE` hoặc `DELETE`.
```json
{
  "status": "DRAFT",
  "totalAmount": 12500000.00,
  "approvedByUserId": null,
  "approvedAt": null
}
```

### 3.2b. Cột `audit_logs.new_value` (#10)
*   **Mô tả:** Bản chụp định dạng Key-Value lưu trữ các trường dữ liệu mới sau khi thực hiện câu lệnh `INSERT` hoặc `UPDATE`.
```json
{
  "status": "APPROVED",
  "totalAmount": 12500000.00,
  "approvedByUserId": 15,
  "approvedAt": "2026-10-18T10:30:00Z"
}
```

### 3.3. Cột `production_zones.map_layout_json` (#13)
*   **Mô tả:** Tọa độ địa lý chuẩn **GeoJSON Polygon** để hiển thị đa giác ranh giới phân khu trên bản đồ Leaflet/Mapbox.
```json
{
  "type": "Polygon",
  "coordinates": [
    [
      [105.7823, 10.2456],
      [105.7850, 10.2456],
      [105.7850, 10.2420],
      [105.7823, 10.2420],
      [105.7823, 10.2456]
    ]
  ],
  "properties": {
    "fillColor": "#10B981",
    "fillOpacity": 0.35,
    "strokeColor": "#059669",
    "strokeWeight": 2
  }
}
```

### 3.4. Cột `farm_operational_settings.irrigation_threshold_json` (#17)
*   **Mô tả:** Cấu hình ngưỡng cảnh báo cảm biến độ ẩm đất và điều khiển van tưới tự động.
```json
{
  "minSoilMoisturePercent": 45.0,
  "maxSoilMoisturePercent": 80.0,
  "targetTemperatureCelsius": 28.5,
  "maxAirTemperatureCelsius": 38.0,
  "autoIrrigationEnabled": true,
  "irrigationDurationMinutes": 25
}
```

### 3.5. Cột `farm_operational_settings.work_shift_config_json` (#17)
*   **Mô tả:** Quy tắc cấu hình ca làm việc và các tham số dung sai chấm công GPS.
```json
{
  "maxCheckInEarlyMinutes": 60,
  "graceLateMinutes": 15,
  "minWorkingHoursFullDay": 8.0,
  "minWorkingHoursHalfDay": 4.0,
  "enableGpsDistanceCheck": true,
  "maxAllowedGpsAccuracyMeters": 30.0
}
```

### 3.6. Cột `farming_logs.supplies_used_json` (#20)
*   **Mô tả:** Bản chụp thô danh mục vật tư đã tiêu hao trong buổi canh tác tại thời điểm ghi nhận (chống sai lệch khi bảng danh mục vật tư gốc có sự thay đổi sau đó).
```json
[
  {
    "materialId": 28,
    "skuCode": "SKU-NPK-01",
    "materialName": "Phân bón NPK Đầu Trâu 20-20-15",
    "warehouseId": 26,
    "warehouseName": "Kho Vật Tư Trại 01",
    "batchNumber": "LOT-NPK-202610",
    "quantity": 50.0,
    "unit": "KG",
    "unitPrice": 25000.0,
    "totalPrice": 1250000.0
  }
]
```

### 3.7. Cột `farming_logs.image_urls_json` (#20)
*   **Mô tả:** Mảng danh sách đường dẫn hình ảnh chụp hiện trường đã được nén WebP và đóng dấu thời gian.
```json
[
  "https://cdn.greenfarm.vn/farming/2026/10/log-101-photo1.webp",
  "https://cdn.greenfarm.vn/farming/2026/10/log-101-photo2.webp"
]
```

### 3.8. Cột `livestock_events.details_json` (#25)
*   **Mô tả:** Bệnh án lâm sàng và thông số chi tiết khi phát sinh sự kiện thú y / tiêm vaccine / điều trị bệnh.
```json
{
  "symptoms": "Bỏ ăn, sốt cao 40.5 độ C, thở dốc",
  "diagnosis": "Viêm phổi dính sườn (APP)",
  "temperatureCelsius": 40.5,
  "treatmentMethod": "Tiêm bắp kháng sinh Amoxicillin",
  "dosagePerHead": "1ml / 10kg thể trọng",
  "prescribingVeterinarian": "Bác sĩ thú y Nguyễn Văn A",
  "isolationDaysRequired": 7
}
```

### 3.9. Cột `traceability_snapshots.enterprise_info_json` (#49)
*   **Mô tả:** Đóng băng thông tin pháp nhân và định danh ngân hàng VietQR tại thời điểm phê duyệt xuất xưởng lô hàng.
```json
{
  "enterpriseName": "Hợp Tác Xã Nông Nghiệp Xanh Đồng Tháp",
  "taxNumber": "0301234567",
  "address": "Ấn Tân Nhuận Đông, Huyện Châu Thành, Tỉnh Đồng Tháp",
  "phone": "02773888999",
  "email": "contact@greenfarm.vn",
  "logoUrl": "https://cdn.greenfarm.vn/assets/logo.png",
  "bankInfo": {
    "bankBin": "970422",
    "bankName": "MBBank",
    "accountNo": "030123456789",
    "accountHolder": "HTX NONG NGHIEP XANH"
  }
}
```

### 3.10. Cột `traceability_snapshots.vietgap_cert_json` (#49)
*   **Mô tả:** Đóng băng chứng chỉ tiêu chuẩn chất lượng VietGAP/GlobalGAP có hiệu lực vào ngày đóng gói lô hàng.
```json
{
  "certNumber": "VIETGAP-TR-2026-088",
  "standardTitle": "Quy trình thực hành sản xuất nông nghiệp tốt VietGAP",
  "certifyingOrganization": "Tổ chức Chứng nhận Vinacert",
  "issuedDate": "2026-01-01",
  "validUntil": "2027-01-01",
  "certifiedAreaM2": 50000.0,
  "licensedScope": "Xoài Cát Chu xuất khẩu"
}
```

### 3.11. Cột `traceability_snapshots.farming_timeline_json` (#49)
*   **Mô tả:** Đóng băng dòng thời gian canh tác sạch, chứng minh đã hoàn thành cách ly PHI trước thu hoạch.
```json
[
  {
    "stageIndex": 1,
    "activityDate": "2026-06-01",
    "stageName": "Làm đất & Xử lý vôi khử trùng",
    "notes": "Bón lót vôi bột nông nghiệp 500kg/ha"
  },
  {
    "stageIndex": 2,
    "activityDate": "2026-07-15",
    "stageName": "Bón phân hữu cơ vi sinh đợt 1",
    "notes": "Phân trùn quế hữu cơ 100% không hóa chất độc hại"
  },
  {
    "stageIndex": 3,
    "activityDate": "2026-09-20",
    "stageName": "Phun phòng trừ sinh học thảo mộc",
    "notes": "Thời gian cách ly 14 ngày (Đã kết thúc cách ly an toàn vào 2026-10-04)"
  }
]
```

### 3.12. Cột `traceability_snapshots.harvest_info_json` (#49)
*   **Mô tả:** Đóng băng dữ liệu thu hoạch tại ruộng vườn.
```json
{
  "harvestRecordCode": "HAR-2610-0012",
  "harvestDate": "2026-10-15",
  "farmName": "Trang Trại Trồng Trọt Châu Thành",
  "zoneName": "Phân Khu Xoài Cát Chu VietGAP",
  "actualHarvestYieldKg": 4500.0,
  "qualityGrade": "GRADE_A"
}
```

### 3.13. Cột `traceability_snapshots.qc_inspection_json` (#49)
*   **Mô tả:** Đóng băng biên bản kiểm định KCS chứng minh sản phẩm không tồn dư thuốc BVTV hoặc vi sinh độc hại.
```json
{
  "inspectionCode": "QC-2610-0005",
  "inspectionDate": "2026-10-16",
  "overallVerdict": "PASSED",
  "inspectorTitle": "Kỹ thuật viên KCS trưởng",
  "testMetrics": [
    {
      "metricName": "Dư lượng Nitrate (NO3)",
      "standardLimit": "< 50 mg/kg",
      "testResult": "12.4 mg/kg",
      "isPassed": true
    },
    {
      "metricName": "Khuẩn E.Coli",
      "standardLimit": "Không phát hiện (0 CFU/g)",
      "testResult": "0 CFU/g",
      "isPassed": true
    }
  ]
}
```

### 3.14. Cột `farm_tasks.photos_json` (#57)
*   **Mô tả:** Mảng các hình ảnh báo cáo kết quả hiện trường do nhân viên gửi lên khi hoàn thành nhiệm vụ.
```json
[
  {
    "photoUrl": "https://cdn.greenfarm.vn/tasks/2026/10/task-88-done.webp",
    "takenAt": "2026-10-18T14:30:00Z",
    "latitude": 10.24567,
    "longitude": 105.78234,
    "caption": "Đã hoàn thành làm cỏ và tỉa cành luống 1 đến 5"
  }
]
```

---

*Văn kiện `SPEC-DATA-015` là bản quy chiếu bất biến về quan hệ thực thể, quyền sở hữu dữ liệu và cấu trúc 15 cột JSON. Toàn bộ các lớp JPA Entity, DTO, Service Mapper và Frontend Component bắt buộc phải tuân thủ 100% cấu trúc này.*
