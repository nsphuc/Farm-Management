# ĐẶC TẢ QUẢN LÝ, KIỂM SOÁT TÀI LIỆU & THỨ TỰ ƯU TIÊN SỰ THẬT
## (MASTER DOCUMENT GOVERNANCE, HIERARCHY OF TRUTH & ANTI-HALLUCINATION RULES)

> **Mã văn kiện:** `SPEC-GOV-000`  
> **Cấp độ hiệu lực:** **TỐI CAO (SUPREME MANDATORY)** — Là Bản Hiến Pháp Quản Trị Tri Thức, Quy Định Thứ Tự Sự Thật Cho Toàn Bộ Kỹ Sư & AI Coding Agent.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (72 bảng hợp nhất) và các bản migration kế thừa hợp lệ đến `V1_4__standardize_4_tier_rbac_matrix.sql` (Chuẩn MySQL 8.x InnoDB).  
> **Tôn chỉ:** *"Một nguồn sự thật duy nhất (Single Source of Truth) - Không suy diễn ngoài lược đồ (Zero Schema Hallucination) - Code phải quy phục đặc tả (Code Obeys Architecture)"*.

---

## 1. THỨ TỰ ƯU TIÊN NGUỒN SỰ THẬT (THE HIERARCHY OF TRUTH)

Khi phát triển, bảo trì, tái cấu trúc hoặc sinh mã tự động bằng AI, mọi xung đột về logic, tên trường, kiểu dữ liệu, bảo mật hoặc hành vi giao diện **BẮT BUỘC PHẢI ĐƯỢC GIẢI QUYẾT THEO THỨ TỰ ƯU TIÊN 3 TẦNG KHẮC KỶ SAU ĐÂY**:

```mermaid
graph TD
    classDef level1 fill:#b91c1c,stroke:#7f1d1d,stroke-width:3px,color:#ffffff;
    classDef level2 fill:#d97706,stroke:#92400e,stroke-width:2px,color:#ffffff;
    classDef level3 fill:#1d4ed8,stroke:#1e40af,stroke-width:2px,color:#ffffff;

    L1["CẤP 1: LƯỢC ĐỒ DATABASE BẤT BIẾN (IMMUTABLE SCHEMA)<br/>V1_0__init_system_core.sql đến V1_4__standardize_4_tier_rbac_matrix.sql (72 Bảng MySQL 8.x)<br/>★ NGUỒN SỰ THẬT TỐI CAO - KHÔNG THỂ BỊ BÁC BỎ ★"]:::level1
    
    L2["CẤP 2: HIẾN PHÁP NGHIỆP VỤ & THIẾT KẾ (SYSTEM SPECIFICATIONS)<br/>Bộ 16 Văn Kiện Master (.antigravity/rules/ từ 00 đến 15)<br/>Quy định Luật nghiệp vụ, State Machines, API DTO, RBAC & UI"]:::level2
    
    L3["CẤP 3: MÃ NGUỒN THỰC THI (APPLICATION SOURCE CODE)<br/>Backend Spring Boot 3.x (Java 17/21) & Frontend React 18+ (Vite)<br/>Nếu Code lệch với Cấp 1 hoặc Cấp 2 ➔ CODE ĐƯỢC COI LÀ LỖI"]:::level3

    L1 -->|Ràng buộc cấu trúc & Constraints| L2
    L2 -->|Chỉ đạo triển khai & Kiểm thử| L3
```

### 1.1. Cấp 1: Nguồn Sự Thật Tối Thượng (Level 1 - Supreme Immutable Truth)
*   **Vị trí tệp tin:** [`backend/src/main/resources/db/migration/`](file:///d:/Projects/Farm_Management/backend/src/main/resources/db/migration/) (Từ baseline `V1_0__init_system_core.sql` đến `V1_4__standardize_4_tier_rbac_matrix.sql`).
*   **Phạm vi áp dụng:**
    1.  Chính xác 100% tên của **72 bảng**, tên cột (column names), kiểu dữ liệu SQL (Data Types), độ dài chuỗi, giá trị mặc định (`DEFAULT`), cờ `NULL / NOT NULL`.
    2.  Khóa chính (`PRIMARY KEY`), khóa ngoại tổ hợp (`COMPOSITE FOREIGN KEYS`), chỉ mục duy nhất (`UNIQUE INDEXES`).
    3.  Tất cả các mệnh đề ràng buộc dữ liệu `CHECK CONSTRAINT` (ví dụ: `geofence_radius_m > 0`, `credit_limit >= 0.00`, `annual_leave_quota >= 0`, `chk_farm_assignments_role`).
    4.  Tập giá trị hợp lệ của toàn bộ các cột `status` và `type` (được định nghĩa trong các `CHECK CONSTRAINT` của bảng).
    5.  Dữ liệu Seed nền tảng chuẩn hóa 4 Cấp: **7 Vai trò hệ thống** (`roles`), **30 Quyền hạn chuẩn** (`permissions`), và bảng ánh xạ quyền (`role_permissions`).
*   **Nguyên tắc tối thượng:** Không có bất kỳ dòng code Java, code TypeScript, hay văn bản đặc tả nào có thẩm quyền sửa đổi cấu trúc Cấp 1 ngoài quy trình Database Migration được phê duyệt chính thức.

### 1.2. Cấp 2: Hiến Pháp Nghiệp Vụ, Bảo Mật & Thiết Kế (Level 2 - Architectural Constitutional Truth)
*   **Vị trí tệp tin:** Thư mục [`.antigravity/rules/`](file:///d:/Projects/Farm_Management/.antigravity/rules/) (Bộ 16 văn kiện từ `00` đến `15`).
*   **Phạm vi áp dụng:**
    1.  Quy tắc nghiệp vụ miền, công thức tính toán toán học, chính sách thời gian cách ly (PHI / Withdrawal Period).
    2.  Máy trạng thái (Finite State Machines - FSM), ma trận chuyển dịch trạng thái hợp lệ/bất hợp lệ.
    3.  Ma trận phân quyền chi tiết (`@PreAuthorize`, `<Can>`), bảo mật dữ liệu đa trang trại (The Farm Barrier Guard).
    4.  Hợp đồng giao tiếp REST API DTO (Request/Response DTO), mã lỗi HTTP đặc thù và cơ chế Idempotency.
    5.  Kiến trúc Frontend 4 Shells, 9 Workspaces, Bản vẽ thi công chi tiết màn hình, Form validation và UX Design System.
    6.  Quy chuẩn chất lượng phi chức năng (NFR), kiến trúc phân lớp, chiến lược kiểm thử và tuân thủ truy xuất nguồn gốc.
*   **Nguyên tắc hiệu lực:** Văn kiện Cấp 2 là tiêu chuẩn nghiệm thu duy nhất cho mã nguồn Cấp 3.

### 1.3. Cấp 3: Mã Nguồn Thực Thi (Level 3 - Executable Implementation)
*   **Vị trí:** [`backend/src/...`](file:///d:/Projects/Farm_Management/backend/) và [`frontend/src/...`](file:///d:/Projects/Farm_Management/frontend/).
*   **Quy định khắc kỷ:**
    > [!CAUTION]
    > Mã nguồn thực thi là sản phẩm cấp dưới. Nếu code Backend hoặc Frontend hiện tại có tên trường, kiểu dữ liệu, API endpoint hoặc logic chuyển trạng thái khác với Cấp 1 hoặc Cấp 2, **CODE HIỆN TẠI ĐƯƠNG NHIÊN BỊ COI LÀ LỖI BỌ (BUG / DRIFT)** và bắt buộc phải refactor để đồng nhất theo Cấp 1 và Cấp 2, tuyệt đối không được sửa đặc tả để "hợp thức hóa" cho code sai!

---

## 2. BẢNG PHÂN ĐỊNH NGUỒN CHUẨN THEO LOẠI THÔNG TIN (DOMAIN SOURCE MAPPING)

Khi kỹ sư hoặc AI Coding Agent cần tra cứu bất kỳ khía cạnh nào của hệ thống, bắt buộc phải truy cập đúng văn kiện thẩm quyền tương ứng theo bảng tra cứu sau:

| STT | Loại Tri Thức / Khía Cạnh Kỹ Thuật | Nguồn Chuẩn Thẩm Quyền (Authoritative Document) | Văn Kiện Bổ Trợ |
| :---: | :--- | :--- | :--- |
| **1** | **Cấu trúc Bảng, Cột, Khóa ngoại, Kiểu dữ liệu, Check Constraints** | [`V1_0__init_system_core.sql`](file:///d:/Projects/Farm_Management/backend/src/main/resources/db/migration/V1_0__init_system_core.sql) | [`15-master-data-dictionary-erd.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/15-master-data-dictionary-erd.md) |
| **2** | **Quy tắc Miền, Nghiệp vụ Lõi, Công thức Tính toán, Phân bổ & Thuật toán** | [`01-master-business-spec.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/01-master-business-spec.md) | [`03-master-validation-constraints.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/03-master-validation-constraints.md) |
| **3** | **Vòng đời Thực thể, Trạng thái `status`, Điều kiện Kích hoạt & Chặn lùi** | [`02-master-state-machines.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/02-master-state-machines.md) | [`06-master-activity-flows.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/06-master-activity-flows.md) |
| **4** | **Ràng buộc Kiểm thực Input (Validation), Giới hạn Độ dài, Định dạng & Regex** | [`03-master-validation-constraints.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/03-master-validation-constraints.md) | [`07-master-api-dto-contracts.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/07-master-api-dto-contracts.md) |
| **5** | **Ma trận Phân quyền 7 Roles $\times$ 30 Permissions (Chuẩn 4 Cấp), Phạm vi SYSTEM/TENANT/FARM** | [`04-master-roles-permissions.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/04-master-roles-permissions.md) | [`05-master-security-rules.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/05-master-security-rules.md) |
| **6** | **An Toàn Bảo Mật, JWT Token Rotation, The Farm Barrier Guard, Audit Trail** | [`05-master-security-rules.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/05-master-security-rules.md) | [`11-master-system-architecture.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/11-master-system-architecture.md) |
| **7** | **Luồng Giao Dịch `@Transactional`, ACID, Khóa Bi quan & Tự động Trừ kho** | [`06-master-activity-flows.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/06-master-activity-flows.md) | [`01-master-business-spec.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/01-master-business-spec.md) |
| **8** | **Hợp Đồng REST API 10 Phân Hệ, Cấu Trúc Request/Response DTO, Idempotency** | [`07-master-api-dto-contracts.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/07-master-api-dto-contracts.md) | [`06-master-activity-flows.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/06-master-activity-flows.md) |
| **9** | **Kiến Trúc Frontend 4 Shells, 9 Workspaces, Luồng Thao Tác & Điều Hướng** | [`08-master-ui-workspace-flows.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/08-master-ui-workspace-flows.md) | [`09-master-screen-action-specs.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/09-master-screen-action-specs.md) |
| **10** | **Bản Vẽ Thi Công 10 Màn Hình Vi Mô, Form Modal, Thẻ `<Can>`, Hành Vi Nút Bấm** | [`09-master-screen-action-specs.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/09-master-screen-action-specs.md) | [`10-ui-ux-design-guidelines.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/10-ui-ux-design-guidelines.md) |
| **11** | **Design System UI/UX, Bảng Màu Nông Nghiệp, Micro-interactions, Accessibility** | [`10-ui-ux-design-guidelines.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/10-ui-ux-design-guidelines.md) | [`08-master-ui-workspace-flows.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/08-master-ui-workspace-flows.md) |
| **12** | **Kiến Trúc Kỹ Thuật Tổng Thể, Cấu Trúc Package Backend/Frontend, ADRs** | [`11-master-system-architecture.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/11-master-system-architecture.md) | Toàn bộ bộ đặc tả |
| **13** | **Tiêu Chuẩn Phi Chức Năng (NFR), Hiệu Năng, Chỉ Số SLA/SLO, Tối Ưu Truy Vấn** | [`12-master-nonfunctional-requirements.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/12-master-nonfunctional-requirements.md) | [`06-master-activity-flows.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/06-master-activity-flows.md) |
| **14** | **Chiến Lược Kiểm Thử (Unit, Integration, E2E), Mocking & Test Data Seeds** | [`13-master-test-strategy-acceptance.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/13-master-test-strategy-acceptance.md) | [`07-master-api-dto-contracts.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/07-master-api-dto-contracts.md) |
| **15** | **Ma Trận Truy Vết Yêu Cầu Đến Triển Khai & Kiểm Thử (RTM 72 Bảng)** | [`14-master-requirements-traceability.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/14-master-requirements-traceability.md) | [`01-master-business-spec.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/01-master-business-spec.md) |
| **16** | **Từ Điển Dữ Liệu 72 Bảng (Data Dictionary), Bảng Ánh Xạ ERD & Cardinality** | [`15-master-data-dictionary-erd.md`](file:///d:/Projects/Farm_Management/.antigravity/rules/15-master-data-dictionary-erd.md) | [`V1_0__init_system_core.sql`](file:///d:/Projects/Farm_Management/backend/src/main/resources/db/migration/V1_0__init_system_core.sql) |

---

## 3. LUẬT CHỐNG ẢO GIÁC CHO AI & QUY TRÌNH GIẢI QUYẾT XUNG ĐỘT (ANTI-HALLUCINATION RULES)

Để ngăn ngừa triệt để hiện tượng AI tự suy diễn, sinh code chắp vá hoặc làm vỡ tính toàn vẹn của hệ thống ERP, mọi AI Agent bắt buộc phải tuân thủ 7 điều răn chống ảo giác:

### 3.1. Bảy Điều Răn Chống Ảo Giác (The 7 Anti-Hallucination Commandments)

> [!IMPORTANT]
> 1. **ĐIỀU 1 - QUẢN LÝ DATABASE MIGRATION NGHIÊM NGẶT:** Cấm tuyệt đối tạo các migration không được phê duyệt. Giữ nguyên tính toàn vẹn (bất biến) của các file migration đã áp dụng ở môi trường dùng chung (staging/production). Toàn bộ thay đổi schema phát sinh từ yêu cầu nghiệp vụ hợp lệ bắt buộc phải thực hiện tuần tự qua chuỗi migration phiên bản hợp lệ từ `V1_0__init_system_core.sql` đến `V1_4__standardize_4_tier_rbac_matrix.sql` (bao gồm: `V1_1__add_farm_id_to_partners.sql`, `V1_2__add_role_farm_manager.sql`, `V1_3__sync_farm_manager_user_roles.sql`, `V1_4__standardize_4_tier_rbac_matrix.sql`).
> 2. **ĐIỀU 2 - CẤM BỊA TÊN BẢNG VÀ TÊN CỘT:** 100% Entity JPA và Query JPQL/SQL phải dùng chính xác tên cột trong schema Cấp 1 (`V1_0` đến `V1_4`). Cấm tự ý thêm các cột như `status_id`, `created_date`, `is_deleted` nếu SQL không có.
> 3. **ĐIỀU 3 - CẤM THÊM / ĐỔI MÃ ROLE & PERMISSION:** Hệ thống có chuẩn **7 Roles chia làm 4 Cấp** (`ROLE_SUPER_ADMIN`, `ROLE_FARM_OWNER`, `ROLE_FARM_MANAGER`, `ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_ACCOUNTANT`, `ROLE_FIELD_STAFF`) và đúng **30 Permissions** chuẩn `PERM_*` (được chuẩn hóa toàn diện tại Flyway Migration `V1_4__standardize_4_tier_rbac_matrix.sql`). Cấm tự ý bịa thêm mã quyền hoặc vai trò ngoài danh mục chuẩn.
> 4. **ĐIỀU 4 - CẤM TỰ ĐỔI GIÁ TRI ENUM / STATUS:** Các giá trị trạng thái phải tuân thủ 100% theo các mệnh đề `CHECK CONSTRAINT` của SQL (ví dụ: `farms.farm_type` chỉ có `CROP`, `LIVESTOCK`, `AQUACULTURE`, `MIXED`; `farm_assignments.role_in_farm` gồm 8 vị trí chuẩn: `'FARM_MANAGER'`, `'ZONE_MANAGER'`, `'TECHNICAL_LEAD'`, `'AGRONOMIST'`, `'VETERINARIAN'`, `'WAREHOUSE_KEEPER'`, `'ACCOUNTANT'`, `'FIELD_WORKER'`; `sales_orders.status` chỉ có `PENDING`, `CONFIRMED`, `DELIVERED`, `COMPLETED`, `CANCELLED`; `farm_tasks.status` chỉ có `TODO`, `IN_PROGRESS`, `PENDING_REVIEW`, `DONE`, `CANCELLED`; `crop_seasons.status` chỉ có `SOIL_PREPARATION`, `SOWING`, `GROWING`, `HARVESTING`, `CLOSED`, `CANCELLED`).
> 5. **ĐIỀU 5 - CẤM RÒ RỈ ENTITY RA API:** Mọi Controller Spring Boot bắt buộc chỉ nhận Request DTO và trả Response DTO. Cấm trả Entity JPA trực tiếp ra ngoài API.
> 6. **ĐIỀU 6 - CẤM BỎ QUA GEOFENCE & CAMERA CHẤM CÔNG:** Nghiệp vụ chấm công bắt buộc phải xác thực khoảng cách GPS $\le$ `geofence_radius_m` và chụp ảnh selfie từ camera trước; không được phép hạ cấp thành form nhập giờ thông thường.
> 7. **ĐIỀU 7 - CẤM VI PHẠM NGUYÊN TẮC PHÂN TÁCH KCS (MAKER-CHECKER):** `ROLE_TECHNICAL_STAFF` tuyệt đối không được cấp quyền `PERM_QC_APPROVE` hay `PERM_QC_RECALL`. Người kiểm định không được tự duyệt lô hàng của mình.

### 3.2. Quy Trình 4 Bước Xử Lý Xung Đột Dữ Liệu (Conflict Resolution Workflow)

Khi phát hiện mâu thuẫn giữa 2 tài liệu hoặc giữa tài liệu và mã nguồn, kỹ sư hoặc AI phải thực hiện quy trình sau:

```mermaid
sequenceDiagram
    autonumber
    actor Dev as Developer / AI Agent
    participant DDL as Cấp 1: V1_0__init_system_core.sql -> V1_4
    participant Spec as Cấp 2: File Thẩm Quyền (.md)
    participant Sec as File Bổ Trợ (.md)
    participant Code as Cấp 3: Source Code

    Dev->>Dev: Phát hiện mâu thuẫn dữ liệu hoặc logic
    Dev->>DDL: Bước 1: Tra cứu trực tiếp SQL DDL (72 bảng & V1_4 RBAC)
    Note over Dev,DDL: Khóa ngoại, Tên cột, Constraint, Seed Data
    Dev->>Spec: Bước 2: Tra cứu File Thẩm Quyền chuyên trách (Bảng Mục 2)
    Dev->>Sec: Bước 3: Đồng bộ hóa cập nhật file bổ trợ theo File Thẩm Quyền
    Dev->>Code: Bước 4: Chỉnh sửa Source Code tuân phục theo Cấp 1 & Cấp 2
    Note over Dev,Code: Xác nhận 100% nhất quán - Không thỏa hiệp
```

1.  **Bước 1 (Hỏi Cấp 1):** Mở các file migration từ [`V1_0__init_system_core.sql`](file:///d:/Projects/Farm_Management/backend/src/main/resources/db/migration/V1_0__init_system_core.sql) đến [`V1_4__standardize_4_tier_rbac_matrix.sql`](file:///d:/Projects/Farm_Management/backend/src/main/resources/db/migration/V1_4__standardize_4_tier_rbac_matrix.sql) để kiểm tra cấu trúc cột, khóa ngoại, constraint và RBAC seed thực tế.
2.  **Bước 2 (Hỏi Cấp 2 chuyên trách):** Đối chiếu với văn kiện chuyên trách cao nhất được định nghĩa tại Bảng Phân Định ở Mục 2.
3.  **Bước 3 (Đồng bộ tài liệu):** Nếu phát hiện văn kiện bổ trợ có sơ suất ghi sai tên cột hoặc ENUM, lập tức sửa văn kiện bổ trợ đó cho khớp 100% với file chuyên trách và SQL.
4.  **Bước 4 (Hiệu chỉnh Source Code):** Sửa code Backend/Frontend để quy phục hoàn toàn theo Cấp 1 và Cấp 2.

---

## 4. QUY TẮC ĐÁNH PHIÊN BẢN (VERSIONING) & DANH MỤC 16 VĂN KIỆN MASTER

### 4.1. Vòng Đời Trạng Thái Văn Kiện (Document Lifecycle States)
Toàn bộ các văn kiện đặc tả trong thư mục `.antigravity/rules/` đều trải qua 4 trạng thái kiểm soát vòng đời:

$$\text{DRAFT} \xrightarrow{\text{Kiểm tra chéo DDL}} \text{REVIEWED} \xrightarrow{\text{Phê duyệt kiến trúc}} \text{APPROVED} \xrightarrow{\text{Lập trình hoàn tất}} \text{IMPLEMENTED}$$

*   **`DRAFT`:** Bản thảo sơ bộ, đang trong quá trình biên soạn.
*   **`REVIEWED`:** Đã qua rà soát đối chiếu với 72 bảng trong `V1_0__init_system_core.sql` và các migration hợp lệ, không còn lệch tên cột.
*   **`APPROVED`:** Đã được Chief Architect phê duyệt chính thức làm chuẩn mực thi công bất biến.
*   **`IMPLEMENTED`:** Toàn bộ mã nguồn Backend và Frontend đã được code và kiểm thử tự động đạt 100% tiêu chí văn kiện.

### 4.2. Danh Mục Toàn Bộ 16 Văn Kiện Master Kiến Trúc Hệ Thống (Master Spec Directory)

| Số Hiệu | Mã Văn Kiện | Tên Văn Kiện | Phiên Bản | Trạng Thái | Phạm Vi Ràng Buộc |
| :---: | :---: | :--- | :---: | :---: | :--- |
| **00** | `SPEC-GOV-000` | **Đặc tả Quản lý, Kiểm soát Tài liệu & Thứ tự Ưu tiên Sự thật** | `v2.0` | **APPROVED** | Toàn bộ dự án, Kỹ sư & AI Agent |
| **01** | `SPEC-CORE-001` | **Đặc tả Nghiệp vụ Lõi, Quy tắc Miền & Hoạt động Canh tác** | `v2.0` | **APPROVED** | Backend Services, Frontend Forms |
| **02** | `SPEC-STATE-002`| **Đặc tả Máy Trạng Thái, Vòng Đời & Ma Trận Chuyển Dịch** | `v2.0` | **APPROVED** | Domain Models, Service Guards, UI Badges |
| **03** | `SPEC-MATH-003` | **Đặc tả Ràng Buộc Dữ Liệu, Biểu Thức Chính Quy & Kiểm Thực** | `v2.0` | **APPROVED** | Jakarta Validation, React Hook Form |
| **04** | `SPEC-RBAC-004` | **Ma Trận Phân Quyền 7 Roles $\times$ 30 Permissions & Phạm Vi 4 Cấp** | `v2.0` | **APPROVED** | Spring Security `@PreAuthorize`, UI `<Can>` |
| **05** | `RULE-SEC-005` | **Đặc tả Bảo Mật, JWT Token Rotation & The Farm Barrier Guard** | `v2.0` | **APPROVED** | Security Filters, Interceptors, Cookies |
| **06** | `SPEC-FLOW-006` | **Đặc tả Luồng Hoạt Động Giao Dịch, ACID & Khóa Bi Quan** | `v2.0` | **APPROVED** | Spring `@Transactional`, DB Locking |
| **07** | `SPEC-API-007` | **Hợp Đồng REST API 10 Phân Hệ, DTO Contracts & Idempotency** | `v2.0` | **APPROVED** | Spring Controllers, React Query Services |
| **08** | `RULE-UI-001`| **Đặc tả Kiến Trúc UI 4 Shells, 9 Workspaces & Luồng Thao Tác** | `v2.0` | **APPROVED** | React Router, App Layouts, Navigation |
| **09** | `SPEC-UI-SCREEN-009`| **Đặc Tả Chi Tiết 10 Màn Hình Vi Mô, Form & Ma Trận Nút Bấm** | `v2.0` | **APPROVED** | React Pages, Modals, Action Handlers |
| **10** | `RULE-UX-010`| **Cẩm Nang Tiêu Chuẩn Thẩm Mỹ, Bảng Màu & Micro-Interactions** | `v2.0` | **APPROVED** | Tailwind/CSS Variables, UI Components |
| **11** | `SPEC-ARCH-011` | **Đặc Tả Thiết Kế Kiến Trúc Tổng Thể Hệ Thống & Cấu Trúc Code** | `v2.0` | **APPROVED** | Backend Packages, Frontend Directories |
| **12** | `SPEC-NFR-012` | **Đặc Tả Tiêu Chuẩn Phi Chức Năng, Hiệu Năng & SLA/SLO** | `v2.0` | **APPROVED** | DB Indexing, Caching, Query Tuning |
| **13** | `SPEC-TEST-013` | **Đặc Tả Chiến Lược Kiểm Thử & Kịch Bản Nghiệm Thu Toàn Hệ Thống** | `v2.0` | **APPROVED** | JUnit 5, Mockito, Playwright/Cypress |
| **14** | `SPEC-TRACE-014`| **Ma Trận Truy Vết Yêu Cầu Đến Triển Khai & Kiểm Thử (RTM 72 Bảng)** | `v2.0` | **APPROVED** | Traceability Matrix 72 Bảng, Test Coverage |
| **15** | `SPEC-DATA-015` | **Từ Điển Dữ Liệu 72 Bảng, Lược Đồ ERD & Ánh Xạ Quan Hệ** | `v2.0` | **APPROVED** | JPA Entities, Liquibase/Flyway Migration |

---

### 4.3. Quy Định Chuẩn Hóa Danh Mục & Loại Hình Sản Xuất
*   **3 Loại Hình Trang Trại Duy Nhất:** Nền tảng Agri-ERP chuẩn hóa tập trung vào đúng 3 loại hình trang trại gồm: `'CROP'` (Trồng trọt), `'LIVESTOCK'` (Chăn nuôi), và `'MIXED'` (Hỗn hợp Trồng trọt & Chăn nuôi). Hệ thống loại bỏ hoàn toàn loại hình Thủy sản (`AQUACULTURE` / `AQUA` / `POND`). Toàn bộ giao diện và backend tự động thích ứng theo `activeFarmType`.

---

*Văn kiện `SPEC-GOV-000` là Hiến pháp tối cao của hệ sinh thái Farm Management SaaS. Bất kỳ sự vi phạm nào đối với thứ tự sự thật và các điều răn trong văn kiện này đều bị coi là sai phạm kiến trúc nghiêm trọng.*
