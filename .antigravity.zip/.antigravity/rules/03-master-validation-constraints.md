# ĐẶC TẢ RÀNG BUỘC TỐI CAO & CÔNG THỨC TOÁN HỌC AGRI-ERP
## (MASTER VALIDATION CONSTRAINTS & MATHEMATICAL IDENTITIES)

> **Mã văn kiện:** `SPEC-MATH-003`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Là Bộ Quy Chuẩn Validation Tối Cao Ánh Xạ Trực Tiếp Từ Database Ràng Buộc Vào Backend DTO/Service và Frontend Forms.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Tôn chỉ:** *"Toán học không nói dối - Dữ liệu bất biến - Chống hoàn toàn xuất âm tồn kho, gian lận công nợ và lỗi phân cấp đa tenant"*.

---

## 1. QUY TẮC SINH MÃ TỰ ĐỘNG CHO 21 THỰC THỂ CỐT LÕI (AUTO-CODE GENERATION)

Mọi mã nghiệp vụ định danh trong hệ thống đều phải tuân thủ định dạng chuẩn:
$$\text{[TIỀN\_TỐ]} - \text{[YYMM]} - \text{[SEQUENCE\_000X]}$$
Áp dụng cơ chế khóa bi quan (**Pessimistic Write Lock**) hoặc Sequence Table cấp Tenant/Farm để tuyệt đối không trùng lặp mã khi có nhiều người dùng thao tác đồng thời.

| STT | Bảng SQL | Cột Mã Định Danh | Tiền Tố Chuẩn | Khóa Duy Nhất SQL (Unique Constraint) | Ý Nghĩa Nghiệp Vụ |
| :---: | :--- | :--- | :---: | :--- | :--- |
| **1** | `partners` (#4) | `code` | `PRT-` | `uk_partners_tenant_code (tenant_id, code)` | Đối tác Nhà cung cấp / Khách hàng |
| **2** | `farms` (#11) | `code` | `FRM-` | `uk_farms_tenant_code (tenant_id, code)` | Mã trang trại cơ sở thực địa |
| **3** | `production_zones` (#13) | `code` | `ZON-` | `uk_production_zones_farm_code (farm_id, code)` | Mã phân khu nhà kính / chuồng / ao |
| **4** | `zone_locations` (#14) | `code` | `LOC-` | `uk_zone_locations_zone_code (zone_id, code)` | Mã lô đất, luống canh tác, ô chuồng |
| **5** | `crop_types` (#18) | `variety_code` | `VAR-` | `uk_crop_types_tenant_variety (tenant_id, variety_code)` | Mã giống cây trồng |
| **6** | `crop_seasons` (#19) | `season_code` | `SSN-` | `uk_crop_seasons_farm_code (tenant_id, farm_id, season_code)` | Mã mùa vụ canh tác |
| **7** | `livestock_groups` (#22) | `group_code` | `GRP-` | `uk_livestock_groups_code (tenant_id, farm_id, group_code)` | Mã đàn / lứa nuôi |
| **8** | `livestock_individuals` (#23)| `rfid_tag_code` | `TAG-` | `uk_livestock_individuals_rfid (tenant_id, rfid_tag_code)` | Mã thẻ tai RFID cá thể gia súc |
| **9** | `warehouses` (#26) | `code` | `WHS-` | `uk_warehouses_farm_code (farm_id, code)` | Mã kho lưu trữ vật tư / nông sản |
| **10** | `material_categories` (#27)| `code` | `MCT-` | `uk_material_categories_code (tenant_id, code)` | Mã nhóm danh mục vật tư |
| **11** | `materials` (#28) | `sku_code` | `SKU-` | `uk_materials_sku (tenant_id, sku_code)` | Mã định danh vật tư lưu kho |
| **12** | `warehouse_receipts` (#32) | `receipt_code` | `RC-` | `uk_warehouse_receipts_code (tenant_id, farm_id, receipt_code)` | Mã phiếu nhập kho |
| **13** | `warehouse_issues` (#34) | `issue_code` | `IS-` | `uk_warehouse_issues_code (tenant_id, farm_id, issue_code)` | Mã phiếu xuất kho |
| **14** | `warehouse_transfers` (#36)| `transfer_code` | `TR-` | `uk_warehouse_transfers_tenant_code (tenant_id, transfer_code)` | Mã phiếu điều chuyển liên kho |
| **15** | `stocktakes` (#39) | `stocktake_code` | `STK-` | `uk_stocktakes_code (tenant_id, farm_id, stocktake_code)` | Mã biên bản kiểm kê kho |
| **16** | `harvest_records` (#43) | `harvest_code` | `HRV-` | `uk_harvest_records_code (tenant_id, farm_id, harvest_code)` | Mã biên bản thu hoạch nông sản |
| **17** | `product_batches` (#44) | `batch_code` | `BAT-` | `uk_product_batch_code (tenant_id, farm_id, batch_code)` | Mã lô thành phẩm đóng gói |
| **18** | `qc_inspections` (#46) | `inspection_code`| `QC-` | `uk_qc_inspections_code (tenant_id, farm_id, inspection_code)` | Mã biên bản kiểm định chất lượng KCS |
| **19** | `employees` (#51) | `employee_code` | `EMP-` | `uk_employees_tenant_code (tenant_id, employee_code)` | Mã hồ sơ nhân viên |
| **20** | `work_shifts` (#52) | `shift_code` | `SHF-` | `uk_work_shifts_code (tenant_id, shift_code)` | Mã ca làm việc |
| **21** | `sales_orders` (#62) | `order_code` | `SO-` | `uk_sales_orders_code (tenant_id, farm_id, order_code)` | Mã đơn đặt hàng bán sỉ |

*(Các mã chứng từ bổ sung tuân thủ cùng quy tắc: `sales_deliveries.delivery_code` $\rightarrow$ `DO-`, `payment_transactions.payment_code` $\rightarrow$ `PAY-`, `farm_expenses.expense_code` $\rightarrow$ `EXP-`, `cost_categories.code` $\rightarrow$ `CST-`).*

---

## 2. NĂM ĐẲNG THỨC TOÁN HỌC CỐT LÕI (THE 5 MATHEMATICAL IDENTITIES)

Mọi dòng code Backend và Frontend tính toán số liệu phải tuân thủ nghiêm ngặt 5 đẳng thức toán học bảo toàn sau:

### 2.1. Đẳng thức 1: Bảo toàn Tồn kho & Cấm Xuất Âm (Zero Negative Stock)
Áp dụng cho `warehouse_inventory` (#31), Sổ cái `warehouse_inventory_transactions` (#38), và `product_batch_transactions` (#48).
*   **Công thức biến động số dư thẻ kho:**
    $$\text{balance\_after} = \begin{cases} \text{balance\_before} + \text{quantity} & \text{khi } \text{direction} = \text{'IN'} \\ \text{balance\_before} - \text{quantity} & \text{khi } \text{direction} = \text{'OUT'} \end{cases}$$
*   **Ràng buộc Check Constraint trong SQL:**
    ```sql
    CONSTRAINT chk_inv_trans_balance_math CHECK (
        (direction = 'IN' AND balance_after = balance_before + quantity) OR
        (direction = 'OUT' AND balance_after = balance_before - quantity)
    ),
    CONSTRAINT chk_inv_trans_balances CHECK (balance_before >= 0.00 AND balance_after >= 0.00)
    ```
*   **Nguyên tắc Bất biến:** `balance_after` trong mọi thời điểm **BẮT BUỘC $\ge 0.00$**. Nếu yêu cầu xuất kho có `quantity > balance_before`: Backend lập tức từ chối và ném lỗi `INSUFFICIENT_STOCK` (HTTP 400).

### 2.2. Đẳng thức 2: Bảo toàn Số dư Công nợ Đối tác (Debt Preservation)
Áp dụng cho bảng `debt_records` (#66).
*   **Công thức cân đối công nợ:**
    $$0.00 \le \text{paid\_amount} \le \text{total\_debt}$$
    $$\text{remaining\_debt} = \text{total\_debt} - \text{paid\_amount}$$
*   **Ràng buộc Check Constraint trong SQL:**
    ```sql
    CONSTRAINT chk_debt_records_amounts CHECK (
        total_debt >= 0.00 AND
        paid_amount >= 0.00 AND
        remaining_debt >= 0.00 AND
        paid_amount <= total_debt AND
        remaining_debt = (total_debt - paid_amount)
    )
    ```
*   **Xử lý Trạng thái:** Khi `remaining_debt == 0.00`, trạng thái `status` tự động chuyển sang `'SETTLED'`.

### 2.3. Đẳng thức 3: Cấu trúc Tài chính Đơn Bán sỉ (Sales Order Financial Formula)
Áp dụng cho bảng `sales_orders` (#62).
*   **Công thức tính Tổng thanh toán và Tiền nợ:**
    $$\text{final\_amount} = \text{subtotal\_amount} - \text{discount\_amount} + \text{vat\_amount}$$
    $$\text{debt\_amount} = \text{final\_amount} - \text{paid\_amount}$$
    $$0.00 \le \text{discount\_amount} \le \text{subtotal\_amount}$$
    $$0.00 \le \text{vat\_rate} \le 100.00$$
    $$0.00 \le \text{paid\_amount} \le \text{final\_amount}$$
*   **Ràng buộc Check Constraint trong SQL:**
    ```sql
    CONSTRAINT chk_sales_orders_financials CHECK (
        subtotal_amount >= 0.00 AND
        discount_amount >= 0.00 AND discount_amount <= subtotal_amount AND
        vat_rate >= 0.00 AND vat_rate <= 100.00 AND
        vat_amount >= 0.00 AND
        final_amount >= 0.00 AND
        paid_amount >= 0.00 AND
        debt_amount >= 0.00 AND
        paid_amount <= final_amount AND
        final_amount = (subtotal_amount - discount_amount + vat_amount) AND
        debt_amount = (final_amount - paid_amount)
    )
    ```

### 2.4. Đẳng thức 4: Giới hạn Phân bổ Dòng tiền Thanh toán (Payment Allocation Boundary)
Áp dụng cho bảng `payment_transactions` (#67) và `payment_allocations` (#68).
*   **Công thức phân bổ dòng tiền:** Một phiếu thanh toán ngân hàng có giá trị `amount` có thể được phân bổ để cấn trừ nhiều khoản nợ khác nhau, nhưng tổng tiền phân bổ không được vượt quá số tiền thực tế nhận:
    $$\sum_{i=1}^{n} \text{payment\_allocations.allocated\_amount}_i \le \text{payment\_transactions.amount}$$
*   **Ràng buộc Check Constraint trong SQL:**
    ```sql
    CONSTRAINT chk_payment_trans_alloc CHECK (allocated_amount >= 0.00 AND allocated_amount <= amount)
    ```

### 2.5. Đẳng thức 5: Giữ chỗ Hàng Tồn kho (Stock Reservation Bound)
Áp dụng cho bảng tồn kho vật tư `warehouse_inventory` (#31) và kho thành phẩm `product_batches` (#44).
*   **Công thức khả dụng:**
    $$0.00 \le \text{reserved\_quantity} \le \text{remaining\_quantity} \le \text{initial\_quantity}$$
    $$\text{Tồn khả dụng (Available Stock)} = \text{remaining\_quantity} - \text{reserved\_quantity} \ge 0.00$$
*   **Ràng buộc Check Constraint trong SQL:**
    ```sql
    CONSTRAINT chk_product_batches_quantities CHECK (
        initial_quantity > 0.00 AND
        remaining_quantity >= 0.00 AND
        remaining_quantity <= initial_quantity AND
        reserved_quantity >= 0.00 AND
        reserved_quantity <= remaining_quantity
    )
    ```

---

## 3. CÁC RÀNG BUỘC LOẠI TRỪ NHAU (XOR INTEGRITY RULES)

Hệ thống thiết lập 6 luật toàn vẹn loại trừ lẫn nhau (Mutual Exclusion - XOR) nhằm ngăn chặn dữ liệu "nửa nạc nửa mỡ" gây xung đột logic nghiệp vụ:

```mermaid
graph TD
    subgraph "LUẬT LOẠI TRỪ NHAU (XOR INTEGRITY)"
        U[users: Super Admin XOR Tenant User]
        LE[livestock_events: Đàn nuôi XOR Cá thể RFID]
        WL[livestock_weight_logs: Cân theo Đàn XOR Cân Cá thể]
        HR[harvest_records: Vụ Trồng trọt XOR Đàn Chăn nuôi]
        MQ[consumption_quotas: Định mức Cây trồng XOR Giống Vật nuôi]
        PBS[product_batch_sources: Thu hoạch XOR Mùa vụ XOR Đàn nuôi]
    end
```

### 3.1. Phân định Tài khoản Quản trị (`users` #5)
*   Một tài khoản người dùng hoặc là **Quản trị viên Hệ thống toàn cầu (`is_super_admin = TRUE`)** không thuộc bất kỳ tenant nào (`tenant_id IS NULL`), HOẶC là **Người dùng Doanh nghiệp (`is_super_admin = FALSE`)** bắt buộc phải trực thuộc một tenant cụ thể (`tenant_id IS NOT NULL`):
    ```sql
    CONSTRAINT chk_users_super_admin_tenant CHECK (
        (is_super_admin = TRUE AND tenant_id IS NULL) OR
        (is_super_admin = FALSE AND tenant_id IS NOT NULL)
    )
    ```

### 3.2. Đối tượng Can thiệp Thú y (`livestock_events` #25)
*   Một sự kiện chăm sóc/thú y chỉ được can thiệp vào một Đàn nuôi HOẶC một Cá thể gắn chip RFID riêng biệt, không được vừa áp dụng cho cả đàn vừa chỉ định 1 cá thể trong cùng một dòng:
    ```sql
    CONSTRAINT chk_livestock_event_target CHECK (
        (target_type = 'GROUP' AND livestock_group_id IS NOT NULL AND livestock_individual_id IS NULL) OR
        (target_type = 'INDIVIDUAL' AND livestock_individual_id IS NOT NULL AND livestock_group_id IS NULL)
    )
    ```

### 3.3. Đối tượng Ghi nhận Cân nặng (`livestock_weight_logs` #24)
*   Bản ghi theo dõi tăng trọng chỉ thuộc về một Cá thể riêng biệt HOẶC cân trung bình của cả Đàn:
    ```sql
    CONSTRAINT chk_weight_log_target CHECK (
        (target_type = 'INDIVIDUAL' AND individual_id IS NOT NULL AND group_id IS NULL) OR
        (target_type = 'GROUP' AND group_id IS NOT NULL AND individual_id IS NULL)
    )
    ```

### 3.4. Nguồn gốc Sản phẩm Thu hoạch (`harvest_records` #43)
*   Sản phẩm nông sản thu hoạch bắt buộc phải đến từ một Mùa vụ Canh tác (`CROP_SEASON`) HOẶC từ một Đàn Chăn nuôi (`LIVESTOCK_GROUP`):
    ```sql
    CONSTRAINT chk_harvest_records_source CHECK (
        (source_type = 'CROP_SEASON' AND season_id IS NOT NULL AND livestock_group_id IS NULL) OR
        (source_type = 'LIVESTOCK_GROUP' AND livestock_group_id IS NOT NULL AND season_id IS NULL)
    )
    ```

### 3.5. Định mức Tiêu hao Vật tư (`consumption_quotas` #30)
*   Một định mức kỹ thuật nông vụ áp dụng cho Giống cây trồng HOẶC cho Giống vật nuôi:
    ```sql
    CONSTRAINT chk_consumption_quotas_target CHECK (
        (crop_type_id IS NOT NULL AND livestock_breed_id IS NULL) OR
        (crop_type_id IS NULL AND livestock_breed_id IS NOT NULL)
    )
    ```

### 3.6. Nguồn Gom Lô Thành phẩm Đóng gói (`product_batch_sources` #45)
*   Mỗi dòng nguyên liệu góp vào lô thành phẩm chỉ được trỏ tới 1 trong 3 thực thể nguồn duy nhất:
    ```sql
    CONSTRAINT chk_batch_source_valid CHECK (
        (source_type = 'HARVEST_RECORD' AND harvest_record_id IS NOT NULL AND crop_season_id IS NULL AND livestock_group_id IS NULL) OR
        (source_type = 'CROP_SEASON' AND crop_season_id IS NOT NULL AND harvest_record_id IS NULL AND livestock_group_id IS NULL) OR
        (source_type = 'LIVESTOCK_GROUP' AND livestock_group_id IS NOT NULL AND harvest_record_id IS NULL AND crop_season_id IS NULL)
    )
    ```

---

## 4. RÀNG BUỘC THỜI GIAN, ĐỊA LÝ & NHÂN SỰ

### 4.1. Ràng buộc Logic Thời gian (Chronological Logic)
Mọi cặp thời gian bắt đầu - kết thúc trên toàn bộ 72 bảng bắt buộc tuân thủ nguyên tắc thời gian xuôi dòng:
1.  **Chu kỳ Vận hành (`operational_cycles` #16):**
    $$\text{end\_date} \ge \text{start\_date}$$
2.  **Mùa vụ Canh tác (`crop_seasons` #19):**
    $$\text{expected\_harvest\_date} \ge \text{start\_date} \quad \text{và} \quad \text{actual\_harvest\_date} \ge \text{start\_date}$$
3.  **Lô Thành phẩm (`product_batches` #44):**
    $$\text{expiry\_date} \ge \text{harvest\_date}$$
4.  **Chấm công GPS (`time_attendances` #54):**
    $$\text{check\_out\_time} \ge \text{check\_in\_time}$$
5.  **Nghỉ phép & Làm thêm (`leave_requests` #55 & `overtime_requests` #56):**
    $$\text{end\_date} \ge \text{start\_date} \quad \text{và} \quad \text{end\_time} > \text{start\_time}$$

### 4.2. Ràng buộc Địa lý & Chấm công GPS Thực địa (Geofence Guard)
*   **Công thức Haversine tính Khoảng cách Chấm công:** Khi công nhân check-in trên mobile, tọa độ GPS gửi lên $(\text{lat}_1, \text{lon}_1)$ được đối chiếu với tâm trang trại $(\text{lat}_0, \text{lon}_0)$ trong bảng `farms`:
    $$d = 2R \times \arcsin\left(\sqrt{\sin^2\left(\frac{\Delta\text{lat}}{2}\right) + \cos(\text{lat}_0)\cos(\text{lat}_1)\sin^2\left(\frac{\Delta\text{lon}}{2}\right)}\right)$$
    *Lưu kết quả vào `time_attendances.gps_distance_m`.*
*   **ĐIỀU KIỆN ĐÁNH GIÁ TRẠNG THÁI CHẤM CÔNG:**
    *   Nếu $\text{gps\_distance\_m} \le \text{farms.geofence\_radius\_m}$: Trạng thái chấm công hợp lệ (`status = 'VALID'`).
    *   Nếu $\text{gps\_distance\_m} > \text{farms.geofence\_radius\_m}$: Hệ thống tự động đánh dấu `status = 'OUT_OF_RANGE'`, lưu cờ `is_adjusted = true` để Người quản lý xem xét và phê duyệt thủ công.

### 4.3. Ràng buộc Pháp lý Lao động & Tuổi Nhân viên (Labor Law Compliance)
*   Bảng `employees` (#51): Ngày sinh `date_of_birth` bắt buộc thỏa mãn độ tuổi lao động tối thiểu theo Bộ luật Lao động Việt Nam:
    $$\text{Tuổi nhân viên} = \text{DATEDIFF}(\text{CURRENT\_DATE}, \text{date\_of\_birth}) / 365.25 \ge 18 \text{ tuổi}$$
*   Backend ném lỗi `VALIDATION_UNDERAGE_EMPLOYEE` nếu `date_of_birth` cho ra độ tuổi nhỏ hơn 18.

### 4.4. Ràng buộc Vai trò Hiện trường & Validate DTO Nhân sự
1.  **Ràng buộc Check Constraint bảng `farm_assignments` (#15):**
    *   Hỗ trợ đầy đủ 8 chức danh công việc tại trại (đã mở rộng thêm vị trí Kế toán theo Flyway `V1_4`):
        ```sql
        CONSTRAINT chk_farm_assignments_role CHECK (
            role_in_farm IN (
                'FARM_MANAGER',     -- Giám đốc / Quản lý trang trại
                'ZONE_MANAGER',     -- Quản lý phân khu sản xuất
                'TECHNICAL_LEAD',   -- Trưởng nhóm kỹ thuật / KCS
                'AGRONOMIST',       -- Kỹ sư nông học / Cây trồng
                'VETERINARIAN',     -- Bác sĩ thú y
                'WAREHOUSE_KEEPER', -- Thủ kho
                'ACCOUNTANT',       -- Kế toán trang trại
                'FIELD_WORKER'      -- Công nhân / Lao động hiện trường
            )
        )
        ```
2.  **Quy Chuẩn Validate DTO Nhân sự (`EmployeeDTO` / `EmployeeCreateRequest`):**
    *   **BỎ HOÀN TOÀN TRƯỜNG `department`:** DTO tuyệt đối không chứa trường `department`. Backend Service tự suy diễn ngầm giá trị phòng ban từ `position`.
    *   **Các trường bắt buộc (`@NotBlank`, `@NotNull`):**
        *   `full_name`: `@NotBlank(message = "Họ tên nhân viên không được để trống")`
        *   `id_card_number`: `@NotBlank`, `@Pattern(regexp = "^[0-9]{12}$", message = "Số CCCD phải gồm đúng 12 chữ số")`
        *   `phone`: `@NotBlank`, `@Pattern(regexp = "^(0|\\+84)(3[2-9]|5[2689]|7[06-9]|8[1-9]|9[0-9])[0-9]{7}$", message = "Số điện thoại di động Việt Nam không hợp lệ")`
        *   `email`: `@NotBlank`, `@Email(message = "Địa chỉ email không đúng định dạng chuẩn RFC 5322")`
        *   `joined_date`: `@NotNull(message = "Ngày vào làm không được để trống")`
        *   `contract_type`: `@NotNull(message = "Loại hợp đồng không được để trống")`
        *   `position`: `@NotBlank(message = "Vị trí công việc không được để trống")`
        *   `farm_id`: `@NotNull(message = "Trang trại trực thuộc không được để trống đối với nhân sự cấp Farm")`

---

## 5. BỘ LỌC ĐỊNH DẠNG DỮ LIỆU & REGEX TOÀN HỆ THỐNG

| Tên Trường | Kiểu Dữ Liệu SQL | Độ Dài / Scale | Biểu Thức Chính Quy (Regex) | Thông Báo Lỗi Chuẩn |
| :--- | :--- | :--- | :--- | :--- |
| **`email`** | `VARCHAR(150)` | Max 150 | `^[A-Za-z0-9+_.-]+@([A-Za-z0-9.-]+\.[A-Za-z]{2,})$` | Địa chỉ email không đúng định dạng chuẩn RFC 5322 |
| **`phone`** | `VARCHAR(30)` | 10-12 số | `^(0\|\+84)(3[2-9]\|5[2689]\|7[06-9]\|8[1-9]\|9[0-9])[0-9]{7}$` | Số điện thoại di động Việt Nam không hợp lệ |
| **`id_card_number`** | `VARCHAR(30)` | Đúng 12 số | `^[0-9]{12}$` | Số Căn cước công dân (CCCD) phải gồm đúng 12 chữ số |
| **`password`** | `VARCHAR(255)` | 8 - 64 ký tự | `^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&._\-#])[A-Za-z\d@$!%*?&._\-#]{8,64}$` | Mật khẩu phải có ít nhất 1 chữ hoa, 1 chữ thường, 1 số, 1 ký tự đặc biệt |
| **Mã Code (`code`)**| `VARCHAR(50)` | Max 50 | `^[A-Z0-9]+(-[A-Z0-9]+)*$` | Mã chỉ gồm chữ in hoa, số và dấu gạch nối '-' |
| **`tax_code`** | `VARCHAR(50)` | 10 hoặc 13 số | `^[0-9]{10}(-[0-9]{3})?$` | Mã số thuế doanh nghiệp phải gồm 10 hoặc 13 chữ số |
| **Tiền tệ (`amount`)**| `DECIMAL(14, 2)`| Max 999 tỷ | Tối đa 2 chữ số thập phân, không âm | Giá trị tiền tệ không được âm |
| **Số lượng (`qty`)**| `DECIMAL(12, 2)`| Max 9.9 tỷ | Tối đa 2 chữ số thập phân, $\ge 0.00$ | Số lượng không được âm |
| **Hệ số quy đổi** | `DECIMAL(12, 4)`| Max 9.9999 | Tối đa 4 chữ số thập phân, $> 0.0000$ | Hệ số quy đổi phải lớn hơn 0 |

---
*Văn kiện `SPEC-MATH-003` là cơ sở để triển khai Bean Validation (@Valid, @Pattern, @DecimalMin) tại Backend Spring Boot và Zod/Yup Schemas tại Frontend React.*
