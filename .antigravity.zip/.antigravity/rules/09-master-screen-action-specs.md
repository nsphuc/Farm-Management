# ĐẶC TẢ CHI TIẾT MÀN HÌNH, FORM, DROPDOWN & NÚT BẤM AGRI-ERP
## (MASTER SCREEN ACTION SPECS, DROPDOWN FILTERS & BUTTON SECURITY MATRIX)

> **Mã văn kiện:** `SPEC-UI-SCREEN-009`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Là Bản Vẽ Thi Công Giao Diện Chi Tiết Dành Cho Frontend Engineers.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Tôn chỉ:** *"Không dropdown rỗng (Context-Aware Dropdown) - Trường tính toán luôn Read-only - Nút bấm kiểm soát 2 tầng (Status Condition + `<Can>` RBAC Guard)"*.

---

## 1. MA TRẬN QUY TẮC LỌC DROPDOWN KHÓA NGOẠI (FOREIGN KEY FILTERING RULES)

Một lỗi nguy hiểm thường gặp trên giao diện là Dropdown khóa ngoại hiển thị toàn bộ dữ liệu mà không lọc theo ngữ cảnh, dẫn đến việc chọn sai Farm| STT | Tên Ô Chọn (Dropdown Field) | Thuộc Form / Màn Hình | Bảng Dữ Liệu Nguồn | Điều Kiện Lọc SQL Bắt Buộc (Filtering Query) | Hành Vi Phụ Thuộc (Cascading / Trigger) |
| :---: | :--- | :--- | :--- | :--- | :--- |
| **1** | **Trang trại** (`farm_id`) | Header Shell / Tạo mới | `farms` (#11) | `tenant_id = :tenantId AND (:isFarmOwner = TRUE OR id IN (:accessibleFarmIds)) AND status = 'ACTIVE'` | Khi đổi: Reset toàn bộ Zone, Kho, Vụ mùa đang chọn |
| **2** | **Phân khu** (`zone_id`) | Form Vụ mùa / Đàn nuôi | `production_zones` (#13) | `tenant_id = :tenantId AND farm_id = :currentFarmId AND status = 'ACTIVE'` | Chỉ nạp các Zone thuộc Farm đang làm việc |
| **3** | **Vị trí / Lô đất** (`zone_locations.id`) | Form Gieo trồng / Chuồng | `zone_locations` (#14) | `zone_id = :selectedZoneId AND status IN ('ACTIVE', 'EMPTY')` | Disabled khi chưa chọn Zone. Chỉ hiện lô/chuồng còn trống |
| **4** | **Kho Lưu Trữ Vật Tư** (`warehouse_id`) | Form Nhập kho / Xuất kho | `warehouses` (#26) | `farm_id = :currentFarmId AND warehouse_type IN ('FERTILIZER', 'PESTICIDE', 'ANIMAL_FEED', 'TOOLS_EQUIPMENT', 'GENERAL') AND status = 'ACTIVE'` | Chặn chọn kho lạnh / kho thành phẩm nông sản |
| **5** | **Kho Chứa Thành Phẩm** (`warehouse_id`) | Form Lô Thành Phẩm (`product_batches`) | `warehouses` (#26) | `farm_id = :currentFarmId AND warehouse_type IN ('HARVESTED_PRODUCE', 'COLD_STORAGE') AND status = 'ACTIVE'` | Chỉ cho phép chọn kho bảo quản nông sản hoặc kho lạnh |
| **6** | **Nhà Cung Cấp** (`partner_id`) | Phiếu Nhập Mua Hàng | `partners` (#4) | `tenant_id = :tenantId AND farm_id = :currentFarmId AND partner_type IN ('SUPPLIER', 'AGENT') AND status = 'ACTIVE'` | Tự động điền hạn mức nợ `payment_term_days` (The Farm Barrier Guard) |
| **7** | **Khách Hàng Thu Mua B2B** (`partner_id`) | Đơn Bán Sỉ (`sales_orders`) | `partners` (#4) | `tenant_id = :tenantId AND farm_id = :currentFarmId AND partner_type IN ('BUYER', 'AGENT') AND status = 'ACTIVE'` | Hiển thị cảnh báo nếu khách bị `credit_rating = 'C'` hoặc quá hạn nợ |
| **8** | **Đơn Vị Vận Chuyển** (`logistics_partner_id`) | Phiếu Giao Hàng (`sales_deliveries`) | `partners` (#4) | `tenant_id = :tenantId AND (farm_id = :currentFarmId OR farm_id IS NULL) AND partner_type = 'LOGISTICS' AND status = 'ACTIVE'` | Cho phép để trống nếu tự vận chuyển nội bộ |
| **9** | **Giống Cây Trồng** (`crop_type_id`) | Kế Hoạch Vụ Mùa | `crop_types` (#18) | `tenant_id = :tenantId` | Tự động điền ngày sinh trưởng chuẩn `growth_days_standard` |
| **10** | **Giống Vật Nuôi** (`breed_id`) | Nhập Đàn Mới (`livestock_groups`) | `livestock_breeds` (#21) | `tenant_id = :tenantId AND species = :selectedSpecies` | Lọc theo Loài (Heo, Bò, Gà) đã chọn ở thanh gạt trên cùng |
| **11** | **Vật Tư Nông Nghiệp** (`material_id`) | Dòng Chi Tiết Nhập / Xuất | `materials` (#28) | `tenant_id = :tenantId AND status = 'ACTIVE'` (lọc theo `category_id` nếu có) | Tự động nạp đơn vị chuẩn `standard_unit`, gợi ý `default_phi_days` |
| **12** | **Đơn Vị Nhập / Xuất** (`entered_unit`) | Dòng Chi Tiết Vật Tư | `material_unit_conversions` (#29) | `material_id = :selectedMaterialId` (Hợp nhất với `materials.standard_unit`) | Khi chọn: Tự động nhân `conversion_factor` tương ứng |
| **13** | **Số Lô Xuất Kho** (`batch_number`) | Xuất Kho / Ghi Nhật Ký | `warehouse_inventory` (#31) | `warehouse_id = :selectedWhId AND material_id = :selectedMatId AND (quantity_on_hand - reserved_quantity) > 0` | Sắp xếp theo hạn dùng `expiry_date ASC` (FEFO). Ẩn lô hết hàng |
| **14** | **Lô Thành Phẩm Xuất Bán** (`product_batch_id`) | Chi Tiết Giao Hàng | `product_batches` (#44) | `farm_id = :currentFarmId AND status = 'SELLING' AND (remaining_quantity - reserved_quantity) > 0` | Chặn tuyệt đối lô đang `PENDING_APPROVAL`, `REJECTED`, `RECALLED` |
| **15** | **Nhân Viên Phân Công** (`assigned_to_employee_id`) | Giao Nhiệm Vụ (`farm_tasks`) / Mặt bằng | `employees` (#51) | `tenant_id = :tenantId AND (farm_id = :currentFarmId OR farm_id IS NULL) AND status = 'ACTIVE'` | Hỗ trợ gán vai trò gồm cả `'ACCOUNTANT'` tại trại |

---

## 2. ĐẶC TẢ TRƯỜNG DỮ LIỆU ĐA PHƯƠNG TIỆN, SCANNER, VIETQR & NÚT BẤM AN TOÀN

### 2.1. Ô Quét Mã Vạch Tự Động (Barcode Scanner Input)
*   **Vị trí:** Đầu bảng chi tiết Phiếu Nhập Kho, Phiếu Xuất Kho, và Drawer Tiêu Hao Canh Tác.
*   **Hành vi UI:**
    *   Ô input luôn sẵn sàng nhận tín hiệu từ máy quét Laser / Camera di động (`autoFocus`, lắng nghe sự kiện `KeyDown: Enter`).
    *   Khi nhận chuỗi mã: Tự động gọi API `GET /api/v1/farms/{farmId}/materials/lookup-barcode?code={code}`.
    *   *Trường hợp 1 (Khớp mã bao bì):* Tự động thêm 1 dòng vào bảng chi tiết, chọn đúng `material_id`, chọn `entered_unit`, áp dụng `conversion_factor`, và đưa con trỏ chuột vào ô `enteredQuantity`.
    *   *Trường hợp 2 (Khớp mã lô kho):* Tự động chọn đúng `warehouse_id`, `material_id`, điền `batch_number`, và hiển thị số lượng tồn khả dụng hiện có.
    *   *Âm thanh phản hồi (Audio Feedback):* Phát tiếng "Beep" chuẩn khi quét thành công; rung màn hình và báo lỗi đỏ nếu mã vạch không tồn tại trong hệ thống.

### 2.2. Ô Tải Lên Đa Phương Tiện & Chụp Ảnh Hiện Trường (Image & Media Upload)
*   Áp dụng quy chuẩn bảo mật MIME Type và Magic Bytes (Chỉ chấp nhận `.jpg`, `.png`, `.pdf`, tối đa 5MB):

| Trường Dữ Liệu | Form Áp Dụng | Hành Vi Giao Diện Người Dùng (UI Behavior) |
| :--- | :--- | :--- |
| **`check_in_photo_url`** | Chấm Công GPS (`time_attendances` #54) | **Bắt buộc mở trực tiếp Camera trước (Selfie)**. Chặn tải ảnh từ thư viện máy để chống gian lận chấm công hộ. Đóng dấu Watermark thời gian và tọa độ lên ảnh. |
| **`proof_of_delivery_url`**| Giao Hàng (`sales_deliveries` #64) | Mở Camera điện thoại chụp Biên bản giao nhận hàng hóa có chữ ký người mua. Hiển thị thumbnail xem trước, phóng to lightbox. |
| **`proof_image_url`** | Thanh Toán (`payment_transactions` #67)| Chụp ủy nhiệm chi hoặc màn hình chuyển khoản ngân hàng của khách hàng. |
| **`logo_url`** | Hồ Sơ Pháp Nhân (`enterprises` #3) | Tải logo vuông công ty (1:1), tự động crop ảnh, hiển thị trên nhãn tem QR. |

### 2.3. Hiển Thị Mã Thanh Toán VietQR Tự Động (Dynamic VietQR Generator)
*   **Vị trí:** Màn hình Chi tiết Đơn Bán Sỉ (`sales_orders` #62) và Hóa đơn công nợ.
*   **Công thức sinh chuỗi VietQR chuẩn NAPAS 24/7:**
    *   Lấy thông tin thụ hưởng từ bảng `enterprises` (#3): Mã ngân hàng `bank_bin`, số tài khoản `bank_account_no`, tên tài khoản `bank_account_name`.
    *   Số tiền thanh toán: Lấy số nợ còn lại `sales_orders.debt_amount`.
    *   Nội dung chuyển khoản chuẩn: `SO {order_code}` (Ví dụ: `SO SO-2610-0002`).
    *   URL tạo mã QR động:
        `https://img.vietqr.io/image/{bank_bin}-{bank_account_no}-compact.png?amount={debt_amount}&addInfo=SO%20{order_code}&accountName={bank_account_name}`
*   Khách hàng chỉ cần mở App ngân hàng quét mã, toàn bộ số tiền và nội dung chuyển khoản được điền chính xác 100%, chống nhầm lẫn dòng tiền.

### 2.4. Quy Chuẩn Kỹ Thuật Component `Button.jsx` An Toàn Tuyệt Đối
Nhằm chống lỗi trắng màn hình (White Screen of Death) và ngăn ngừa lỗi Double-Submit giao dịch tài chính/kho:
1.  **Hàm bọc `renderSafeIcon(icon, className)`:**
    *   Kiểm tra an toàn kiểu dữ liệu của `icon`:
        *   Nếu là Lucide React Component (`typeof icon === 'function'` hoặc component object): Render `<IconComponent className={className} />`.
        *   Nếu là React Element đã được khởi tạo (`isValidElement(icon)`): Clone element kèm merge class.
        *   Nếu là chuỗi hoặc `null`/`undefined`: Bỏ qua an toàn, không ném exception gây crash ứng dụng.
2.  **Cơ chế Chống Double-Submit (`isLoading`):**
    *   Khi truyền `isLoading={true}`: Nút bấm tự động gán thuộc tính `disabled={true}`, con trỏ chuột đổi thành `cursor-not-allowed`, độ mờ `opacity-75`.
    *   Tự động chèn `<Loader2 className="animate-spin w-4 h-4 mr-2" />` thay thế hoặc đứng trước icon gốc.
    *   Ngăn chặn hoàn toàn việc người dùng click nhiều lần liên tiếp khi API backend đang xử lý.

### 2.5. Quy Chuẩn Ô Nhập Mã Định Danh Tự Sinh (Auto-Code Pattern)
Áp dụng cho mọi ô mã định danh nghiệp vụ (`code`, `skuCode`, `employeeCode`, `receiptCode`, `issueCode`, `batchCode`, `orderCode`, `transCode`...):
1.  **Khi Thêm Mới (Create Mode):**
    *   Hệ thống tự động sinh mã theo quy chuẩn:
        $$\text{[TIỀN\_TỐ] - YYMM - XXXX}$$
        *(Ví dụ: `EMP-2610-0001`, `RCP-2610-0003`, `ISS-2610-0002`, `SO-2610-0007`)*.
    *   Ô Input đi kèm nút phụ `[🔄 Tự sinh]` cho phép người dùng click để sinh mã mới nhất từ máy chủ hoặc nhập mã thủ công hợp lệ.
2.  **Khi Chỉnh Sửa (Edit / Update Mode):**
    *   **BẮT BUỘC KHÓA CỨNG `readOnly={true}`**:
        Thuộc tính `readOnly={true}`, thêm class giao diện `bg-slate-100 text-slate-500 cursor-not-allowed border-slate-200`. Ẩn hoặc vô hiệu hóa nút `[🔄 Tự sinh]`. Tuyệt đối không cho phép sửa đổi mã định danh đã lưu trong cơ sở dữ liệu.

---

## 3. MA TRẬN NÚT BẤM NGHIỆP VỤ & BẢO VỆ BỞI `<Can>` GUARD

Mọi nút bấm thay đổi trạng thái hoặc tác động dữ liệu nhạy cảm trên giao diện đều phải thỏa mãn đồng thời:
1.  **Quyền hạn người dùng:** Được bao bọc bởi thẻ `<Can permission="PERM_..." />` và thỏa mãn cấp bậc (Maker vs Checker vs Owner).
2.  **Điều kiện trạng thái thực thể:** Nút bấm tự động ẨN hoặc VÔ HIỆU HÓA (Disabled) nếu bản ghi không ở trạng thái hợp lệ.

| Tên Nút Bấm | Vị Trí Màn Hình | Thẻ Phân Quyền `<Can>` | Vai Trò Cho Phép | Điều Kiện Trạng Thái Bản Ghi Được Bấm | Endpoint API Kích Hoạt |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **`[ Tạo Phiếu Nhập Kho ]`** | Danh sách Phiếu Nhập Kho | `<Can permission="PERM_INVENTORY_RECEIPT" role="ROLE_WAREHOUSE_STAFF">` | `ROLE_WAREHOUSE_STAFF` (Maker) | Luôn sẵn sàng | `POST /api/v1/farms/{fId}/inventory/receipts` |
| **`[ Phê Duyệt Nhập Kho ]`** | Chi tiết Phiếu Nhập Kho | `<Can permission="PERM_INVENTORY_RECEIPT" role="ROLE_FARM_MANAGER">` | `ROLE_FARM_MANAGER` (Checker) | `receipt.status == 'DRAFT'` | `POST /api/v1/farms/{fId}/inventory/receipts/{id}/approve` |
| **`[ Hoàn Tất Nhập Kho ]`** | Chi tiết Phiếu Nhập Kho | `<Can permission="PERM_INVENTORY_RECEIPT" role="ROLE_FARM_MANAGER">` | `ROLE_FARM_MANAGER` (Checker) | `receipt.status == 'APPROVED'` | `POST /api/v1/farms/{fId}/inventory/receipts/{id}/complete` |
| **`[ Hủy Phiếu Nhập ]`** | Chi tiết Phiếu Nhập Kho | `<Can permission="PERM_INVENTORY_RECEIPT" role="ROLE_FARM_MANAGER">` | `ROLE_FARM_MANAGER` (Checker) | `receipt.status IN ('DRAFT', 'APPROVED')` | `POST /api/v1/farms/{fId}/inventory/receipts/{id}/cancel` |
| **`[ Tạo Phiếu Xuất Kho ]`** | Danh sách Phiếu Xuất Kho | `<Can permission="PERM_INVENTORY_ISSUE" role="ROLE_WAREHOUSE_STAFF">` | `ROLE_WAREHOUSE_STAFF` (Maker) | Luôn sẵn sàng | `POST /api/v1/farms/{fId}/inventory/issues` |
| **`[ Phê Duyệt Xuất Kho ]`** | Chi tiết Phiếu Xuất Kho | `<Can permission="PERM_INVENTORY_ISSUE" role="ROLE_FARM_MANAGER">` | `ROLE_FARM_MANAGER` (Checker) | `issue.status == 'DRAFT'` | `POST /api/v1/farms/{fId}/inventory/issues/{id}/approve` |
| **`[ Tạo Đợt Kiểm Kê ]`** | Danh sách Đợt Kiểm Kê | `<Can permission="PERM_INVENTORY_STOCKTAKE" role="ROLE_WAREHOUSE_STAFF">`| `ROLE_WAREHOUSE_STAFF` (Maker) | Luôn sẵn sàng | `POST /api/v1/farms/{fId}/inventory/stocktakes` |
| **`[ Phê Duyệt Kiểm Kê ]`** | Chi tiết Đợt Kiểm Kê | `<Can permission="PERM_INVENTORY_STOCKTAKE" role="ROLE_FARM_MANAGER">`| `ROLE_FARM_MANAGER` (Checker) | `stocktake.status == 'IN_PROGRESS'` | `POST /api/v1/farms/{fId}/inventory/stocktakes/{id}/approve` |
| **`[ Lập Biên Bản KCS ]`** | Chi tiết Lô Thành Phẩm | `<Can permission="PERM_QC_INSPECT" role="ROLE_TECHNICAL_STAFF">` | `ROLE_TECHNICAL_STAFF` (Maker) | `batch.status == 'HARVESTED'` | `POST /api/v1/farms/{fId}/qc-inspections` |
| **`[ Phê Duyệt KCS Lô ]`** | Chi tiết Lô Thành Phẩm | `<Can permission="PERM_QC_APPROVE" role={["ROLE_FARM_MANAGER", "ROLE_FARM_OWNER"]}>` | `ROLE_FARM_MANAGER`, `ROLE_FARM_OWNER` (Checker) | `batch.status == 'PENDING_APPROVAL'` & **`inspectorUserId != currentUserId`** | `POST /api/v1/farms/{fId}/product-batches/{id}/approve` |
| **`[ Từ Chối Lô KCS ]`** | Chi tiết Lô Thành Phẩm | `<Can permission="PERM_QC_APPROVE" role={["ROLE_FARM_MANAGER", "ROLE_FARM_OWNER"]}>` | `ROLE_FARM_MANAGER`, `ROLE_FARM_OWNER` (Checker) | `batch.status == 'PENDING_APPROVAL'` | `POST /api/v1/farms/{fId}/product-batches/{id}/reject` |
| **`[ Lệnh Thu Hồi Khẩn Cấp ]`**| Chi tiết Lô Thành Phẩm | `<Can permission="PERM_QC_RECALL" role={["ROLE_FARM_MANAGER", "ROLE_FARM_OWNER"]}>` | `ROLE_FARM_MANAGER`, `ROLE_FARM_OWNER` (Checker) | `batch.status IN ('READY_TO_PRINT', 'PRINTED', 'SELLING')` | `POST /api/v1/farms/{fId}/product-batches/{id}/recall` |
| **`[ In Tem Nhãn QR ]`** | Chi tiết Lô Thành Phẩm | `<Can permission="PERM_LABEL_PRINT" role="ROLE_WAREHOUSE_STAFF">` | `ROLE_WAREHOUSE_STAFF` (Độc quyền) | `batch.status IN ('READY_TO_PRINT', 'PRINTED', 'SELLING')` | Mở Modal in nhiệt ESC/POS (50x50 hoặc 35x22) |
| **`[ Xuất Giao Hàng ]`** | Phiếu Giao Hàng | `<Can permission="PERM_DELIVERY_MANAGE" role="ROLE_WAREHOUSE_STAFF">` | `ROLE_WAREHOUSE_STAFF` (Maker) | `delivery.status == 'DRAFT'` | `POST /api/v1/farms/{fId}/sales-deliveries/{id}/dispatch` |
| **`[ Lập Phiếu Chi ]`** | Danh sách Phiếu Chi | `<Can permission="PERM_FINANCE_EXPENSE" role="ROLE_ACCOUNTANT">` | `ROLE_ACCOUNTANT` (Maker) | Luôn sẵn sàng | `POST /api/v1/farms/{fId}/expenses` |
| **`[ Phê Duyệt Phiếu Chi ]`**| Chi tiết Phiếu Chi | `<Can permission="PERM_FINANCE_EXPENSE" role="ROLE_FARM_MANAGER">` | `ROLE_FARM_MANAGER` (Checker) | `expense.status == 'DRAFT'` | `POST /api/v1/farms/{fId}/expenses/{id}/approve` |
| **`[ Lên Đơn Bán Sỉ ]`** | Danh sách Đơn Bán Sỉ | `<Can permission="PERM_FINANCE_SALES_ORDER" role="ROLE_ACCOUNTANT">`| `ROLE_ACCOUNTANT` (Maker) | Luôn sẵn sàng | `POST /api/v1/farms/{fId}/sales-orders` |
| **`[ Phê Duyệt Đơn Bán ]`** | Chi tiết Đơn Bán Sỉ | `<Can permission="PERM_FINANCE_SALES_ORDER" role="ROLE_FARM_MANAGER">`| `ROLE_FARM_MANAGER` (Checker) | `order.status == 'PENDING'` | `POST /api/v1/farms/{fId}/sales-orders/{id}/confirm` |
| **`[ Lập Phiếu Thu / Chi ]`**| Danh sách Thanh Toán | `<Can permission="PERM_FINANCE_PAYMENT" role="ROLE_ACCOUNTANT">` | `ROLE_ACCOUNTANT` (Maker) | Luôn sẵn sàng | `POST /api/v1/farms/{fId}/payments` |
| **`[ Xác Nhận Thanh Toán ]`**| Sổ Quỹ / Công Nợ | `<Can permission="PERM_FINANCE_PAYMENT" role="ROLE_FARM_MANAGER">` | `ROLE_FARM_MANAGER` (Checker) | `payment.status == 'PENDING'` | `POST /api/v1/farms/{fId}/payments/{id}/confirm` |
| **`[ Cấn Trừ Công Nợ ]`** | Chi Tiết Khoản Nợ | `<Can permission="PERM_PAYMENT_ALLOCATE" role="ROLE_ACCOUNTANT">` | `ROLE_ACCOUNTANT` | `debt.status IN ('ACTIVE', 'OVERDUE')` | `POST /api/v1/farms/{fId}/payments/{id}/allocate` |
| **`[ Duyệt Hạn Mức Tín Dụng ]`**| Drawer Đối Tác | `<Can permission="PERM_FINANCE_SALES_ORDER" role="ROLE_FARM_OWNER">`| **`ROLE_FARM_OWNER` (Độc quyền)** | `partner.status == 'ACTIVE'` | `PUT /api/v1/partners/{id}/credit-limit` |
| **`[ Khóa Đen Đối Tác ]`** | Drawer Đối Tác | `<Can permission="PERM_FINANCE_SALES_ORDER" role="ROLE_FARM_OWNER">`| **`ROLE_FARM_OWNER` (Độc quyền)** | `partner.status != 'BLACKLISTED'` | `PUT /api/v1/partners/{id}/blacklist` |
| **`[ Duyệt Ngân Sách ]`** | Tab Ngân Sách WS-H1 | `<Can permission="PERM_FINANCE_REPORT" role="ROLE_FARM_OWNER">` | **`ROLE_FARM_OWNER` (Độc quyền)** | `budget.status == 'SUBMITTED'` | `POST /api/v1/farms/{fId}/budgets/{id}/approve` |
| **`[ Ký Duyệt Kết Toán Chu Kỳ ]`**| Tab Kết Toán WS-H2 | `<Can permission="PERM_FINANCE_REPORT" role="ROLE_FARM_MANAGER">` | `ROLE_FARM_MANAGER` (Checker) | `cycleSettlement.status == 'DRAFT'` | `POST /api/v1/farms/{fId}/cycles/{id}/settlement/sign` |
| **`[ Xác Nhận Kết Toán Chu Kỳ ]`**| Tab Kết Toán WS-H2 | `<Can permission="PERM_FINANCE_REPORT" role="ROLE_FARM_OWNER">` | **`ROLE_FARM_OWNER` (Độc quyền)** | `cycleSettlement.status == 'REVIEWED'` | `POST /api/v1/farms/{fId}/cycles/{id}/settlement/confirm` |
| **`[ Cấp Tài Khoản ]`** | Drawer Nhân Sự WS-B | `<Can permission="PERM_HR_EMPLOYEE_MANAGE" role={["ROLE_FARM_OWNER", "ROLE_FARM_MANAGER"]}>`| Owner (tuyển Cấp 3), FM (tuyển Cấp 4) | `employee.userId == null` (Chỉ Nhóm 6A) | `POST /api/v1/hr/employees/{id}/provision-account` |
| **`[ Điểm Danh Tổ (Batch) ]`** | Cổng Điểm Danh WS-G | `<Can permission="PERM_HR_ATTENDANCE" role={["ROLE_FARM_MANAGER", "ROLE_TECHNICAL_STAFF"]} farmRole={["FARM_MANAGER", "ZONE_MANAGER", "TECHNICAL_LEAD"]}>` | Tech Lead, Farm Manager, Trưởng khu | Hàng ngày đầu ca / tan ca (Dành riêng Nhóm 6B) | `POST /api/v1/hr/attendance/batch-roll-call` |
| **`[ Khởi Tạo Mùa Vụ ]`** | Bàn Làm Việc Canh Tác | `<Can permission="PERM_CROP_PLAN" role="ROLE_TECHNICAL_STAFF">` | `ROLE_TECHNICAL_STAFF` (Maker) | `season == null` hoặc lên lịch mới | `POST /api/v1/farms/{fId}/crop-seasons` |
| **`[ Duyệt / Đóng Mùa Vụ ]`** | Bàn Làm Việc Canh Tác | `<Can permission="PERM_CROP_PLAN" role="ROLE_FARM_MANAGER">` | `ROLE_FARM_MANAGER` (Checker) | `season.status IN ('PLANNING', 'HARVESTING')` | `POST /api/v1/farms/{fId}/crop-seasons/{id}/close` |

---

## 4. BẢN VẼ THI CÔNG CHI TIẾT 10 MÀN HÌNH VI MÔ TOÀN DIỆN (4.1 ĐẾN 4.10)

### 4.1. Màn Hình 1: Trung Tâm Giao Dịch Kho (`/app/inventory/receipts`)
*   **Bảng Dữ Liệu (`Table`):**
    *   *Cột hiển thị:* Mã phiếu `receipt_code`, Ngày nhập `receipt_date`, Kho nhận `warehouseName`, Nhà cung cấp `partnerName`, Loại phiếu `receipt_type` (Badge), Tổng tiền `total_amount` (Format VNĐ), Trạng thái `status` (Badge màu), Người duyệt `approverFullName`.
    *   *Bộ lọc phía trên:* Search mã phiếu/nhà cung cấp, Dropdown lọc theo Kho `warehouse_id`, Dropdown lọc loại nhập `receipt_type`, DateRangePicker lọc theo ngày nhập, Segment Filter theo `status` (`Tất cả`, `DRAFT`, `COMPLETED`, `CANCELLED`).
*   **Form Nhập Kho (`ReceiptFormModal`):**
    *   *Ô tự động tính (Read-only):* Tổng tiền phiếu `total_amount` (Tự động cộng `total_price` của các dòng).
    *   *Bảng dòng chi tiết:* Cột Số lượng chuẩn `quantity` là **Read-only**, tự động tính theo công thức:
        $$\text{quantity} = \text{enteredQuantity} \times \text{conversionFactor}$$

### 4.2. Màn Hình 2: Quản Lý Lô Thành Phẩm & QA (`/app/qa/batches`)
*   **Bảng Kanban 6 Cột (Tương ứng 6 Trạng thái của `product_batches`):**
    1.  `PENDING_APPROVAL`: Cột màu Vàng cam (Chờ KCS kiểm định).
    2.  `READY_TO_PRINT`: Cột màu Xanh ngọc (Đã đạt chuẩn KCS, đã cấp mã UUID, chờ in tem).
    3.  `PRINTED`: Cột màu Xanh dương (Đã in tem QR dán lên sản phẩm).
    4.  `SELLING`: Cột màu Xanh lá cây (Đang mở bán trong đơn sỉ).
    5.  `REJECTED`: Cột màu Xám tro (Bị KCS đánh trượt).
    6.  `RECALLED`: Cột màu Đỏ thẫm (Có lệnh thu hồi khẩn cấp).
*   **Card Lô Thành Phẩm trên Kanban:**
    *   Hiển thị: Mã lô `batch_code`, Tên sản phẩm `product_name`, Cấp chất lượng `quality_grade`, Ngày thu hoạch `harvest_date`, Hạn sử dụng `expiry_date`.
    *   Thanh tiến độ tồn kho: Tồn thực tế `remaining_quantity` / Ban đầu `initial_quantity`, Số lượng đã giữ chỗ `reserved_quantity`.

### 4.3. Màn Hình 3: Đơn Hàng Bán Sỉ, Giữ Chỗ Lô & Thu Phí VietQR (`/app/commercial/sales`)
*   **Bảng Dữ Liệu Đơn Bán Sỉ (`Table`):**
    *   *Cột hiển thị:* Mã đơn `order_code`, Ngày đặt `order_date`, Khách hàng `partnerName`, Hạn thanh toán `payment_term_days` (kèm ngày đến hạn `due_date`), Tổng thanh toán `final_amount` (VNĐ), Đã trả `paid_amount`, Tiền nợ `debt_amount`, Trạng thái giao hàng `delivery_status` (Badge: `PENDING`, `PARTIAL`, `DELIVERED`), Trạng thái thanh toán `payment_status` (Badge: `UNPAID`, `PARTIAL`, `PAID`), Trạng thái đơn `status` (Badge: `PENDING`, `CONFIRMED`, `DELIVERED`, `COMPLETED`, `CANCELLED`).
    *   *Bộ lọc phía trên:* Search mã đơn/tên khách, Dropdown lọc khách hàng `partner_id`, Segment Filter trạng thái `status`, DateRangePicker ngày tạo đơn.
*   **Form Tạo Đơn Bán Sỉ (`SalesOrderFormModal`):**
    *   *Thông tin chung:* Chọn đối tác mua hàng `partner_id` (chỉ nạp đối tác `BUYER` hoặc `AGENT` đang `ACTIVE`). Hệ thống tự động hiển thị Hạn mức tín dụng `credit_limit`, Số dư nợ hiện tại và Xếp hạng tín dụng.
    *   *Bảng chọn lô hàng bán sỉ (`sales_order_items`):*
        *   Chọn Lô thành phẩm `product_batch_id` (chỉ nạp các lô đang `SELLING` và còn tồn khả dụng: $\text{remaining\_quantity} - \text{reserved\_quantity} > 0$).
        *   Nhập số lượng đặt `quantity` ($0 < \text{quantity} \le \text{khả dụng}$).
        *   Nhập đơn giá bán `unit_price` ($> 0$). Thành tiền tự tính: $\text{total\_price} = \text{quantity} \times \text{unit\_price}$.
    *   *Ô nhập số có biên độ:* Tỷ lệ chiết khấu `discount_amount` ($0 \le \text{discount} \le \text{subtotal}$), Tỷ lệ VAT `vat_rate` ($0.0 \le vat\_rate \le 100.0\%$).
    *   *Các ô tự động tính (Read-only):*
        *   Tiền hàng trước thuế: $\text{subtotal\_amount} = \sum (\text{items.quantity} \times \text{items.unitPrice})$
        *   Tiền thuế: $\text{vat\_amount} = (\text{subtotal\_amount} - \text{discount\_amount}) \times \frac{\text{vat\_rate}}{100}$
        *   Tổng thanh toán: $\text{final\_amount} = \text{subtotal\_amount} - \text{discount\_amount} + \text{vat\_amount}$
        *   Tiền nợ còn lại: $\text{debt\_amount} = \text{final\_amount} - \text{paid\_amount}$
*   **Đặc tả các nút bấm & hành động nghiệp vụ:**
    1.  **Nút `[ + Tạo Mới Đơn Hàng ]`:**
        *   *(1) Điều kiện xuất hiện:* Luôn hiển thị tại thanh công cụ màn hình Đơn hàng.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FINANCE_SALES_ORDER">`.
        *   *(3) Trạng thái cho phép thao tác:* Luôn khả dụng.
        *   *(4) Ràng buộc tín dụng (Credit Limit Guard):* Nếu tổng nợ hiện tại của khách hàng cộng thêm `final_amount` của đơn hàng mới vượt quá `partners.credit_limit`, hệ thống hiển thị cảnh báo đỏ và chặn tạo đơn (trừ khi có tài khoản `ROLE_FARM_OWNER` phê duyệt ngoại lệ).
        *   *(5) Kết quả khi thành công:* Lưu đơn hàng ở trạng thái `PENDING` (mặc định), chưa trừ kho hay giữ chỗ lô hàng. Toast xanh *"Tạo đơn bán sỉ thành công!"*.
        *   *(6) Hành vi khi thất bại:* Báo lỗi chi tiết vi phạm hạn mức nợ hoặc lỗi số lượng.
    2.  **Nút `[ Phê Duyệt Đơn & Giữ Chỗ Lô Hàng (Reserve Stock) ]`:**
        *   *(1) Điều kiện xuất hiện:* Trên màn hình chi tiết đơn hàng đang ở trạng thái `sales_orders.status == 'PENDING'`.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FINANCE_SALES_ORDER">`.
        *   *(3) Trạng thái cho phép thao tác:* Đơn đang `PENDING`.
        *   *(4) Ràng buộc giữ chỗ tồn kho:* Hệ thống kiểm tra lại số lượng khả dụng của từng lô hàng trong đơn:
            $$\text{available\_quantity} = \text{product\_batches.remaining\_quantity} - \text{product\_batches.reserved\_quantity}$$
            Nếu $\text{items.quantity} \le \text{available\_quantity}$ trên 100% các dòng, thực hiện giao dịch:
            $$\text{reserved\_quantity} = \text{reserved\_quantity} + \text{items.quantity}$$
        *   *(5) Kết quả khi thành công:* Chuyển trạng thái đơn sang `CONFIRMED`, khóa số lượng giữ chỗ không cho các đơn khác mua trùng, sinh bản ghi công nợ dự kiến trong `debt_records` (#66) loại `RECEIVABLE`. Toast xanh *"Đã duyệt đơn và giữ chỗ lô hàng!"*.
        *   *(6) Hành vi khi thất bại:* Toast đỏ cảnh báo *"Lô hàng [Mã lô] không còn đủ số lượng khả dụng để giữ chỗ!"*.
    3.  **Nút `[ + Lập Phiếu Giao Hàng (Dispatch Delivery) ]`:**
        *   *(1) Điều kiện xuất hiện:* Đơn hàng có trạng thái `sales_orders.status == 'CONFIRMED'` và `delivery_status != 'DELIVERED'`.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_DELIVERY_MANAGE">`.
        *   *(3) Form & Validation (`SalesDeliveryModal`):* `delivery_code` (Unique), `delivery_date` (LocalDate), `logistics_partner_id` (Dropdown lọc từ `partners` loại `LOGISTICS`), `driver_name`, `vehicle_plate`, Bảng chi tiết xuất hàng: Chọn số lượng xuất giao đợt này cho từng dòng ($\text{delivered\_quantity} \le \text{ordered\_quantity} - \text{shipped\_quantity}$).
        *   *(4) Giao dịch kho & Giữ chỗ khi giao hàng:*
            *   Trừ tồn thực tế: $\text{remaining\_quantity} = \text{remaining\_quantity} - \text{delivered\_quantity}$
            *   Giải phóng giữ chỗ: $\text{reserved\_quantity} = \text{reserved\_quantity} - \text{delivered\_quantity}$
            *   Cộng dồn giao hàng: $\text{shipped\_quantity} = \text{shipped\_quantity} + \text{delivered\_quantity}$
            *   Ghi nhật ký giao dịch xuất kho thành phẩm vào bảng `product_batch_transactions` (#48).
        *   *(5) Kết quả khi thành công:* Tạo bản ghi `sales_deliveries` (#64) và `sales_delivery_items` (#65). Cập nhật `sales_orders.delivery_status` thành `PARTIAL` hoặc `DELIVERED`. Toast xanh thông báo *"Đã xuất kho giao hàng đợt mới!"*.
        *   *(6) Hành vi khi thất bại:* Báo lỗi nếu số lượng giao vượt quá số lượng còn lại của đơn hàng.
    4.  **Nút `[ 📱 Lấy Mã VietQR Thanh Toán ]`:**
        *   *(1) Điều kiện xuất hiện:* Trên màn hình chi tiết đơn hàng có số dư nợ `debt_amount > 0`.
        *   *(2) Quyền bảo vệ:* Mọi vai trò có quyền xem đơn hàng (`PERM_FINANCE_SALES_ORDER` hoặc `ROLE_ACCOUNTANT`, `ROLE_FARM_OWNER`).
        *   *(3) Hành vi UI:* Mở Modal hiển thị mã VietQR động chuẩn NAPAS 24/7 (sinh từ ngân hàng `enterprises.bank_bin`, số tài khoản `bank_account_no`, số tiền `debt_amount`, cú pháp `SO {order_code}`). Kèm nút `[ Tải Ảnh Mã QR ]` và nút `[ Sao Chép Nội Dung Chuyển Khoản ]`.
    5.  **Nút `[ Hủy Đơn Bán Sỉ ]`:**
        *   *(1) Điều kiện xuất hiện:* Đơn hàng ở trạng thái `PENDING` hoặc `CONFIRMED` nhưng chưa xuất giao bất kỳ đợt hàng nào (`shipped_quantity == 0`).
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FINANCE_SALES_ORDER">`.
        *   *(3) Cơ chế giải phóng giữ chỗ:* Nếu đơn đang `CONFIRMED`, hệ thống tự động hoàn trả số lượng đã giữ chỗ về kho:
            $$\text{reserved\_quantity} = \text{reserved\_quantity} - \text{items.quantity}$$
            và hủy bản ghi công nợ tương ứng trong `debt_records`.
        *   *(4) Kết quả khi thành công:* Trạng thái đơn chuyển sang `CANCELLED`. Toast xanh *"Đã hủy đơn hàng và giải phóng tồn kho giữ chỗ!"*.

---

### 4.4. Màn Hình 4: Workspace A - Quản Trị Mặt Bằng, Cây Địa Lý 3 Tầng & Phân Công Hiện Trường (`/app/geography`)
*   **Cấu trúc giao diện:**
    *   *Cây phân cấp 3 tầng (Hierarchy Tree View):* Cấp 1 Trang trại (`farms` #11) $\rightarrow$ Cấp 2 Phân khu sản xuất (`production_zones` #13) $\rightarrow$ Cấp 3 Vị trí / Lô đất / Chuồng trại (`zone_locations` #14).
    *   *Bản đồ địa giới tương tác (GIS / Leaflet Map):* Hiển thị tâm trang trại bằng tọa độ GPS (`latitude`, `longitude`), vẽ vòng tròn ranh giới Geofence bán kính `geofence_radius_m` (màu xanh lá bán trong suốt), hiển thị polygon các phân khu và vị trí các kho lưu trữ.
    *   *Bảng phân công nhân sự hiện trường (`farm_assignments` #15):* Danh sách người phụ trách từng phân khu/lô đất kèm chức danh và ngày bắt đầu.
*   **Đặc tả các nút bấm & hành động nghiệp vụ:**
    1.  **Nút `[ + Thêm Mới Trang Trại ]`:**
        *   *(1) Điều kiện xuất hiện:* Luôn hiển thị ở thanh công cụ góc phải phía trên của cây địa lý.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FARM_CREATE">`.
        *   *(3) Trạng thái cho phép thao tác:* Số lượng trang trại hiện tại của tenant phải nhỏ hơn giới hạn thuê bao: $\text{count}(\text{farms}) < \text{tenant\_subscriptions.max\_farms}$. Nếu đã đạt giới hạn, nút bị disabled kèm tooltip giải thích.
        *   *(4) Form & Validation (`FarmFormModal`):* `farm_code` (Bắt buộc, uppercase, unique, 3-20 ký tự), `farm_name` (Bắt buộc, 3-100 ký tự), `farm_type` (Enum: `CROP`, `LIVESTOCK`, `AQUACULTURE`, `MIXED`), `latitude` (Bắt buộc, -90 đến 90), `longitude` (Bắt buộc, -180 đến 180), `geofence_radius_m` (Bắt buộc, 10 đến 5000 mét), `total_area_m2` (Bắt buộc, $> 0$), `address`, `province`, `district`, `commune`.
        *   *(5) Kết quả khi thành công:* Toast xanh *"Khởi tạo trang trại thành công!"*, tự động chọn trang trại mới trên cây phân cấp, định vị bản đồ tới tọa độ vừa nhập và nạp danh sách phân khu rỗng.
        *   *(6) Hành vi khi thất bại:* Hiển thị inline error màu đỏ dưới ô bị lỗi (ví dụ: *"Mã trang trại đã tồn tại"* hoặc *"Tọa độ GPS không hợp lệ"*).
    2.  **Nút `[ Chỉnh Sửa Thông Số Trang Trại ]`:**
        *   *(1) Điều kiện xuất hiện:* Khi đang chọn một node Trang trại trên cây phân cấp.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FARM_UPDATE">`.
        *   *(3) Trạng thái cho phép thao tác:* `farms.status == 'ACTIVE'`.
        *   *(4) Form & Validation:* Cho phép sửa tên, diện tích, cập nhật lại tâm GPS và bán kính Geofence. Mã trang trại `farm_code` là Read-only.
        *   *(5) Kết quả khi thành công:* Toast xanh thông báo *"Cập nhật trang trại thành công!"*, vẽ lại vòng tròn Geofence trên bản đồ tương tác.
        *   *(6) Hành vi khi thất bại:* Toast đỏ hiển thị mã lỗi và giữ nguyên trạng thái form để người dùng sửa lại.
    3.  **Nút `[ + Thêm Phân Khu (Zone) ]`:**
        *   *(1) Điều kiện xuất hiện:* Đang chọn một trang trại trên cây.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_ZONE_MANAGE">`.
        *   *(3) Trạng thái cho phép thao tác:* Trang trại cha đang ở trạng thái `ACTIVE`.
        *   *(4) Form & Validation (`ZoneFormModal`):* `code` (Unique trong trang trại), `name`, `zone_type` (Enum: `'GREENHOUSE'`, `'OPEN_FIELD'`, `'BARN'`, `'POND'`, `'STORAGE'`, `'ISOLATION'`), `area_m2` (Bắt buộc $\ge 0$, không được vượt quá tổng diện tích trang trại), `map_layout_json` (Tùy chọn vẽ trực tiếp trên bản đồ).
        *   *(5) Kết quả khi thành công:* Toast xanh *"Đã thêm phân khu mới!"*, thêm 1 node con vào cây địa lý và vẽ vùng polygon lên bản đồ.
        *   *(6) Hành vi khi thất bại:* Inline error tại các trường không hợp lệ.
    4.  **Nút `[ + Thêm Vị Trí / Lô Đất / Chuồng (Location) ]`:**
        *   *(1) Điều kiện xuất hiện:* Đang chọn một phân khu trên cây.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_ZONE_MANAGE">`.
        *   *(3) Trạng thái cho phép thao tác:* Phân khu cha đang ở trạng thái `ACTIVE`.
        *   *(4) Form & Validation (`LocationFormModal`):* `code` (Unique trong Zone), `name`, `description`, `status` (Enum: `'ACTIVE'`, `'OCCUPIED'`, `'EMPTY'`, `'MAINTENANCE'`). Trạng thái khởi tạo tự động là `EMPTY`.
        *   *(5) Kết quả khi thành công:* Thêm node lá vào cây địa lý với Badge xám `EMPTY`.
        *   *(6) Hành vi khi thất bại:* Báo lỗi trùng mã vị trí.
    5.  **Nút `[ Phân Công Nhân Sự Quản Lý Hiện Trường ]`:**
        *   *(1) Điều kiện xuất hiện:* Tab Phân công nhân sự của Trang trại hoặc Phân khu.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_ZONE_MANAGE">`.
        *   *(3) Trạng thái cho phép thao tác:* Node địa lý đang `ACTIVE`.
        *   *(4) Form & Validation (`AssignmentModal`):* Dropdown chọn người dùng từ `users`/`employees` (chỉ nạp nhân sự `ACTIVE`), chọn vai trò nghiệp vụ `role_in_farm` gồm 8 giá trị chuẩn SQL (`'FARM_MANAGER'`, `'ZONE_MANAGER'`, `'TECHNICAL_LEAD'`, `'AGRONOMIST'`, `'VETERINARIAN'`, `'WAREHOUSE_KEEPER'`, `'ACCOUNTANT'`, `'FIELD_WORKER'`), ngày bắt đầu hiệu lực `assigned_from` (mặc định hôm nay), ngày kết thúc `assigned_to` (tùy chọn, `assigned_to >= assigned_from`).
        *   *(5) Kết quả khi thành công:* Toast xanh *"Phân công thành công!"*, thêm dòng vào bảng phụ trách kèm avatar nhân viên.
        *   *(6) Hành vi khi thất bại:* Báo lỗi nếu nhân viên này đã được phân công cùng chức danh tại phân khu đó.

---

### 4.5. Màn Hình 5: Workspace B - Hồ Sơ Nhân Sự 360°, Cấp Tài Khoản SaaS & Tổng Hợp Công (`/app/hr`)
*   **Cấu trúc giao diện:**
    *   *Thanh chỉ số nhân sự (HR Metric Bar):* Tổng số nhân sự, Số nhân sự 6A (SaaS), Số lao động thời vụ 6B, Số nhân sự đang nghỉ phép hôm nay, Tổng số giờ làm việc trong tháng.
    *   *Bảng Danh bạ Nhân sự 360° (Tab 1):* Mã NV `employee_code`, Avatar, Họ tên `full_name`, Số CCCD `id_card_number`, Ngày sinh, Điện thoại, Email, Phân loại nhóm (Badge xanh 6A / Badge cam 6B), Trang trại trực thuộc `farmName`, Chức vụ `position`, Hợp đồng `contract_type`, Lương cơ bản `base_salary`, Lương giờ `hourly_rate`, Quỹ phép năm `annual_leave_quota`, Trạng thái (`ACTIVE`, `ON_LEAVE`, `RESIGNED`, `TERMINATED`), Cột Tài khoản SaaS (Badge xanh nếu đã có `user_id`, Badge xám *"Chưa cấp / Không áp dụng"*).
    *   *Lưới Phân Ca Tuần (Tab 2 - `shift_assignments` #53):* Bảng ma trận Nhân viên $\times$ 7 ngày trong tuần, hiển thị tên ca làm việc (`work_shifts` #52).
    *   *Bảng Tổng Hợp & Điều Chỉnh Công (Tab 3 - `time_attendances` #54):* Ngày làm việc, Giờ vào/ra, Ảnh selfie check-in/out thu nhỏ, Tọa độ GPS, Khoảng cách tới trại, Số phút trễ `late_minutes`, Số giờ làm `working_hours`, Cột trạng thái kiểm toán (Badge tím *"ĐÃ ĐIỀU CHỈNH"* nếu `is_adjusted = TRUE`).
    *   *Tab Duyệt Nghỉ Phép & Đăng Ký OT (Tab 4):* Danh sách đơn xin nghỉ (`leave_requests` #55) và đơn làm thêm giờ (`overtime_requests` #56).
*   **Đặc tả các nút bấm & hành động nghiệp vụ:**
    1.  **Nút `[ + Tiếp Nhận Nhân Viên Mới ]`:**
        *   *(1) Điều kiện xuất hiện:* Luôn hiển thị tại Tab Danh bạ nhân sự.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_HR_EMPLOYEE_MANAGE">` (Owner tuyển Cấp 3; Farm Manager tuyển Cấp 4 tại trại).
        *   *(3) Trạng thái cho phép thao tác:* Luôn khả dụng.
        *   *(4) Form & Validation (`EmployeeCreateModal`):*
            *   `employee_code`: Mã tự sinh `EMP-YYMM-XXXX` kèm nút `[🔄 Tự sinh]` khi tạo mới. Khóa cứng `readOnly={true}` khi chỉnh sửa.
            *   `full_name *`: Bắt buộc nhập họ tên đầy đủ.
            *   `date_of_birth`: Bắt buộc $\ge 18$ tuổi tính đến ngày nhập hồ sơ.
            *   `id_card_number *`: Bắt buộc, kiểm tra Regex 12 chữ số CCCD (`^[0-9]{12}$`).
            *   `phone *`: Bắt buộc, kiểm tra Regex 10 chữ số bắt đầu bằng đầu số VN (`^(03|05|07|08|09)[0-9]{8}$`).
            *   `email *`: Bắt buộc, kiểm tra Regex email chuẩn RFC 5322.
            *   `joined_date *`: Bắt buộc chọn ngày vào làm.
            *   `contract_type *`: Bắt buộc chọn (`'FULL_TIME'`, `'PART_TIME'`, `'SEASONAL'`, `'INTERN'`).
            *   `position *`: Bắt buộc chọn chức danh công việc.
            *   **BỎ HOÀN TOÀN Ô "Phòng Ban / Bộ Phận" (`department`):** Không có ô department trên Form. Backend Service tự suy diễn ngầm từ `position`.
            *   `labor_group *`: Chọn Nhóm 6A (Biên chế / Chuyên môn - mở tab Cấp tài khoản SaaS) hoặc Nhóm 6B (Lao động thời vụ - không tài khoản SaaS, tham gia điểm danh tổ tập thể bằng ảnh + GPS).
            *   `base_salary`, `hourly_rate`, `farm_id` (Bắt buộc theo trại phân công), `annual_leave_quota` (Mặc định 12, $\ge 0$).
        *   *(5) Kết quả khi thành công:* Toast xanh *"Tiếp nhận nhân sự thành công!"*, thêm nhân viên vào danh sách với trạng thái `ACTIVE`.
        *   *(6) Hành vi khi thất bại:* Inline error đỏ tại các ô vi phạm.
    2.  **Nút `[ Cấp Tài Khoản Đăng Nhập SaaS ]`:**
        *   *(1) Điều kiện xuất hiện:* Trên từng dòng nhân sự Nhóm 6A có `user_id IS NULL` và trạng thái `status == 'ACTIVE'`.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_HR_EMPLOYEE_MANAGE">`.
        *   *(3) Trạng thái cho phép thao tác:* Tổng số người dùng hoạt động hiện tại phải nhỏ hơn giới hạn thuê bao: $\text{count}(\text{users}) < \text{tenant\_subscriptions.max\_users}$.
        *   *(4) Form & Validation (`ProvisionAccountModal`):*
            *   Username (Tự động gợi ý theo `phone` hoặc `email`), tùy chọn mật khẩu khởi tạo mặc định. Cờ `must_change_password = true` kích hoạt bắt buộc.
            *   **Chốt chặn phân quyền theo cấp bậc:**
                *   Owner (`ROLE_FARM_OWNER`): Cấp vai trò `ROLE_FARM_MANAGER` cho trại.
                *   Farm Manager (`ROLE_FARM_MANAGER`): Cấp 1 trong 4 vai trò Cấp 4 (`ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_ACCOUNTANT`, `ROLE_FIELD_STAFF`) tại trại phụ trách.
        *   *(5) Kết quả khi thành công:* Tạo tài khoản trong bảng `users`, ghi đồng thời vào `user_roles` và `user_farm_access`, cập nhật `employees.user_id = users.id`. Toast xanh *"Đã cấp tài khoản thành công!"*.
        *   *(6) Hành vi khi thất bại:* Banner cảnh báo đỏ nếu vi phạm quota hoặc sai thẩm quyền cấp bậc.
    3.  **Nút `[ Điều Chỉnh Giờ Công (Audited Adjustment) ]`:**
        *   *(1) Điều kiện xuất hiện:* Trên mỗi dòng chấm công của Tab Tổng hợp công.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_HR_EMPLOYEE_MANAGE">`.
        *   *(3) Trạng thái cho phép thao tác:* Bản ghi chấm công chưa bị khóa kỳ lương.
        *   *(4) Form & Validation (`AttendanceAdjustModal`):* `adjusted_check_in` (DateTime), `adjusted_check_out` (DateTime, phải sau `adjusted_check_in`), `adjustment_reason` (Bắt buộc nhập tối thiểu 10 ký tự, nêu rõ lý do điều chỉnh: quên chấm, máy hỏng, công tác đột xuất).
        *   *(5) Kết quả khi thành công:* Cập nhật `is_adjusted = TRUE`, lưu giá trị cũ vào `original_check_in` và `original_check_out`, gán `adjusted_by_user_id = currentUserId`, tính lại `working_hours` và `late_minutes`. Dòng đổi sang Badge tím *"ĐÃ ĐIỀU CHỈNH"*. Ghi nhận vào nhật ký kiểm toán.
        *   *(6) Hành vi khi thất bại:* Báo lỗi nếu lý do điều chỉnh để trống hoặc giờ ra sớm hơn giờ vào.
    4.  **Nút `[ Phê Duyệt Nghỉ Phép ]`:**
        *   *(1) Điều kiện xuất hiện:* Dòng đơn nghỉ có `leave_requests.status == 'PENDING'`.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_HR_EMPLOYEE_MANAGE">`.
        *   *(3) Trạng thái cho phép thao tác:* Đơn đang chờ duyệt và số ngày xin nghỉ $\le$ số phép năm còn lại của nhân viên (nếu loại nghỉ là Phép năm).
        *   *(4) Hành động:* Bấm nút `[ Duyệt ]` kèm ghi chú phê duyệt (tùy chọn).
        *   *(5) Kết quả khi thành công:* Chuyển trạng thái đơn sang `APPROVED`, tự động trừ số ngày nghỉ tương ứng vào `employees.annual_leave_quota`. Toast xanh thông báo *"Đã duyệt đơn nghỉ phép!"*.
        *   *(6) Hành vi khi thất bại:* Toast đỏ cảnh báo *"Nhân viên không đủ quỹ phép năm để phê duyệt đơn này!"*.
    5.  **Nút `[ Phê Duyệt Làm Thêm Giờ (OT) ]`:**
        *   *(1) Điều kiện xuất hiện:* Dòng đơn làm thêm giờ có `overtime_requests.status == 'PENDING'`.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_HR_EMPLOYEE_MANAGE">`.
        *   *(3) Trạng thái cho phép thao tác:* Đơn đang chờ duyệt.
        *   *(4) Form xác nhận:* Xác nhận số giờ OT và hệ số lương `ot_multiplier` (1.5 cho ngày thường, 2.0 cho ngày nghỉ cuối tuần, 3.0 cho ngày lễ tết).
        *   *(5) Kết quả khi thành công:* Trạng thái đơn chuyển sang `APPROVED`. Toast xanh thông báo thành công.

---

### 4.6. Màn Hình 6: Workspace D - Sổ Danh Bạ Đối Tác & Cấu Hình VietQR / Hạn Mức Tín Dụng (`/app/partners`)
*   **Cấu trúc giao diện:**
    *   *Bộ lọc phân loại đối tác (Segment Tabs):* `Tất cả`, `Nhà Cung Cấp (SUPPLIER)`, `Khách Hàng Thu Mua (BUYER)`, `Đơn Vị Vận Chuyển (LOGISTICS)`, `Đại Lý 2 Chiều (AGENT)`.
    *   *Bảng dữ liệu `partners` (#4):* Mã đối tác `partner_code`, Tên công ty / thương lái `partner_name`, Mã số thuế `tax_code`, Loại đối tác (Badge màu), Số điện thoại, Hạn mức nợ `credit_limit` (Định dạng VNĐ), Thời hạn nợ `payment_term_days` (ngày), Xếp hạng tín dụng `credit_rating` (Badge A xanh lá, B vàng, C đỏ), Số nợ hiện tại (Lấy từ `debt_records`), Trạng thái (`ACTIVE`, `INACTIVE`).
    *   *Drawer Chi Tiết Hồ Sơ Đối Tác 360°:* Lịch sử đơn hàng, Sổ theo dõi công nợ chi tiết, Cấu hình tài khoản ngân hàng nhận tiền phục vụ sinh mã VietQR tự động (`bank_bin`, `bank_account_no`, `bank_account_name`).
*   **Đặc tả các nút bấm & hành động nghiệp vụ:**
    1.  **Nút `[ + Thêm Mới Đối Tác ]`:**
        *   *(1) Điều kiện xuất hiện:* Luôn hiển thị tại thanh công cụ trên cùng.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FINANCE_SALES_ORDER">` hoặc `<Can permission="PERM_INVENTORY_RECEIPT">`.
        *   *(3) Trạng thái cho phép thao tác:* Luôn khả dụng.
        *   *(4) Form & Validation (`PartnerFormModal`):* `partner_code` (Unique, 3-20 ký tự), `partner_name` (NotBlank), `partner_type` (Enum: `SUPPLIER`, `BUYER`, `LOGISTICS`, `AGENT`), `tax_code` (Pattern mã số thuế nếu là doanh nghiệp), `phone`, `email`, `address`, `credit_limit` (DecimalMin 0.0, mặc định 0.0), `payment_term_days` (Integer Min 0, mặc định 30 ngày), `credit_rating` (Mặc định `B`), `bank_bin` (Mã ngân hàng NAPAS), `bank_account_no`, `bank_account_name`.
        *   *(5) Kết quả khi thành công:* Toast xanh *"Thêm đối tác thành công!"*, hiển thị dòng mới trong danh bạ đối tác.
        *   *(6) Hành vi khi thất bại:* Inline error nếu mã đối tác hoặc mã số thuế bị trùng lặp trong cùng Tenant.
    2.  **Nút `[ Cập Nhật Hạn Mức Tín Dụng & Xếp Hạng ]`:**
        *   *(1) Điều kiện xuất hiện:* Trong Drawer chi tiết của đối tác loại `BUYER` hoặc `AGENT`.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FINANCE_SALES_ORDER">`.
        *   *(3) Trạng thái cho phép thao tác:* Đối tác đang ở trạng thái `ACTIVE`.
        *   *(4) Form & Validation:* `credit_limit` ($\ge 0$), `payment_term_days` ($\ge 0$), `credit_rating` (`A`, `B`, `C`).
        *   *(5) Kết quả khi thành công:* Toast xanh *"Đã cập nhật hạn mức tín dụng!"*, ghi nhận nhật ký kiểm toán và cập nhật badge tín nhiệm của đối tác.
        *   *(6) Hành vi khi thất bại:* Toast đỏ hiển thị lỗi.
    3.  **Nút `[ Khóa Giao Dịch Đối Tác ]`:**
        *   *(1) Điều kiện xuất hiện:* Trên menu thao tác ba chấm của từng dòng đối tác.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FINANCE_SALES_ORDER">`.
        *   *(3) Trạng thái cho phép thao tác:* `partner.status == 'ACTIVE'`.
        *   *(4) Hộp thoại xác nhận:* Cảnh báo *"Khi khóa, đối tác này sẽ không thể được chọn trong các Đơn bán sỉ và Phiếu nhập kho mới"*.
        *   *(5) Kết quả khi thành công:* Chuyển trạng thái `status = 'INACTIVE'`, Badge chuyển sang màu xám. Toast thông báo hoàn tất.

---

### 4.7. Màn Hình 7: Workspace E - Bàn Làm Việc Canh Tác Trồng Trọt, Chăn Nuôi, Cân Nặng & Thu Hoạch (`/app/farming`)
*   **Cấu trúc giao diện:**
    *   *Nút chuyển đổi phân hệ (Segment Switcher):* `Trồng Trọt (CROP)` $\leftrightarrow$ `Chăn Nuôi (LIVESTOCK)`.
    *   *Bàn Làm Việc Trồng Trọt:*
        *   Lưới Mùa Vụ `crop_seasons` (#19): Card hiển thị Mã vụ `season_code`, Giống cây trồng `crop_type_id`, Phân khu `zone_id`, Chu kỳ `operational_cycle_id`, Ngày bắt đầu `start_date`, Ngày thu hoạch dự kiến `expected_harvest_date`, Diện tích gieo trồng `planted_area_m2`, Lượng giống `seed_quantity`, Sản lượng ước tính `estimated_yield_kg`.
        *   Thanh cảnh báo an toàn cách ly thuốc BVTV (PHI Alert): Hiển thị Badge đỏ nổi bật kèm đồng hồ đếm ngược nếu vụ mùa có ngày cách ly `phi_end_date >= current_date`.
        *   Dòng thời gian nhật ký canh tác (Timeline View - `farming_logs` #20) kết hợp danh mục vật tư đã tiêu hao (`farming_log_supplies` #41).
    *   *Bàn Làm Việc Chăn Nuôi:*
        *   Danh sách Đàn / Lứa nuôi `livestock_groups` (#22): Mã lứa, Giống loài (`livestock_breeds` #21), Chuồng nuôi (`production_zones` #13), Số lượng ban đầu / hiện tại, Trọng lượng trung bình hiện tại, Ngày tuổi.
        *   Đồ thị biểu diễn tốc độ tăng trọng bình quân ngày (ADG Chart) từ dữ liệu `livestock_weight_logs` (#24).
*   **Đặc tả các nút bấm & hành động nghiệp vụ:**
    1.  **Nút `[ + Khởi Tạo Mùa Vụ Canh Tác ]`:**
        *   *(1) Điều kiện xuất hiện:* Luôn hiển thị tại Tab Trồng Trọt.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_CROP_PLAN">`.
        *   *(3) Trạng thái cho phép thao tác:* Trang trại đang làm việc có trạng thái `ACTIVE`.
        *   *(4) Form & Validation (`CropSeasonModal`):* `season_code` (Unique), `crop_type_id` (Dropdown lọc từ `crop_types`), `zone_id` (Dropdown lọc từ các Zone của Farm), `operational_cycle_id` (Dropdown chu kỳ vận hành), `start_date` (LocalDate), `expected_harvest_date` (LocalDate, phải sau `start_date`), `planted_area_m2` ($> 0.00$), `seed_quantity` ($\ge 0.00$), `estimated_yield_kg` ($\ge 0.00$).
        *   *(5) Kết quả khi thành công:* Khởi tạo vụ mùa với trạng thái `SOIL_PREPARATION` (hoặc `SOWING`). Toast xanh *"Khởi tạo mùa vụ thành công!"*.
        *   *(6) Hành vi khi thất bại:* Báo lỗi trùng mã mùa vụ hoặc phân khu không hợp lệ.
    2.  **Nút `[ + Ghi Nhật Ký Canh Tác & Trừ Kho Tự Động ]`:**
        *   *(1) Điều kiện xuất hiện:* Vụ mùa đang ở trạng thái `GROWING` hoặc `HARVESTING`.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_CROP_LOG">`.
        *   *(3) Trạng thái cho phép thao tác:* Vụ mùa chưa bị đóng sổ (`status != 'CLOSED'`).
        *   *(4) Form Drawer (`FarmingLogDrawer`):* `activity_type` (Enum: `'SOIL_TILLAGE'`, `'IRRIGATION'`, `'FERTILIZATION'`, `'PESTICIDE_APPLICATION'`, `'PRUNING'`, `'WEEDING'`, `'HARVESTING'`), `log_date` (LocalDate), `phi_days` (Số ngày cách ly an toàn, tự nạp từ vật tư hoặc nhập tay $\ge 0$), `notes`, Bảng vật tư tiêu hao: chọn `material_id`, chọn `warehouse_id`, chọn `batch_number` (chỉ nạp lô còn hàng khả dụng), nhập `actual_quantity` ($> 0$), `unit`.
        *   *(5) Kết quả khi thành công:* Lưu bản ghi `farming_logs`, tự động trừ kho vật tư (tạo phiếu xuất kho `warehouse_issues` loại `PRODUCTION_BACKFLUSH`), tính toán chi phí và lưu vào `farm_expenses`. Nếu có `phi_days > 0`, tự động cập nhật ngày hết hạn cách ly của vụ mùa. Toast xanh *"Đã ghi nhật ký và tự động xuất kho vật tư!"*.
        *   *(6) Hành vi khi thất bại:* Banner cảnh báo đỏ *"Số lượng xuất vượt quá tồn kho khả dụng của lô vật tư đã chọn!"*.
    3.  **Nút `[ + Lập Biên Bản Thu Hoạch Nông Sản ]`:**
        *   *(1) Điều kiện xuất hiện:* Trên thanh công cụ của Vụ mùa đang `GROWING` hoặc `HARVESTING`.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_HARVEST_MANAGE">`.
        *   *(3) Trạng thái cho phép thao tác:* **ĐIỀU KIỆN AN TOÀN PHI BẮT BUỘC:** Vụ mùa KHÔNG được nằm trong thời gian cách ly thuốc BVTV (`phi_end_date IS NULL` hoặc `phi_end_date < current_date`). Nếu đang trong thời gian cách ly, nút bấm bị VÔ HIỆU HÓA HOÀN TOÀN, viền đỏ, hiển thị tooltip cảnh báo: *"Mùa vụ đang trong thời gian cách ly nông dược PHI (còn X ngày) - Cấm thu hoạch!"*.
        *   *(4) Form & Validation (`HarvestModal`):* `harvest_code` (Unique), `harvest_date` (LocalDate), `quantity` (DecimalMin 0.01), `unit`, `quality_grade` (Enum: `'GRADE_A'`, `'GRADE_B'`, `'STANDARD'`, `'REJECT'`), `harvested_by_user_id` (Dropdown nhân sự), `notes`.
        *   *(5) Kết quả khi thành công:* Lưu bản ghi vào bảng `harvest_records` (#43), tự động chuyển trạng thái mùa vụ sang `HARVESTING`, mở pop-up gợi ý: *"Bạn có muốn tạo Lô Thành Phẩm để chuẩn bị kiểm định KCS ngay không?"*.
        *   *(6) Hành vi khi thất bại:* Toast đỏ hiển thị lỗi kiểm tra PHI hoặc lỗi dữ liệu.
    4.  **Nút `[ Đóng Mùa Vụ (Close Season) ]`:**
        *   *(1) Điều kiện xuất hiện:* Mùa vụ đang ở trạng thái `HARVESTING`.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_CROP_PLAN">`.
        *   *(3) Trạng thái cho phép thao tác:* Đã hoàn tất thu hoạch và không còn phiếu xuất kho/nhật ký dở dang.
        *   *(4) Hộp thoại xác nhận:* Cảnh báo *"Đóng mùa vụ sẽ khóa toàn bộ hoạt động ghi nhật ký và giải phóng các phân khu để chuẩn bị cho vụ sau"*.
        *   *(5) Kết quả khi thành công:* Cập nhật `crop_seasons.status = 'CLOSED'`. Toast xanh *"Đã đóng mùa vụ thành công!"*.
    5.  **Nút `[ + Ghi Nhận Cân Nặng (Weigh-in) ]`:**
        *   *(1) Điều kiện xuất hiện:* Tab Chăn Nuôi, khi chọn một lứa nuôi hoặc cá thể đang `ACTIVE`.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_LIVESTOCK_MANAGE">`.
        *   *(3) Trạng thái cho phép thao tác:* Lứa nuôi/cá thể đang hoạt động.
        *   *(4) Form & Validation (`LivestockWeightLogModal`):* `target_type` (`'INDIVIDUAL'`, `'GROUP'`), `individual_id` (khi chọn cá thể), `group_id` (khi chọn đàn), `record_date` (LocalDate), `weight_kg` ($> 0.00$), `recorded_by_user_id`, `notes`.
        *   *(5) Kết quả khi thành công:* Lưu vào `livestock_weight_logs` (#24), cập nhật chỉ số tăng trọng và vẽ lại đồ thị ADG tức thì. Toast xanh thông báo hoàn tất.

---

### 4.8. Màn Hình 8: Workspace G - Cổng Nhân Viên, Chấm Công GPS/Selfie 2 Đầu, Lịch Ca, Nghỉ Phép & Kanban Việc (`/app/my-dashboard`)
*   **Cấu trúc giao diện (Mobile-First UI Cho Công Nhân Hiện Trường):**
    *   *Thẻ định danh cá nhân (Worker Identity Card):* Ảnh đại diện, Tên nhân viên, Ca làm việc hôm nay (Giờ bắt đầu - kết thúc, Thời gian ân hạn trễ), Trạng thái công trong ngày (Badge lớn: `CHƯA VÀO CA`, `ĐANG TRONG CA`, `ĐÃ KẾT THÚC CA`).
    *   *Bộ Công Cụ Chấm Công 2 Đầu Trực Quan (GPS + Camera Selfie Widget):*
        *   Hiển thị bản đồ nhỏ hiển thị vị trí GPS hiện tại của điện thoại và vòng tròn Geofence của trang trại.
        *   Khung ngắm Camera trước trực tiếp để chụp ảnh selfie nhận diện khuôn mặt khi bấm check-in/out.
    *   *Bảng Kanban Nhiệm Vụ Được Giao (4 Cột chuẩn SQL):* `CẦN LÀM (TODO)`, `ĐANG LÀM (IN_PROGRESS)`, `CHỜ NGHIỆM THU (PENDING_REVIEW)`, `HOÀN THÀNH (DONE)`.
    *   *Drawer Đăng Ký Chế Độ:* Đơn xin nghỉ phép (`leave_requests`) và Đơn đăng ký làm thêm giờ (`overtime_requests`).
*   **Đặc tả các nút bấm & hành động nghiệp vụ:**
    1.  **Nút `[ 📸 Check-in Vào Ca (GPS + Selfie) ]`:**
        *   *(1) Điều kiện xuất hiện:* Khi nhân viên chưa chấm công vào ca hôm nay (`time_attendances` trong ngày chưa có bản ghi).
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_HR_ATTENDANCE">`.
        *   *(3) Trạng thái cho phép thao tác:* Nằm trong khung giờ ca làm việc (cho phép chấm sớm tối đa 60 phút trước giờ ca bắt đầu).
        *   *(4) Ràng buộc kỹ thuật & Validation:*
            *   Bắt buộc mở trực tiếp Camera trước (Selfie) của thiết bị. Cấm tải ảnh từ thư viện máy.
            *   Lấy tọa độ GPS (`latitude`, `longitude`) với độ chính xác cao (`enableHighAccuracy: true`).
            *   Tính khoảng cách Haversine từ tọa độ thiết bị đến tâm trang trại. Nếu $\text{khoảng cách} > \text{farms.geofence\_radius\_m}$, hệ thống chặn chấm công và rung thiết bị kèm thông báo đỏ: *"Bạn đang ở ngoài ranh giới trang trại (Cách tâm trại X mét, bán kính cho phép Y mét) - Không thể chấm công!"*.
        *   *(5) Kết quả khi thành công:* Đóng dấu Watermark thời gian + tọa độ lên ảnh, tải ảnh lên CDN, tạo bản ghi `time_attendances` (#54) với `check_in_time = NOW()`, `check_in_photo_url`, tính `late_minutes` nếu quá giờ ân hạn. Thẻ đổi sang trạng thái `ĐANG TRONG CA`, nút tự động chuyển thành nút `[ Check-out Ra Ca ]`.
        *   *(6) Hành vi khi thất bại:* Banner cảnh báo nếu người dùng từ chối cấp quyền truy cập Camera hoặc Vị trí GPS trên trình duyệt.
    2.  **Nút `[ 🏁 Check-out Ra Ca (GPS + Selfie) ]`:**
        *   *(1) Điều kiện xuất hiện:* Đã check-in thành công và chưa check-out (`check_in_time IS NOT NULL AND check_out_time IS NULL`).
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_HR_ATTENDANCE">`.
        *   *(3) Trạng thái cho phép thao tác:* Đang trong ca làm việc.
        *   *(4) Ràng buộc kỹ thuật & Validation:* Chụp ảnh selfie trực tiếp và kiểm tra bán kính GPS tương tự như khi check-in.
        *   *(5) Kết quả khi thành công:* Cập nhật `check_out_time = NOW()`, lưu `check_out_photo_url`, tự động tính toán tổng số giờ công:
            $$\text{working\_hours} = \frac{\text{check\_out\_time} - \text{check\_in\_time} - \text{break\_minutes}}{60}$$
            và tính `early_leave_minutes` nếu ra sớm trước giờ kết thúc ca. Thẻ chuyển sang trạng thái `ĐÃ KẾT THÚC CA`. Toast xanh *"Chúc bạn một ngày làm việc tốt lành!"*.
        *   *(6) Hành vi khi thất bại:* Thông báo lỗi GPS ngoài ranh giới hoặc lỗi đường truyền mạng.
    3.  **Nút `[ Bắt Đầu Nhiệm Vụ (Start Task) ]`:**
        *   *(1) Điều kiện xuất hiện:* Trên thẻ công việc thuộc cột `TODO` trong đó nhân viên hiện tại có tên trong danh sách phân công `farm_task_assignees`.
        *   *(2) Quyền bảo vệ:* Mọi nhân sự được phân công nhiệm vụ.
        *   *(3) Trạng thái cho phép thao tác:* `farm_tasks.status == 'TODO'`.
        *   *(4) Hành động:* Bấm nút hoặc kéo thẻ sang cột `IN_PROGRESS`.
        *   *(5) Kết quả khi thành công:* Cập nhật trạng thái `farm_tasks.status = 'IN_PROGRESS'`. Card chuyển sang viền màu vàng cam.
    4.  **Nút `[ Báo Cáo Hoàn Thành Nhiệm Vụ (Gửi Nghiệm Thu) ]`:**
        *   *(1) Điều kiện xuất hiện:* Trên thẻ công việc thuộc cột `IN_PROGRESS`.
        *   *(2) Quyền bảo vệ:* Nhân viên nhận nhiệm vụ.
        *   *(3) Trạng thái cho phép thao tác:* `farm_tasks.status == 'IN_PROGRESS'`.
        *   *(4) Form xác nhận (`CompleteTaskModal`):* Nhập kết quả công việc đã thực hiện, tùy chọn chụp ảnh hiện trường đính kèm (lưu `photos_json`).
        *   *(5) Kết quả khi thành công:* Cập nhật `farm_tasks.status = 'PENDING_REVIEW'`, chuyển card sang cột `CHỜ NGHIỆM THU (PENDING_REVIEW)` viền vàng, gửi thông báo đẩy tới Quản lý để nghiệm thu. Khi Quản lý duyệt nghiệm thu đạt, hệ thống chuyển sang `DONE` (viền xanh lá).
    5.  **Nút `[ + Gửi Đơn Xin Nghỉ Phép ]`:**
        *   *(1) Điều kiện xuất hiện:* Luôn hiển thị trong Drawer Chế độ nhân viên.
        *   *(2) Quyền bảo vệ:* Nhân viên có tài khoản hợp lệ.
        *   *(3) Form & Validation (`LeaveRequestModal`):* `leave_type` (`'ANNUAL_LEAVE'`, `'SICK_LEAVE'`, `'UNPAID_LEAVE'`, `'MATERNITY_LEAVE'`, `'BEREAVEMENT_LEAVE'`), `start_date`, `end_date` ($\ge \text{start\_date}$), `reason` (Bắt buộc). Nếu chọn `ANNUAL_LEAVE`, hệ thống hiển thị số phép năm còn lại và kiểm tra chặn nếu số ngày xin nghỉ vượt quá quỹ phép khả dụng.
        *   *(4) Kết quả khi thành công:* Tạo bản ghi `leave_requests` trạng thái `PENDING`, gửi thông báo cho Trưởng trại duyệt. Toast xanh thông báo gửi đơn thành công.

---

### 4.9. Màn Hình 9: Workspace H1 - Tập Hợp Chi Phí, Bàn Phân Bổ Giá Thành & Ngân Sách Dự Toán (`/app/cost-accounting`)
*   **Cấu trúc giao diện:**
    *   *Sổ Tập Hợp Chi Phí (Tab 1 - `farm_expenses` #60):* Bảng dữ liệu toàn bộ chi phí phát sinh với bộ lọc 4 nguồn chi phí `expense_source` (`MANUAL`, `INVENTORY_BACKFLUSH`, `PAYROLL_ALLOCATION`, `UTILITY_BILL`), Cột cờ tính giá thành `unit_cost_eligible` (Badge xanh *"Tính giá thành"* / Badge xám *"Chi phí quản lý"*), Cột tỷ lệ đã phân bổ (Thanh tiến độ % số tiền đã gán vào các vụ mùa/lứa nuôi).
    *   *Bàn Phân Bổ Chi Phí Đa Đối Tượng (Tab 2 - `cost_allocations` #61):* Giao diện 2 cột tương tác (Split-panel View): Cột trái hiển thị danh sách các khoản chi phí chung chưa phân bổ hết; Cột phải là bàn thao tác gán tiền vào các đối tượng đích (`CROP_SEASON`, `LIVESTOCK_GROUP`, `PRODUCTION_ZONE`).
    *   *Bảng Phân Tích Giá Thành Đơn Vị (Tab 3 - Unit Cost Dashboard):* Bảng tổng hợp theo từng Vụ mùa / Lứa nuôi thu hoạch: Tổng sản lượng thực tế (kg), Chi phí vật tư (từ Backflushing), Chi phí nhân công phân bổ, Chi phí chung phân bổ $\rightarrow$ Giá thành thực tế trên mỗi kg nông sản:
        $$\text{Unit Cost (VNĐ/kg)} = \frac{\sum \text{Chi phí hợp lệ}}{\text{Tổng sản lượng thu hoạch (kg)}}$$
    *   *Bảng Theo Dõi Dự Toán Ngân Sách (Tab 4 - `budgets` #69 & `budget_line_items` #70):* Biểu đồ cột so sánh Hạn mức dự toán (`allocated_amount`) với Thực chi (`spent_amount`) theo từng nhóm chi phí.
*   **Đặc tả các nút bấm & hành động nghiệp vụ:**
    1.  **Nút `[ + Khai Báo Chi Phí Thủ Công / Hóa Đơn ]`:**
        *   *(1) Điều kiện xuất hiện:* Luôn hiển thị tại Tab Sổ Tập Hợp Chi Phí.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FINANCE_EXPENSE">`.
        *   *(3) Trạng thái cho phép thao tác:* Trang trại đang hoạt động.
        *   *(4) Form & Validation (`ExpenseFormModal`):* `expense_code` (Unique), `cost_category_id` (Dropdown lọc từ `cost_categories`), `amount` (DecimalMin 1000.0 VNĐ), `expense_date` (LocalDate), `expense_source` (Enum: `'MANUAL'`, `'INVENTORY_BACKFLUSH'`, `'PAYROLL_ALLOCATION'`, `'UTILITY_BILL'`), `payment_method` (Enum: `'CASH'`, `'BANK_TRANSFER'`, `'TRADE_CREDIT'`), `recipient_name`, `receipt_photo_url` (Tải lên ảnh chụp hóa đơn chứng từ), `unit_cost_eligible` (Checkbox, mặc định TRUE), `notes`.
        *   *(5) Kết quả khi thành công:* Lưu bản ghi vào bảng `farm_expenses`, cập nhật ngay tổng chi phí lũy kế của kỳ. Toast xanh thông báo *"Đã lưu khoản chi phí!"*.
        *   *(6) Hành vi khi thất bại:* Inline error tại các trường không hợp lệ.
    2.  **Nút `[ Phân Bổ Chi Phí Chung (Allocate Expense) ]`:**
        *   *(1) Điều kiện xuất hiện:* Trên dòng của khoản chi phí có số tiền chưa phân bổ hết: $\sum \text{allocated\_amount} < \text{farm\_expenses.amount}$.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FINANCE_EXPENSE">`.
        *   *(3) Trạng thái cho phép thao tác:* Khoản chi có cờ `unit_cost_eligible = TRUE`.
        *   *(4) Form & Validation (`CostAllocationModal`):* Chọn loại đối tượng phân bổ `target_type` (Enum: `'CROP_SEASON'`, `'LIVESTOCK_GROUP'`, `'PRODUCTION_ZONE'`), Chọn đối tượng đích `target_id` (Dropdown nạp các vụ mùa hoặc đàn nuôi đang hoạt động), Nhập số tiền phân bổ `allocated_amount` ($> 0$).
        *   *(5) Ràng buộc kiểm toán bắt buộc:* Hệ thống tự động kiểm tra điều kiện tổng tiền phân bổ:
            $$\sum \text{allocated\_amount} \le \text{farm\_expenses.amount}$$
            Nếu số tiền phân bổ vượt quá số dư còn lại của khoản chi phí, nút Xác nhận bị khóa và hiển thị cảnh báo đỏ.
        *   *(6) Kết quả khi thành công:* Lưu bản ghi vào bảng `cost_allocations` (#61), cập nhật ngay lập tức chi phí của đối tượng đích trên Bảng phân tích giá thành. Toast xanh *"Phân bổ chi phí thành công!"*.
    3.  **Nút `[ + Khởi Tạo Dự Toán Ngân Sách Chu Kỳ ]`:**
        *   *(1) Điều kiện xuất hiện:* Tab Quản Trị Ngân Sách.
        *   *(2) Quyền bảo vệ:* `<Can permission="PERM_FINANCE_EXPENSE">`.
        *   *(3) Trạng thái cho phép thao tác:* Chu kỳ vận hành đang ở trạng thái `ACTIVE`.
        *   *(4) Form & Validation (`BudgetCreateModal`):* Chọn chu kỳ `operational_cycle_id`, `fiscal_year` (Năm hiện tại), Nhập hạn mức phân bổ cho từng nhóm trong 5 nhóm chi phí chuẩn (`'MATERIALS'`, `'DIRECT_LABOR'`, `'MACHINERY_FUEL'`, `'DEPRECIATION'`, `'INDIRECT_OVERHEAD'`). Tổng hạn mức ngân sách `total_budget_amount` tự động tính bằng tổng các dòng.
        *   *(5) Kết quả khi thành công:* Lưu vào bảng `budgets` (#69) và `budget_line_items` (#70). Kích hoạt cơ chế cảnh báo tự động khi thực chi chạm ngưỡng 90% hạn mức.

---

### 4.10. Màn Hình 10: Cài Đặt Danh Mục Tĩnh, Trung Tâm Báo Cáo, Quản Trị Hệ Thống, Platform Shell & Cổng QR Công Khai
*   **Chi tiết đặc tả các màn hình hỗ trợ và công cộng:**

#### 1. Trung Tâm Cài Đặt Danh Mục Tĩnh 7 Tabs (`/app/settings`):
*   *Phân chia cấu trúc 7 Tabs danh mục:*
    1.  Tab 1: **Giống cây trồng** (`crop_types` #18)
    2.  Tab 2: **Giống vật nuôi** (`livestock_breeds` #21)
    3.  Tab 3: **Vật tư & Chuyển đổi đơn vị** (`material_categories` #27, `materials` #28, `material_unit_conversions` #29)
    4.  Tab 4: **Hệ thống kho bãi & Ô kệ** (`warehouses` #26)
    5.  Tab 5: **Định mức tiêu hao kỹ thuật** (`consumption_quotas` #30)
    6.  Tab 6: **Ca làm việc chuẩn** (`work_shifts` #52)
    7.  Tab 7: **Nhóm chi phí kế toán** (`cost_categories` #59)

*   *Quy tắc điều khiển chung trên từng Tab danh mục:*
    *   Mỗi Tab có thanh công cụ gồm: Ô tìm kiếm từ khóa (`search`), Bộ lọc trạng thái (`status`: Tất cả / `ACTIVE` / `INACTIVE`), và Nút bấm `[ + Thêm Mới ]` mở Modal nhập chuẩn tương ứng.
    *   Mỗi dòng trên Bảng dữ liệu có Nút bấm `[ Sửa ]` (mở Drawer chỉnh sửa có nạp sẵn dữ liệu) và Công tắc gạt `[ Bật / Tắt Hoạt Động ]` (`status = 'ACTIVE' / 'INACTIVE'`).
    *   *Ràng buộc toàn vẹn dữ liệu (Integrity Guard):* Không cho phép xóa vật lý (Hard Delete) bất kỳ bản ghi danh mục nào đã phát sinh giao dịch trong các bảng nghiệp vụ (nhật ký canh tác, phiếu nhập xuất kho, phân ca làm việc, đơn hàng). Nút Xóa tự động bị ẩn hoặc vô hiệu hóa.

---

##### ĐẶC TẢ FORM THÊM/SỬA & VALIDATION CHI TIẾT CHO 7 DANH MỤC CỐT LÕI:

---

###### 1.1. Tab 1: Form Giống Cây Trồng (`crop_types` #18 - `CropTypeFormModal`)
Màn hình phục vụ khai báo các giống cây ăn quả, rau màu, cây công nghiệp với các thông số sinh trưởng chuẩn để làm căn cứ lập kế hoạch mùa vụ và cảnh báo thời vụ.

| Tên Trường Giao Diện (Label) | Biến DDL / DTO | Kiểu Ô Nhập (Control Type) | Bắt Buộc | Quy Chuẩn Dữ Liệu & Ràng Buộc Validation | Thông Báo Lỗi Khi Vi Phạm (Error Message) |
| :--- | :--- | :--- | :---: | :--- | :--- |
| **Tên giống cây trồng** | `name` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 150 ký tự; không được để trống; loại bỏ khoảng trắng thừa 2 đầu. Placeholder: *"VD: Xoài Cát Chu Cao Lãnh"* | *"Tên giống cây trồng không được để trống"* |
| **Mã giống cây** | `variety_code` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 50 ký tự; tự động viết hoa (Auto-uppercase); Pattern: `^[A-Z0-9_-]{2,50}$`. Unique theo `tenant_id`. Placeholder: *"VD: XCC-01"* | *"Mã giống cây đã tồn tại hoặc chứa ký tự đặc biệt"* |
| **Chu kỳ sinh trưởng chuẩn** | `growth_days_standard` | **Ô nhập số nguyên (Number Input - Integer)** | Có | Đơn vị: ngày. Min: 1; Max: 3650; Mặc định: 90. Validation: `growth_days_standard > 0`. Placeholder: *"90"* | *"Số ngày sinh trưởng phải là số nguyên lớn hơn 0"* |
| **Nhu cầu nước tưới trung bình** | `water_need_m3_day` | **Ô nhập số thập phân (Number Input - Decimal 8,2)** | Không | Đơn vị: $m^3$/ngày/ha. Min: 0.00; Max: 999999.99. Bước nhảy: 0.1. Placeholder: *"VD: 2.50"* | *"Nhu cầu nước tưới không được âm"* |
| **Nhiệt độ tối ưu tối thiểu** | `optimal_temp_min` | **Ô nhập số thập phân (Number Input - Decimal 5,2)** | Không | Đơn vị: °C. Min: -10.0; Max: 60.0. Bước nhảy: 0.5. Placeholder: *"VD: 22.0"* | *"Nhiệt độ tối thiểu không hợp lệ"* |
| **Nhiệt độ tối ưu tối đa** | `optimal_temp_max` | **Ô nhập số thập phân (Number Input - Decimal 5,2)** | Không | Đơn vị: °C. Min: -10.0; Max: 60.0. Ràng buộc: `optimal_temp_min <= optimal_temp_max`. Placeholder: *"VD: 35.0"* | *"Nhiệt độ tối ưu tối đa không được nhỏ hơn nhiệt độ tối thiểu"* |

---

###### 1.2. Tab 2: Form Giống Vật Nuôi (`livestock_breeds` #21 - `LivestockBreedFormModal`)
Màn hình quản lý danh mục giống vật nuôi phân nhóm theo loài, quy định số ngày nuôi tiêu chuẩn và trọng lượng xuất chuồng mục tiêu để làm cơ sở tính chỉ số FCR và ADG.

| Tên Trường Giao Diện (Label) | Biến DDL / DTO | Kiểu Ô Nhập (Control Type) | Bắt Buộc | Quy Chuẩn Dữ Liệu & Ràng Buộc Validation | Thông Báo Lỗi Khi Vi Phạm (Error Message) |
| :--- | :--- | :--- | :---: | :--- | :--- |
| **Phân loại loài vật nuôi** | `species` | **Ô chọn Dropdown (Single Select)** | Có | Nạp 6 giá trị chuẩn từ SQL: `CATTLE` (Bò/Trâu), `SWINE` (Heo/Lợn), `POULTRY` (Gia cầm), `GOAT` (Dê), `SHEEP` (Cừu), `AQUA` (Thủy sản). | *"Vui lòng chọn phân loại loài vật nuôi"* |
| **Tên giống vật nuôi** | `breed_name` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 150 ký tự; không để trống. Unique theo bộ `(tenant_id, species, breed_name)`. Placeholder: *"VD: Heo Rừng Lai F1, Bò BBB, Gà Ri Thả Vườn"* | *"Tên giống vật nuôi đã tồn tại trong cùng loài"* |
| **Số ngày nuôi tiêu chuẩn** | `standard_growth_days` | **Ô nhập số nguyên (Number Input - Integer)** | Không | Đơn vị: ngày. Min: 1; Max: 3650. Validation: `standard_growth_days > 0` nếu có nhập. Placeholder: *"VD: 180"* | *"Số ngày nuôi tiêu chuẩn phải lớn hơn 0"* |
| **Trọng lượng xuất chuồng mục tiêu** | `target_weight_kg` | **Ô nhập số thập phân (Number Input - Decimal 8,2)** | Không | Đơn vị: kg/con. Min: 0.01; Max: 999999.99. Validation: `target_weight_kg > 0.00`. Bước nhảy: 0.5. Placeholder: *"VD: 95.00"* | *"Trọng lượng xuất chuồng mục tiêu phải lớn hơn 0"* |

---

###### 1.3. Tab 3: Form Vật Tư Nông Nghiệp & Đơn Vị Quy Đổi (`materials` #28 + `material_unit_conversions` #29 - `MaterialFormModal`)
Form 2 phần (Gồm thông tin SKU mặt hàng vật tư và Bảng cấu hình quy đổi đơn vị bao bì nhập/xuất kho).

*   **Phần A: Thông Tin Mặt Hàng Vật Tư (`materials` #28):**

| Tên Trường Giao Diện (Label) | Biến DDL / DTO | Kiểu Ô Nhập (Control Type) | Bắt Buộc | Quy Chuẩn Dữ Liệu & Ràng Buộc Validation | Thông Báo Lỗi Khi Vi Phạm (Error Message) |
| :--- | :--- | :--- | :---: | :--- | :--- |
| **Nhóm phân loại vật tư** | `category_id` | **Ô chọn Dropdown (Single Select)** | Có | Nạp danh mục `material_categories` (#27). Khi chọn nhóm `PESTICIDE`, tự động chuyển chiến lược xuất sang `FEFO` và kích hoạt ô cách ly PHI. | *"Vui lòng chọn nhóm danh mục vật tư"* |
| **Mã SKU mặt hàng** | `sku_code` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 50 ký tự; tự động viết hoa; Pattern: `^[A-Z0-9_-]{3,50}$`. Unique toàn tenant. Placeholder: *"VD: SKU-NPK-202015"* | *"Mã SKU đã tồn tại hoặc không đúng định dạng"* |
| **Mã vạch Barcode** | `barcode` | **Ô nhập chuỗi kèm nút Scan (Input Text with Scan)** | Không | Tối đa 100 ký tự; chuẩn EAN-13, Code-128. Unique toàn tenant nếu có nhập. Placeholder: *"Quét hoặc nhập mã vạch"* | *"Mã vạch đã được gán cho một mặt hàng khác"* |
| **Tên mặt hàng vật tư** | `name` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 255 ký tự; không để trống. Placeholder: *"VD: Phân bón NPK Đầu Trâu 20-20-15+TE"* | *"Tên mặt hàng vật tư không được để trống"* |
| **Đơn vị cơ sở chuẩn** | `standard_unit` | **Ô chọn Dropdown (Single Select)** | Có | 9 giá trị chuẩn từ SQL: `KG`, `GRAM`, `LITER`, `ML`, `BAG`, `BOTTLE`, `DOSE`, `PIECE`, `BOX`. Mặc định `KG` cho phân, `LITER` cho thuốc. | *"Vui lòng chọn đơn vị chuẩn cơ sở"* |
| **Chiến lược xuất kho** | `dispatch_strategy` | **Ô chọn Dropdown (Single Select)** | Có | 2 giá trị chuẩn: `FIFO` (Nhập trước xuất trước - Mặc định cho phân/vật dụng), `FEFO` (Hạn ngắn xuất trước - Bắt buộc cho thuốc BVTV/Vaccine). | *"Vui lòng chọn chiến lược xuất kho"* |
| **Cảnh báo cận hạn sử dụng** | `expiry_alert_days` | **Ô nhập số nguyên (Number Input - Integer)** | Có | Đơn vị: ngày. Min: 0; Max: 365; Mặc định: 30. Hệ thống bật cờ vàng khi hạn dùng $\le$ giá trị này. | *"Số ngày cảnh báo không được là số âm"* |
| **Mức tồn kho tối thiểu** | `min_stock_level` | **Ô nhập số thập phân (Number Input - Decimal 12,2)** | Có | Min: 0.00; Mặc định: 0.00. Khi tồn kho $<$ giá trị này, hiển thị cảnh báo đỏ cần nhập hàng. | *"Mức tồn tối thiểu không được âm"* |
| **Mức tồn kho tối đa** | `max_stock_level` | **Ô nhập số thập phân (Number Input - Decimal 12,2)** | Không | Phải $\ge$ `min_stock_level`. Dùng để cảnh báo nguy cơ dư thừa tồn kho. | *"Tồn tối đa không được nhỏ hơn mức tồn tối thiểu"* |
| **Đơn giá nhập chuẩn** | `unit_price_standard`| **Ô nhập số thập phân (Currency VNĐ - Decimal 14,2)** | Có | Min: 0.00; Mặc định: 0.00. Làm căn cứ tính giá trị dự toán. | *"Đơn giá không được là số âm"* |
| **Nhà sản xuất / Thương hiệu** | `manufacturer_name` | **Ô nhập chuỗi (Input Text)** | Không | Tối đa 255 ký tự. Placeholder: *"VD: Công ty Cổ phần Phân bón Bình Điền"* | N/A |
| **Hoạt chất / Thành phần** | `active_ingredient` | **Ô nhập chuỗi (Input Text)** | Không | Tối đa 255 ký tự. Placeholder: *"VD: N: 20%, P2O5: 20%, K2O: 15%"* | N/A |
| **Thời gian cách ly mặc định (PHI)**| `default_phi_days` | **Ô nhập số nguyên (Number Input - Integer)** | Có | Đơn vị: ngày. Min: 0; Max: 90; Mặc định: 0. Tự động điền vào nhật ký canh tác khi phun thuốc. | *"Số ngày cách ly PHI không được âm"* |
| **Hạn sử dụng tiêu chuẩn** | `shelf_life_days` | **Ô nhập số nguyên (Number Input - Integer)** | Không | Đơn vị: ngày. Min: 1. Dùng để tự động tính `expiry_date` khi tạo phiếu nhập kho. | *"Hạn sử dụng tiêu chuẩn phải lớn hơn 0"* |
| **Mô tả & Hướng dẫn sử dụng**| `description` | **Vùng văn bản (Textarea)** | Không | Tối đa 500 ký tự. Lưu ý an toàn bảo hộ lao động. | N/A |
| **Trạng thái mặt hàng** | `status` | **Ô chọn Dropdown (Single Select)** | Có | 3 giá trị: `ACTIVE` (Đang dùng), `INACTIVE` (Tạm ngưng), `DISCONTINUED` (Ngừng sử dụng vĩnh viễn). | *"Trạng thái không hợp lệ"* |

*   **Phần B: Bảng Cấu Hình Quy Đổi Đơn Vị Bao Bì (`material_unit_conversions` #29):**
Bảng động cho phép thêm/sửa/xóa các quy cách đóng gói thương mại (Bao, Thùng, Can, Chai):
    1.  **Tên đơn vị quy đổi (`unit_name`):** Ô nhập chuỗi (tối đa 30 ký tự, VD: `BAG`, `BOX`, `CAN`, `THÙNG`). Cấm trùng với `standard_unit`.
    2.  **Hệ số quy đổi (`conversion_factor`):** Ô nhập số thập phân (Decimal 12,4), bắt buộc `conversion_factor > 0.0000`. Hiển thị nhãn công thức: `1 [unit_name] = [conversion_factor] [standard_unit]` (Ví dụ: `1 BAG = 25.0000 KG`).
    3.  **Mã vạch bao bì riêng (`unit_barcode`):** Ô nhập chuỗi (tối đa 100 ký tự, tùy chọn, Unique toàn tenant).
    4.  **Đơn vị mặc định khi mua (`is_purchase_unit`):** Công tắc gạt (Checkbox). Khi bật, tự động chọn đơn vị này trong form Phiếu nhập kho mua hàng.
    5.  **Đơn vị mặc định khi xuất (`is_dispatch_unit`):** Công tắc gạt (Checkbox). Khi bật, tự động chọn đơn vị này khi xuất kho hoặc ghi nhật ký.

---

###### 1.4. Tab 4: Form Kho Bãi & Khu Vực Lưu Trữ (`warehouses` #26 - `WarehouseFormModal`)
Màn hình quản lý các kho vật tư, kho thành phẩm nông sản và kho lạnh bảo quản với đầy đủ thông số kỹ thuật dung tích và môi trường.

| Tên Trường Giao Diện (Label) | Biến DDL / DTO | Kiểu Ô Nhập (Control Type) | Bắt Buộc | Quy Chuẩn Dữ Liệu & Ràng Buộc Validation | Thông Báo Lỗi Khi Vi Phạm (Error Message) |
| :--- | :--- | :--- | :---: | :--- | :--- |
| **Trang trại trực thuộc** | `farm_id` | **Ô chọn Dropdown (Single Select)** | Có | Mặc định chọn Trang trại hiện tại; Read-only nếu người dùng cấp Farm. | *"Vui lòng chọn trang trại trực thuộc"* |
| **Mã định danh kho** | `code` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 50 ký tự; tự động viết hoa; Pattern: `^[A-Z0-9_-]{3,50}$`. Unique trong cùng `farm_id`. Placeholder: *"VD: KHO-VT-01"* | *"Mã kho đã tồn tại trong trang trại"* |
| **Tên kho bãi** | `name` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 150 ký tự; không để trống. Placeholder: *"VD: Kho Vật Tư Phân Bón Trại 01"* | *"Tên kho bãi không được để trống"* |
| **Phân loại tính chất kho** | `warehouse_type` | **Ô chọn Dropdown (Single Select)** | Có | 7 giá trị chuẩn từ SQL: `FERTILIZER` (Kho phân bón), `PESTICIDE` (Kho thuốc BVTV), `ANIMAL_FEED` (Kho thức ăn), `HARVESTED_PRODUCE` (Kho nông sản thu hoạch), `COLD_STORAGE` (Kho lạnh), `TOOLS_EQUIPMENT` (Kho công cụ dụng cụ), `GENERAL` (Kho tổng hợp). | *"Vui lòng chọn loại hình kho phù hợp"* |
| **Sức chứa thiết kế** | `capacity_m3` | **Ô nhập số thập phân (Number Input - Decimal 12,2)** | Không | Đơn vị: $m^3$. Min: 0.00; Max: 999999999.99. Placeholder: *"VD: 500.00"* | *"Sức chứa không được âm"* |
| **Diện tích mặt sàn** | `floor_area_m2` | **Ô nhập số thập phân (Number Input - Decimal 12,2)** | Không | Đơn vị: $m^2$. Min: 0.00; Max: 999999999.99. Placeholder: *"VD: 250.00"* | *"Diện tích sàn không được âm"* |
| **Nhiệt độ bảo quản chuẩn** | `standard_temp_c` | **Ô nhập số thập phân (Number Input - Decimal 5,2)** | Không | Đơn vị: °C. Phạm vi: từ -30.0 đến 50.0. Bắt buộc nhập nếu loại kho là `COLD_STORAGE`. Placeholder: *"VD: 4.0"* | *"Vui lòng nhập nhiệt độ chuẩn cho kho lạnh"* |
| **Độ ẩm bảo quản chuẩn** | `standard_humidity_pct` | **Ô nhập số thập phân (Number Input - Decimal 5,2)** | Không | Đơn vị: %. Ràng buộc: $0.00 \le \text{standard\_humidity\_pct} \le 100.00$. Placeholder: *"VD: 65.0"* | *"Độ ẩm phải nằm trong khoảng từ 0% đến 100%"* |
| **Mô tả vị trí mặt bằng** | `location_desc` | **Ô nhập chuỗi (Input Text)** | Không | Tối đa 255 ký tự. Placeholder: *"VD: Cổng số 2, đối diện phân khu nhà lưới A"* | N/A |
| **Thủ kho phụ trách** | `manager_user_id` | **Ô chọn Dropdown (Single Select)** | Không | Nạp danh sách nhân sự có vai trò `ROLE_WAREHOUSE_STAFF` thuộc trang trại hiện tại. | N/A |
| **Trạng thái hoạt động** | `status` | **Ô chọn Dropdown (Single Select)** | Có | 3 giá trị chuẩn: `ACTIVE` (Đang mở hoạt động), `INACTIVE` (Tạm ngưng), `FULL` (Đã đầy sức chứa). | *"Trạng thái kho không hợp lệ"* |

---

###### 1.5. Tab 5: Form Định Mức Tiêu Hao Kỹ Thuật (`consumption_quotas` #30 - `ConsumptionQuotaFormModal`)
Màn hình thiết lập định mức sử dụng phân bón, thuốc BVTV, hoặc thức ăn chăn nuôi theo từng giai đoạn phát triển, phục vụ kiểm soát thất thoát và tự động tính nhu cầu vật tư.

| Tên Trường Giao Diện (Label) | Biến DDL / DTO | Kiểu Ô Nhập (Control Type) | Bắt Buộc | Quy Chuẩn Dữ Liệu & Ràng Buộc Validation | Thông Báo Lỗi Khi Vi Phạm (Error Message) |
| :--- | :--- | :--- | :---: | :--- | :--- |
| **Trang trại áp dụng** | `farm_id` | **Ô chọn Dropdown (Single Select)** | Có | Nạp trang trại đang chọn; Read-only; composite key với tenant. | *"Vui lòng chọn trang trại áp dụng"* |
| **Đối tượng áp dụng** | N/A (UI Selector) | **Nút chuyển chọn Radio (Radio Group Switch)** | Có | 2 tùy chọn độc quyền: `🔘 Cây trồng` (Kích hoạt chọn giống cây) hoặc `🔘 Vật nuôi` (Kích hoạt chọn giống nuôi). | *"Vui lòng chọn loại đối tượng áp dụng định mức"* |
| **Giống cây trồng** | `crop_type_id` | **Ô chọn Dropdown (Single Select)** | Tùy chọn* | Bắt buộc khi chọn Radio Cây trồng; Bị vô hiệu hóa và gán `null` khi chọn Vật nuôi. Nạp từ `crop_types` (#18). | *"Vui lòng chọn giống cây trồng"* |
| **Giống vật nuôi** | `livestock_breed_id` | **Ô chọn Dropdown (Single Select)** | Tùy chọn* | Bắt buộc khi chọn Radio Vật nuôi; Bị vô hiệu hóa và gán `null` khi chọn Cây trồng. Nạp từ `livestock_breeds` (#21). | *"Vui lòng chọn giống vật nuôi"* |
| **Ràng buộc đối tượng SQL** | N/A | **Constraint chk_consumption_quotas_target** | Bắt buộc | Hệ thống kiểm tra thỏa mãn: Đúng 1 trong 2 trường có giá trị, trường còn lại bắt buộc bằng `NULL`. | *"Định mức chỉ được gán cho cây trồng HOẶC vật nuôi, không được chọn cả hai"* |
| **Mặt hàng vật tư áp dụng** | `material_id` | **Ô chọn Dropdown có tìm kiếm (Select with Search)** | Có | Nạp danh mục `materials` (#28) đang `ACTIVE`. Hiển thị kèm mã SKU và đơn vị chuẩn `standard_unit`. | *"Vui lòng chọn vật tư nông nghiệp"* |
| **Số lượng định mức tiêu chuẩn**| `standard_quantity` | **Ô nhập số thập phân (Number Input - Decimal 12,2)** | Có | Min: 0.01; Max: 999999999.99. Validation: `standard_quantity > 0.00`. Placeholder: *"VD: 50.00"* | *"Số lượng định mức phải lớn hơn 0"* |
| **Đơn vị đo lường định mức** | `unit_of_measure` | **Ô chọn Dropdown (Single Select)** | Có | 3 giá trị chuẩn từ SQL: `PER_HECTARE` (Trên 1 hecta), `PER_HEAD` (Trên 1 đầu con), `PER_DAY` (Trên 1 ngày sinh trưởng). | *"Vui lòng chọn đơn vị đo lường định mức"* |
| **Giai đoạn sinh trưởng** | `stage` | **Ô nhập chuỗi hoặc chọn gợi ý (Creatable Select)** | Không | Tối đa 50 ký tự. Gợi ý: `LAM_DAT`, `CAY_CON`, `RA_HOA`, `NUOI_TRAI`, `VO_GAO`, `HAU_BI`. | N/A |

---

###### 1.6. Tab 6: Form Ca Làm Việc Chuẩn (`work_shifts` #52 - `WorkShiftFormModal`)
Màn hình cấu hình khung giờ làm việc, thời gian nghỉ giữa ca, và biên độ ân hạn đi trễ dùng cho thuật toán tính công chấm công GPS/Selfie.

| Tên Trường Giao Diện (Label) | Biến DDL / DTO | Kiểu Ô Nhập (Control Type) | Bắt Buộc | Quy Chuẩn Dữ Liệu & Ràng Buộc Validation | Thông Báo Lỗi Khi Vi Phạm (Error Message) |
| :--- | :--- | :--- | :---: | :--- | :--- |
| **Phạm vi áp dụng ca** | `farm_id` | **Nút chuyển chọn Radio (Radio Group Switch)** | Có | 2 tùy chọn: `🔘 Dùng chung toàn doanh nghiệp` (`farm_id = NULL`) hoặc `🔘 Riêng trang trại hiện tại` (`farm_id = :currentFarmId`). | *"Vui lòng chọn phạm vi áp dụng ca làm việc"* |
| **Mã ca làm việc** | `shift_code` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 50 ký tự; tự động viết hoa; Pattern: `^[A-Z0-9_-]{2,50}$`. Unique theo `tenant_id`. Placeholder: *"VD: CA-SANG-01"* | *"Mã ca làm việc đã tồn tại trong doanh nghiệp"* |
| **Tên ca làm việc** | `name` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 100 ký tự; không để trống. Placeholder: *"VD: Ca Sáng Nông Vụ (07:00 - 16:00)"* | *"Tên ca làm việc không được để trống"* |
| **Giờ bắt đầu ca** | `start_time` | **Ô chọn thời gian (TimePicker - HH:mm:ss)** | Có | Định dạng 24h. Bước nhảy: 15 phút. Placeholder: *"07:00:00"* | *"Vui lòng chọn giờ bắt đầu ca làm việc"* |
| **Giờ kết thúc ca** | `end_time` | **Ô chọn thời gian (TimePicker - HH:mm:ss)** | Có | Định dạng 24h. Nếu không bật ca qua đêm: Bắt buộc `end_time > start_time`. Placeholder: *"16:00:00"* | *"Giờ kết thúc ca phải sau giờ bắt đầu (trừ ca qua đêm)"* |
| **Thời gian nghỉ giữa ca** | `break_minutes` | **Ô nhập số nguyên (Number Input - Integer)** | Có | Đơn vị: phút. Min: 0; Max: 240; Mặc định: 60. Validation: `break_minutes >= 0`. Trừ trực tiếp khi tính giờ công. | *"Số phút nghỉ giải lao không được âm"* |
| **Số phút ân hạn đi trễ** | `grace_late_minutes` | **Ô nhập số nguyên (Number Input - Integer)** | Có | Đơn vị: phút. Min: 0; Max: 60; Mặc định: 15. Check-in sau (start_time + grace) mới bị tính trễ. | *"Số phút ân hạn đi trễ không được âm"* |
| **Ca làm việc qua đêm** | `is_overnight` | **Công tắc gạt (Checkbox / Switch)** | Có | Mặc định: FALSE. Khi bật TRUE: Cho phép `end_time <= start_time` (kết thúc sáng hôm sau). Thuật toán cộng 24h khi tính tổng giờ. | N/A |
| **Tổng giờ công danh định** | N/A (Computed) | **Ô chỉ đọc (Read-only Badge)** | N/A | Tự động tính toán theo công thức: $\text{Working Hours} = \frac{(\text{end\_time} - \text{start\_time}) - \text{break\_minutes}}{60}$. | N/A |

---

###### 1.7. Tab 7: Form Nhóm Chi Phí Kế Toán (`cost_categories` #59 - `CostCategoryFormModal`)
Màn hình quản lý các nhóm khoản mục chi phí giá thành dùng cho việc hạch toán chi phí phát sinh, dự toán ngân sách và phân bổ giá thành nông vụ.

| Tên Trường Giao Diện (Label) | Biến DDL / DTO | Kiểu Ô Nhập (Control Type) | Bắt Buộc | Quy Chuẩn Dữ Liệu & Ràng Buộc Validation | Thông Báo Lỗi Khi Vi Phạm (Error Message) |
| :--- | :--- | :--- | :---: | :--- | :--- |
| **Mã nhóm chi phí** | `code` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 50 ký tự; tự động viết hoa; Pattern: `^[A-Z0-9_-]{2,50}$`. Unique toàn tenant `uk_cost_categories_code (tenant_id, code)`. Placeholder: *"VD: CP-VT-01, CP-NC-01"* | *"Mã nhóm chi phí đã tồn tại trong doanh nghiệp"* |
| **Tên nhóm chi phí** | `name` | **Ô nhập chuỗi (Input Text)** | Có | Tối đa 150 ký tự; không để trống. Placeholder: *"VD: Chi phí Phân bón & Thuốc BVTV"* | *"Tên nhóm chi phí không được để trống"* |
| **Phân loại chi phí** | `cost_type` | **Ô chọn Dropdown (Single Select)** | Có | 5 giá trị chuẩn từ SQL `chk_cost_categories_type`: `MATERIALS` (Chi phí nguyên vật liệu trực tiếp), `DIRECT_LABOR` (Chi phí nhân công trực tiếp), `MACHINERY_FUEL` (Chi phí máy móc & nhiên liệu), `DEPRECIATION` (Chi phí khấu hao tài sản), `INDIRECT_OVERHEAD` (Chi phí quản lý & sản xuất chung). | *"Vui lòng chọn phân loại chi phí hợp lệ"* |

---

#### 2. Trung Tâm Báo Cáo Điều Hành & Tài Chính (`/app/reports`):
*   *Thanh bộ lọc toàn cục:* Chọn Trang trại, Chọn Chu kỳ sản xuất / Năm tài chính, Chọn khoảng thời gian Từ ngày - Đến ngày.
*   *5 Báo cáo điều hành chuyên sâu:*
    1.  **Executive KPI Dashboard:** Biểu đồ doanh thu bán hàng, chi phí lũy kế, lợi nhuận gộp và tỷ lệ hoàn thành kế hoạch sản lượng.
    2.  **Báo cáo Tuổi Thọ Tồn Kho (Inventory Aging):** Thống kê số lượng và giá trị tồn kho theo các nhóm tuổi hàng (0-30 ngày, 31-60 ngày, 61-90 ngày, >90 ngày), danh sách cảnh báo các lô cận hạn sử dụng (`expiry_alert_days`).
    3.  **Báo cáo Giá Thành & Lợi Nhuận Từng Vụ Mùa (Crop P&L Report):** Bảng so sánh chi tiết giữa Dự toán chi phí $\leftrightarrow$ Chi phí thực tế $\leftrightarrow$ Giá thành thực tế / kg $\leftrightarrow$ Doanh thu bán hàng thực tế $\leftrightarrow$ Lợi nhuận gộp từng mùa vụ.
    4.  **Báo cáo Chỉ Số Tiêu Tốn Thức Ăn FCR & Nuôi Sống (Livestock FCR Report):** Phân tích hệ số FCR theo từng lứa nuôi, đối chiếu với định mức kỹ thuật chuẩn để đánh giá tay nghề chăn nuôi.
    5.  **Báo cáo Phân Tích Tuổi Nợ Khách Hàng (Debt Aging Report):** Phân tích các khoản nợ phải thu theo các nhóm nợ trong hạn và quá hạn (1-30 ngày, 31-60 ngày, >90 ngày), gắn nhãn rủi ro nợ xấu.
*   *Nút bấm xuất file:*
    *   Nút `[ 📊 Xuất File Excel (.xlsx) ]`: Gọi API sinh file Excel đa sheet có định dạng màu, logo công ty và công thức tính.
    *   Nút `[ 📄 Xuất Bản In Báo Cáo PDF ]`: Mở cửa sổ in PDF chuẩn A4 ngang có chữ ký của Kế toán trưởng và Chủ trang trại.

#### 3. Màn Hình Quản Trị Hệ Thống & Kiểm Toán (`/app/system`):
*   *Bảng Tra Cứu Nhật Ký Kiểm Toán Bất Biến (`audit_logs` #10):*
    *   Hiển thị các cột chuẩn khớp 100% SQL (#10): `created_at`, `module`, `action`, `endpoint`, `method`, `status_code`, `ip_address`, `old_value`, `new_value`.
    *   *Bảo vệ bất biến:* Màn hình này là **READ-ONLY 100%**, tuyệt đối không có nút Thêm, Sửa hoặc Xóa để đảm bảo tính khách quan trước pháp luật.
    *   *Drawer So Sánh Biến Động (Diff Inspector):* Bấm vào từng dòng nhật ký sẽ mở Drawer hiển thị bảng so sánh trực quan từng trường dữ liệu thay đổi: Cột bên trái hiển thị giá trị cũ `old_value` (bôi đỏ), cột bên phải hiển thị giá trị mới `new_value` (bôi xanh).

#### 4. Platform Shell (`/platform/*` - Dành Riêng Cho `ROLE_SUPER_ADMIN`):
*   *Màn hình Quản Lý Khách Thuê SaaS (`/platform/tenants`):*
    *   Danh sách toàn bộ các doanh nghiệp / hợp tác xã thuê nền tảng trên toàn quốc, trạng thái gói cước, số lượng trang trại và người dùng hiện tại so với hạn mức gói.
    *   Nút `[ Nâng Cấp Gói Thuê Bao ]`: Mở modal cho phép gia hạn gói, nâng cấp loại gói (`FREE`, `STARTER`, `PROFESSIONAL`, `ENTERPRISE`), thay đổi `max_farms` và `max_users`.
    *   Nút `[ Khóa Khách Thuê Khẩn Cấp ]`: Chuyển trạng thái sang `SUSPENDED`, hệ thống ngay lập tức thu hồi toàn bộ token đăng nhập của người dùng thuộc tenant đó và chặn mọi yêu cầu API.

#### 5. Cổng Tra Cứu QR Nguồn Gốc Nông Sản Công Khai (`/trace/:code`):
*   *Đặc tả trải nghiệm người tiêu dùng:*
    *   Giao diện Web siêu nhẹ, tối ưu hóa 100% cho điện thoại di động khi người tiêu dùng quét mã QR dán trên quả xoài, con gà, túi gạo bằng Zalo hoặc Camera điện thoại.
    *   Đọc dữ liệu tức thì từ bản chụp bất biến `traceability_snapshots` (#49), hiển thị thông tin trang trại sản xuất, chứng nhận VietGAP (kèm số hiệu và ngày hết hạn), dòng thời gian canh tác (ngày xuống giống, ngày thu hoạch, cam kết không tồn dư hóa chất độc hại), kết quả kiểm định KCS và thông tin xuất xưởng.
    *   Hiển thị thông báo cảnh báo màu đỏ to toàn màn hình nếu lô hàng đã bị phát lệnh thu hồi khẩn cấp (`is_recalled = TRUE`).
    *   Tự động tăng biến đếm số lượt quét `scan_count` để nhà vườn nắm được mức độ quan tâm của thị trường đối với sản phẩm.

---

*Văn kiện `SPEC-UI-SCREEN-009` là bản vẽ thi công chính xác đến từng thuộc tính, giúp đội ngũ Frontend lập trình chính xác 100% không cần hỏi lại Backend.*
