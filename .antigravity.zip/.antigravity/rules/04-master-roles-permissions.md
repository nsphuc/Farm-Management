# MA TRẬN PHÂN QUYỀN 4 CẤP & PHẠM VI DỮ LIỆU AGRI-ERP
## (MASTER 4-TIER ROLES, PERMISSIONS & DATA SCOPE MATRIX)

> **Mã văn kiện:** `SPEC-RBAC-004`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Ràng Buộc Kiểm Soát Truy Cập Dựa Trên Vai Trò (RBAC) Toàn Diện Cho Tầng Application & Security.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` & `V1_4__standardize_4_tier_rbac_matrix.sql` (Chuẩn MySQL 8.x InnoDB).  
> **Tôn chỉ:** *"Đặc quyền tối thiểu (Least Privilege) - Phân tách nhiệm vụ Maker-Checker (Separation of Duties) - Bảo vệ ranh giới đa trang trại (The Farm Barrier Guard) - Tuyển dụng theo cấp bậc (Hierarchical Recruitment Guard)"*.

---

## 1. MA TRẬN TỔNG THỂ 7 VAI TRÒ VÀ 30 QUYỀN HẠN (7 ROLES X 30 PERMISSIONS)

Toàn bộ 7 vai trò được chia thành **4 Cấp bậc (4-Tier Hierarchy)** với 30 mã quyền hạn chuẩn xác theo Flyway Migration `V1_4__standardize_4_tier_rbac_matrix.sql`:

*   **Cấp 1 (`SYSTEM` Scope):** `ROLE_SUPER_ADMIN` (1 quyền: `PERM_TENANT_MANAGE`).
*   **Cấp 2 (`TENANT` Scope):** `ROLE_FARM_OWNER` (12 quyền: Giám sát toàn chuỗi, độc quyền tạo trang trại, duyệt ngân sách & phê duyệt cấp cao).
*   **Cấp 3 (`FARM` Scope):** `ROLE_FARM_MANAGER` (25 quyền: Điều hành toàn diện cơ sở, tuyển Cấp 4, đóng vai trò **Checker** phê duyệt kho, kế toán, mùa vụ, KCS).
*   **Cấp 4 (`FARM` Scope):** 4 vai trò chuyên môn thực thi (**Maker**):
    *   `ROLE_TECHNICAL_STAFF` (11 quyền: Lên lịch mùa vụ, phác đồ thú y, lấy mẫu KCS - Maker, giao việc kỹ thuật).
    *   `ROLE_WAREHOUSE_STAFF` (10 quyền: Quản lý tồn kho, lập phiếu nhập/xuất/chuyển/kiểm kê - Maker, in tem QR, xuất xe giao hàng).
    *   `ROLE_ACCOUNTANT` (8 quyền - Scope FARM: Đối chiếu tồn kho, lập phiếu chi, đơn bán sỉ, phiếu thanh toán - Maker, phân bổ công nợ và lập báo cáo trại).
    *   `ROLE_FIELD_STAFF` (6 quyền: Xem lịch, nhập nhật ký canh tác, ghi sản lượng thu hoạch, chấm công).

### Bảng Ma Trận Phân Quyền Chi Tiết:

| STT | Mã Quyền Hạn (`permissions.code`) | Phân Hệ (`module`) | Cấp 1: `SUPER_ADMIN` | Cấp 2: `FARM_OWNER` | Cấp 3: `FARM_MANAGER` | Cấp 4: `TECHNICAL_STAFF` | Cấp 4: `WAREHOUSE_STAFF` | Cấp 4: `ACCOUNTANT` | Cấp 4: `FIELD_STAFF` |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Phạm vi mặc định (`scope_level`)** | | | **SYSTEM** | **TENANT** | **FARM** | **FARM** | **FARM** | **FARM** | **FARM** |
| 1 | `PERM_TENANT_MANAGE` | SYSTEM | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| 2 | `PERM_FARM_CREATE` | FARM | ❌ | ✅ *(Độc quyền)* | ❌ | ❌ | ❌ | ❌ | ❌ |
| 3 | `PERM_FARM_VIEW` | FARM | ❌ | ✅ *(Toàn chuỗi)* | ✅ *(Trại phụ trách)*| ✅ | ✅ | ✅ | ✅ |
| 4 | `PERM_FARM_UPDATE` | FARM | ❌ | ✅ *(Cấu hình chung)*| ✅ *(Vận hành trại)*| ❌ | ❌ | ❌ | ❌ |
| 5 | `PERM_ZONE_MANAGE` | FARM | ❌ | ✅ *(Duyệt/Quản lý)* | ✅ *(Khu & Ô/Luống)* | ❌ | ❌ | ❌ | ❌ |
| 6 | `PERM_CROP_VIEW` | CROP | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ |
| 7 | `PERM_CROP_PLAN` | CROP | ❌ | ❌ | ✅ *(Checker: Duyệt)*| ✅ *(Maker: Lập lịch)* | ❌ | ❌ | ❌ |
| 8 | `PERM_CROP_LOG` | CROP | ❌ | ❌ | ✅ *(Kiểm tra/Giám sát)*| ❌ | ❌ | ❌ | ✅ *(Maker: Ghi log)*|
| 9 | `PERM_LIVESTOCK_VIEW` | LIVESTOCK | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ |
| 10 | `PERM_LIVESTOCK_MANAGE` | LIVESTOCK | ❌ | ❌ | ✅ *(Checker: Duyệt đàn)*| ✅ *(Maker: Lập KH)*| ❌ | ❌ | ❌ |
| 11 | `PERM_LIVESTOCK_VET` | LIVESTOCK | ❌ | ❌ | ❌ | ✅ *(Độc quyền khám/đơn)*| ❌ | ❌ | ❌ |
| 12 | `PERM_INVENTORY_VIEW` | INVENTORY | ❌ | ✅ *(Giám sát chuỗi)*| ✅ *(Giám sát kho)* | ✅ *(Xem vật tư)* | ✅ *(Quản lý tồn kho)*| ✅ *(Đối chiếu sổ)*| ❌ |
| 13 | `PERM_INVENTORY_RECEIPT` | INVENTORY | ❌ | ❌ | ✅ *(Checker: Duyệt)* | ❌ | ✅ *(Maker: Tạo phiếu)*| ❌ | ❌ |
| 14 | `PERM_INVENTORY_ISSUE` | INVENTORY | ❌ | ❌ | ✅ *(Checker: Duyệt)* | ❌ | ✅ *(Maker: Tạo phiếu)*| ❌ | ❌ |
| 15 | `PERM_INVENTORY_TRANSFER` | INVENTORY | ❌ | ❌ | ✅ *(Checker: Duyệt)* | ❌ | ✅ *(Maker: Tạo yêu cầu)*| ❌ | ❌ |
| 16 | `PERM_INVENTORY_STOCKTAKE` | INVENTORY | ❌ | ❌ | ✅ *(Checker: Duyệt)* | ❌ | ✅ *(Maker: Kiểm đếm)*| ❌ | ❌ |
| 17 | `PERM_HARVEST_MANAGE` | HARVEST | ❌ | ❌ | ✅ *(Checker: Duyệt)* | ✅ *(Đánh giá giống)*| ✅ *(Nhập kho nông sản)*| ❌ | ✅ *(Maker: Ghi SL)*|
| 18 | `PERM_QC_INSPECT` | QC | ❌ | ❌ | ❌ *(CẤM TỰ DUYỆT)* | ✅ *(Maker: Lấy mẫu/KCS)*| ❌ | ❌ | ❌ |
| 19 | `PERM_QC_APPROVE` | QC | ❌ | ✅ *(Duyệt cấp cao)* | ✅ *(Checker: Duyệt lô)* | ❌ *(CẤM)* | ❌ | ❌ | ❌ |
| 20 | `PERM_LABEL_PRINT` | QC | ❌ | ❌ | ❌ | ❌ | ✅ *(Độc quyền in tem)*| ❌ | ❌ |
| 21 | `PERM_QC_RECALL` | QC | ❌ | ✅ *(Lệnh thu hồi cấp cao)*| ✅ *(Lệnh thu hồi trại)*| ❌ | ❌ | ❌ | ❌ |
| 22 | `PERM_DELIVERY_MANAGE` | DELIVERY | ❌ | ❌ | ✅ *(Giám sát giao xe)*| ❌ | ✅ *(Maker: Xuất xe)*| ❌ | ❌ |
| 23 | `PERM_HR_EMPLOYEE_MANAGE` | HR | ❌ | ✅ *(Tuyển Cấp 3: FM)* | ✅ *(Tuyển Cấp 4 tại trại)*| ❌ | ❌ | ❌ | ❌ |
| 24 | `PERM_HR_ATTENDANCE` | HR | ❌ | ✅ *(Xem tổng hợp chuỗi)*| ✅ *(Chấm & Duyệt công trại)*| ✅ *(Chấm & Điểm danh tổ)*| ✅ *(Chấm & Điểm danh kho)*| ✅ *(Chấm & Xem công chốt)*| ✅ *(Chấm GPS cá nhân)*|
| 25 | `PERM_TASK_ASSIGN` | HR | ❌ | ❌ | ✅ *(Giao & Nghiệm thu)*| ✅ *(Giao việc kỹ thuật)*| ❌ | ❌ | ❌ |
| 26 | `PERM_FINANCE_EXPENSE` | FINANCE | ❌ | ❌ | ✅ *(Checker: Duyệt chi)*| ❌ | ❌ | ✅ *(Maker: Lập phiếu chi)*| ❌ |
| 27 | `PERM_FINANCE_SALES_ORDER` | FINANCE | ❌ | ❌ | ✅ *(Checker: Duyệt bán)*| ❌ | ❌ | ✅ *(Maker: Lên đơn sỉ)*| ❌ |
| 28 | `PERM_FINANCE_PAYMENT` | FINANCE | ❌ | ❌ | ✅ *(Checker: Duyệt TT)*| ❌ | ❌ | ✅ *(Maker: Lập phiếu TT)*| ❌ |
| 29 | `PERM_PAYMENT_ALLOCATE` | FINANCE | ❌ | ❌ | ✅ *(Giám sát công nợ)*| ❌ | ❌ | ✅ *(Cấn trừ công nợ)*| ❌ |
| 30 | `PERM_FINANCE_REPORT` | FINANCE | ❌ | ✅ *(Báo cáo toàn chuỗi)*| ✅ *(Duyệt báo cáo trại)*| ❌ | ❌ | ✅ *(Lập báo cáo trại)*| ❌ |
| **TỔNG SỐ QUYỀN HẠN** | | | **1** | **12** | **25** | **11** | **10** | **8** | **6** |

---

## 2. NGUYÊN TẮC PHÂN TÁCH MAKER - CHECKER & BẢO MẬT ĐẶC BIỆT

### 2.1. Cơ Chế Maker - Checker Khi Có Chung Mã Quyền
Hệ thống Agri-ERP tuân thủ chặt chẽ mô hình phân chia trách nhiệm kép giữa Cấp 4 (Maker - Người lập) và Cấp 3 (Checker - Người duyệt):
1.  **Kho Vận (`module: INVENTORY`):**
    *   **Maker (`ROLE_WAREHOUSE_STAFF`):** Được quyền tạo chứng từ ở trạng thái `DRAFT` / `PENDING_APPROVAL` (Nhập kho, Xuất kho, Chuyển kho, Kiểm kê). Cấp 2 (`ROLE_FARM_OWNER`) và Cấp 1 không làm Maker lập chứng từ kho bãi.
    *   **Checker (`ROLE_FARM_MANAGER`):** Thẩm định số liệu thực tế, ký duyệt trạng thái `APPROVED` / `POSTED` để ghi nhận biến động thẻ kho và cập nhật số lượng tồn khả dụng (`available_quantity`).
2.  **Tài Chính (`module: FINANCE`):**
    *   **Maker (`ROLE_ACCOUNTANT`):** Nhập liệu hóa đơn, chứng từ chi tiêu, đơn bán sỉ và lập lệnh chuyển khoản / QR Code trạng thái `DRAFT`.
    *   **Checker (`ROLE_FARM_MANAGER`):** Phê duyệt phiếu chi dưới hạn mức trang trại, ký duyệt xuất kho bán sỉ và đối chiếu phiếu thanh toán.
    *   **Owner (`ROLE_FARM_OWNER`):** Phê duyệt hạn mức công nợ (`creditLimit`) lớn, khóa đen đối tác (`BLACKLISTED`) và ký xác nhận kết toán chu kỳ (`Cycle Settlement`). Owner không làm Maker lập phiếu chi hay đơn bán sỉ.
3.  **Mùa Vụ & Chăn Nuôi (`modules: CROP, LIVESTOCK`):**
    *   **Maker (`ROLE_TECHNICAL_STAFF`):** Xây dựng phác đồ dinh dưỡng, kế hoạch xuống giống, quy trình chăm sóc đàn ở trạng thái `PLANNING` / `DRAFT`.
    *   **Checker (`ROLE_FARM_MANAGER`):** Phê duyệt khởi động mùa vụ (`ACTIVE`), cấp phát nguồn lực và vật tư.

### 2.2. Phân Tách Maker-Checker Trong Kiểm Định Chất Lượng (QA/QC Separation)
*   **Maker (`ROLE_TECHNICAL_STAFF`):** Độc quyền lấy mẫu hiện trường và lập biên bản KCS (`PERM_QC_INSPECT`). Bắt buộc ghi nhận `qc_inspections.inspector_user_id`.
*   **Checker (`ROLE_FARM_MANAGER` & `ROLE_FARM_OWNER`):** Có quyền phê duyệt lô xuất xưởng (`PERM_QC_APPROVE`) và quyền thu hồi khẩn cấp (`PERM_QC_RECALL`).
*   **CHỐT CHẶN BẢO MẬT BẮT BUỘC:** `ROLE_TECHNICAL_STAFF` **TUYỆT ĐỐI CẤM** có quyền `PERM_QC_APPROVE` và `PERM_QC_RECALL`.
*   **Luật Chống Tự Duyệt (Self-Approval Immunity):** Tại tầng Service, kể cả khi một tài khoản có vai trò `ROLE_FARM_MANAGER` hoặc `ROLE_FARM_OWNER`, nếu tài khoản đó chính là người lập biên bản kiểm định (`qc_inspections.inspector_user_id == currentUserId`), Backend **BẮT BUỘC TỪ CHỐI** quyền phê duyệt lô bằng lỗi `403 Forbidden - Self-Approval Not Allowed`. Bắt buộc phải do một người quản lý khác phê duyệt độc lập.

### 2.3. Quy Định Chấm Công & Điểm Danh (HR Attendance Guard)
*   `ROLE_FIELD_STAFF`: Chấm công cá nhân thông qua GPS trên thiết bị di động (Bán kính hợp lệ <= `geofence_radius_m` so với tọa độ tâm trang trại).
*   `ROLE_TECHNICAL_STAFF` & `ROLE_WAREHOUSE_STAFF`: Chấm công cá nhân GPS, đồng thời được cấp quyền **Điểm danh tổ / Điểm danh kho** (`batch roll-call`) cho nhóm lao động thời vụ (Loại 6B không có tài khoản SaaS) bằng hình ảnh hiện trường và tọa độ GPS (hoặc thông qua `role_in_farm` như `ZONE_MANAGER`, `TECHNICAL_LEAD`).
*   `ROLE_ACCOUNTANT`: Tự chấm công cá nhân; chỉ được xem báo cáo bảng công tổng hợp **đã được Farm Manager chốt duyệt** để làm căn cứ tính lương, cấm can thiệp nhật ký GPS trực tiếp của nhân sự khác.
*   `ROLE_FARM_MANAGER`: Duyệt bảng chấm công cuối kỳ toàn trang trại.
*   `ROLE_FARM_OWNER`: Xem báo cáo chuyên cần và chi phí nhân sự tổng hợp toàn chuỗi.

---

## 3. QUY TẮC GÁN ROLE THEO PHẠM VI DỮ LIỆU (DATA SCOPE LEVELING)

Cấu trúc phân quyền Agri-ERP kết hợp chặt chẽ giữa Vai trò Nghiệp vụ (Role) và Ranh giới Không gian (Scope) thông qua bảng `user_roles` và `user_farm_access`:

```mermaid
graph TD
    subgraph "PHÂN BỔ QUYỀN 4 CẤP THEO PHẠM VI DỮ LIỆU"
        U[users: Tài Khoản Người Dùng] --> UR[user_roles: Bảng Gán Vai Trò]
        UR -->|Cấp 1: scope_level = SYSTEM| S1[Super Admin: Toàn Hệ Thống - tenant_id = NULL, farm_id = NULL]
        UR -->|Cấp 2: scope_level = TENANT| S2[Farm Owner: Cấp Tenant - Toàn Chuỗi Trang Trại, farm_id = NULL]
        UR -->|Cấp 3: scope_level = FARM| S3[Farm Manager: Quản Lý Trang Trại - farm_id BẮT BUỘC]
        UR -->|Cấp 4: scope_level = FARM| S4[Tech / Warehouse / Accountant / Field: farm_id BẮT BUỘC]
        S3 -.->|Đồng Bộ Bắt Buộc| UFA[user_farm_access: Danh Sách Trang Trại Được Cấp Phép]
        S4 -.->|Đồng Bộ Bắt Buộc| UFA
    end
```

### 3.1. Cấp 1: Vai trò Quản trị Nền tảng (`SYSTEM` Scope)
*   Áp dụng cho: `ROLE_SUPER_ADMIN`.
*   Cột `user_roles.tenant_id`: Bắt buộc là `NULL`.
*   Cột `user_roles.farm_id`: Bắt buộc là `NULL`.
*   Ràng buộc SQL: `chk_users_super_admin_tenant: (is_super_admin = TRUE AND tenant_id IS NULL)`.
*   Phạm vi: Quản lý đăng ký thuê bao nền tảng (`tenants`, `tenant_subscriptions`), xem nhật ký `audit_logs`. Không được truy cập dữ liệu nghiệp vụ sản xuất nội bộ của khách hàng nếu không có token ủy quyền kỹ thuật có kiểm toán.

### 3.2. Cấp 2: Vai trò Chủ Doanh nghiệp / Chuỗi Trang trại (`TENANT` Scope)
*   Áp dụng cho: `ROLE_FARM_OWNER`.
*   Cột `user_roles.tenant_id`: Bắt buộc mang ID của Tenant (`tenant_id NOT NULL`).
*   Cột `user_roles.farm_id`: **BẮT BUỘC ĐỂ `NULL`**.
*   Phạm vi tác nghiệp: Được quyền truy cập **TẤT CẢ CÁC TRANG TRẠI** thuộc tenant đó. Độc quyền tạo mới trang trại (`PERM_FARM_CREATE`), bổ nhiệm Giám đốc trang trại (`ROLE_FARM_MANAGER`), duyệt ngân sách đầu tư và nhận báo cáo kết toán tổng hợp chuỗi.

### 3.3. Cấp 3: Vai trò Giám đốc / Quản lý Trang trại (`FARM` Scope)
*   Áp dụng cho: `ROLE_FARM_MANAGER`.
*   Cột `user_roles.tenant_id`: Bắt buộc mang ID Tenant (`tenant_id NOT NULL`).
*   Cột `user_roles.farm_id`: **BẮT BUỘC KHÁC `NULL`**, phải là ID của Trang trại được giao điều hành.
*   Ràng buộc: Bảng `farms.manager_user_id` liên kết với người dùng này.
*   Phạm vi: Toàn quyền điều hành cơ sở tại trang trại được phân công; tuyển dụng và quản lý nhân viên Cấp 4 tại trang trại đó; giữ vai trò Checker phê duyệt mọi chứng từ nghiệp vụ phát sinh tại trại.

### 3.4. Cấp 4: Vai trò Chuyên môn Thực thi (`FARM` Scope)
*   Áp dụng cho: `ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_ACCOUNTANT`, `ROLE_FIELD_STAFF`.
*   Cột `user_roles.tenant_id`: Bắt buộc mang ID Tenant (`tenant_id NOT NULL`).
*   Cột `user_roles.farm_id`: **BẮT BUỘC KHÁC `NULL`**, phải là ID của Trang trại cụ thể được phân công.
*   **QUY TẮC ĐỒNG BỘ HAI TẦNG:** Khi gán một vai trò cấp Farm cho nhân viên, Backend **BẮT BUỘC PHẢI GHI ĐỒNG THỜI** vào cả 2 bảng trong cùng một transaction:
    1.  Ghi vào `user_roles` với cặp `(tenant_id, user_id, role_id, farm_id)`.
    2.  Ghi vào `user_farm_access` với bộ `(user_id, farm_id, tenant_id)`.
*   Nhân viên Cấp 4 chỉ được truy xuất dữ liệu trong phạm vi `farm_id` được phân công. Mọi truy vấn sang trại khác đều bị chặn bởi `HTTP 403 Forbidden`.

---

## 4. QUY TẮC CHỐNG LEO THANG ĐẶC QUYỀN & ỦY QUYỀN CẤP TÀI KHOẢN THÁC ĐỔ
### (CASCADING ACCOUNT PROVISIONING & HIERARCHICAL RECRUITMENT GUARD)

Cơ chế phân quyền quản trị tài khoản được thực thi nghiêm ngặt theo mô hình Thác Đổ 4 Cấp (Cascading Waterfall: Cấp 1 $\rightarrow$ Cấp 2 $\rightarrow$ Cấp 3 $\rightarrow$ Cấp 4), triệt tiêu hoàn toàn lỗ hổng leo thang đặc quyền (Privilege Escalation):

```mermaid
graph TD
    classDef l1 fill:#b91c1c,stroke:#7f1d1d,stroke-width:2px,color:#fff;
    classDef l2 fill:#d97706,stroke:#92400e,stroke-width:2px,color:#fff;
    classDef l3 fill:#059669,stroke:#065f46,stroke-width:2px,color:#fff;
    classDef l4 fill:#2563eb,stroke:#1e40af,stroke-width:2px,color:#fff;

    T1["CẤP 1: ROLE_SUPER_ADMIN (SYSTEM Scope)<br/>Khởi tạo Tenant & Cấp tài khoản Cấp 2"]:::l1
    T2["CẤP 2: ROLE_FARM_OWNER (TENANT Scope)<br/>Tạo Trang trại & Bổ nhiệm Giám đốc Cấp 3"]:::l2
    T3["CẤP 3: ROLE_FARM_MANAGER (FARM Scope)<br/>Quản trị trại & Tuyển dụng/Phân quyền Cấp 4"]:::l3
    T4["CẤP 4: TECHNICAL / WAREHOUSE / ACCOUNTANT / FIELD<br/>Nhân sự chuyên môn tác nghiệp tại trại"]:::l4

    T1 -->|1. Cấp tài khoản ban đầu| T2
    T2 -->|2. Bổ nhiệm & gán farm_id| T3
    T3 -->|3. Tuyển dụng vào farm_id phụ trách| T4
```

1.  **Cấp 1 (`ROLE_SUPER_ADMIN`):**
    *   Chỉ `ROLE_SUPER_ADMIN` mới có quyền tạo Tenant (`tenants`) và tài khoản `ROLE_FARM_OWNER` ban đầu cho Tenant đó.
    *   Không tự ý can thiệp tạo tài khoản nội bộ cho trang trại.
2.  **Cấp 2 (`ROLE_FARM_OWNER`):**
    *   Chỉ được tạo và bổ nhiệm nhân sự Cấp 3 (`ROLE_FARM_MANAGER`) cho các trang trại thuộc sở hữu của mình (`manager_user_id` trong `farms`).
    *   Cấp 2 không can thiệp trực tiếp vào việc phân quyền nhân viên tác nghiệp chi tiết tại từng trại.
3.  **Cấp 3 (`ROLE_FARM_MANAGER`):**
    *   Chỉ được tuyển dụng, tạo tài khoản và phân quyền cho nhân sự Cấp 4 (`ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_ACCOUNTANT`, `ROLE_FIELD_STAFF`) thuộc đúng `farm_id` mà mình đang quản lý.
    *   Đồng bộ song song vào 2 bảng `user_roles` và `user_farm_access`.
    *   **CHỐT CHẶN CẤM:** Cấp 3 **TUYỆT ĐỐI KHÔNG ĐƯỢC** gán role `ROLE_FARM_OWNER` hoặc gán role `ROLE_FARM_MANAGER` cho bất kỳ ai, và không được tạo nhân sự sang `farm_id` khác.
4.  **Quy tắc Chống Tự Tăng Quyền (No Self-Elevation):**
    *   Người dùng không thể tự gán thêm quyền cho chính mình hoặc nâng vai trò của bản thân lên cấp cao hơn.

---

## 5. MÔ HÌNH TRIỂN KHAI CODE BACKEND (SPRING SECURITY ARCHITECTURE)

### 5.1. Cấu trúc Custom Security Expressions
Toàn bộ Controller và Service của hệ thống áp dụng kiểm tra quyền hạn kết hợp: **Mã quyền nghiệp vụ (Permission)** và **Phạm vi Trang trại (The Farm Barrier Guard)**:

```java
// Ví dụ 1: Endpoint cấp Tenant (Chỉ Farm Owner - Scope TENANT)
@PreAuthorize("hasAuthority('PERM_FARM_CREATE')")
@PostMapping("/api/v1/farms")
public ResponseEntity<FarmResponse> createFarm(@Valid @RequestBody FarmCreateRequest request) { ... }

// Ví dụ 2: Endpoint cấp Farm (Kiểm tra Permission & Quyền truy cập Farm cụ thể)
@PreAuthorize("hasAuthority('PERM_INVENTORY_RECEIPT') and @farmSecurity.canAccessFarm(#farmId)")
@PostMapping("/api/v1/farms/{farmId}/inventory/receipts")
public ResponseEntity<ReceiptResponse> createReceipt(
        @PathVariable Long farmId, 
        @Valid @RequestBody ReceiptCreateRequest request) { ... }

// Ví dụ 3: Endpoint duyệt KCS (Kiểm tra Checker & Maker-Checker độc lập)
@PreAuthorize("hasAuthority('PERM_QC_APPROVE') and @farmSecurity.canApproveBatch(#farmId, #batchId)")
@PostMapping("/api/v1/farms/{farmId}/product-batches/{batchId}/approve")
public ResponseEntity<BatchApprovalResponse> approveBatch(
        @PathVariable Long farmId, 
        @PathVariable Long batchId) { ... }
```

### 5.2. Cài đặt Component `FarmSecurityEvaluator`
```java
@Component("farmSecurity")
@RequiredArgsConstructor
public class FarmSecurityEvaluator {

    public boolean canAccessFarm(Long farmId) {
        CustomUserDetails user = SecurityUtils.getCurrentUser();
        if (user.isSuperAdmin()) return true;
        
        // Kiểm tra cùng tenant
        if (!user.getTenantId().equals(SecurityUtils.resolveFarmTenantId(farmId))) {
            return false;
        }
        
        // Cấp 2: Farm Owner (Scope TENANT) -> Được phép truy cập mọi Farm trong Tenant
        if (user.hasRole("ROLE_FARM_OWNER")) {
            return true;
        }
        
        // Cấp 3 (Farm Manager) & Cấp 4 (Tech, Warehouse, Accountant, Field) -> Bắt buộc farmId thuộc user_farm_access
        return user.getAccessibleFarmIds().contains(farmId);
    }

    public boolean canApproveBatch(Long farmId, Long batchId) {
        if (!canAccessFarm(farmId)) return false;
        
        CustomUserDetails user = SecurityUtils.getCurrentUser();
        Long inspectorUserId = SecurityUtils.resolveBatchInspectorId(batchId);
        
        // Luật Maker-Checker: Người kiểm định (inspector) tuyệt đối không được tự phê duyệt
        if (user.getId().equals(inspectorUserId)) {
            throw new AccessDeniedException("Luật Maker-Checker: Người kiểm định không được tự phê duyệt kết quả kiểm định của chính mình");
        }
        return true;
    }
}
```

---
*Văn kiện `SPEC-RBAC-004` là Single Source of Truth điều chỉnh toàn bộ cấu hình Spring Security `@PreAuthorize` và Frontend Component `<Can permission="..." />`.*
