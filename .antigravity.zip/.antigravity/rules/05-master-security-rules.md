# HIẾN PHÁP BẢO MẬT, XÁC THỰC, CÔ LẬP DỮ LIỆU & CHỐT CHẶN MAKER-CHECKER
## (MASTER SECURITY CONSTITUTION, MULTI-TENANT ISOLATION & MAKER-CHECKER GUARDS)

> **Mã văn kiện:** `RULE-SEC-005`  
> **Cấp độ hiệu lực:** **TỐI CAO (SUPREME MANDATORY)** — Là Tấm Khiên An Ninh 4 Cấp Bắt Buộc Tuân Thủ Tuyệt Đối Bởi 100% Endpoints, Filters, Services và Query Dữ Liệu.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql`, `V1_1__add_farm_id_to_partners.sql` & `V1_4__standardize_4_tier_rbac_matrix.sql`.  
> **Tôn chỉ:** *"Không tin tưởng Client (Zero Trust) - Cô lập đa tenant và rào chắn Farm Barrier Guard (Defense-in-Depth) - Phân tách kiểm duyệt Maker-Checker - Tuyển dụng theo đúng cấp bậc"*.

---

## 1. MÔ HÌNH HÀNG RÀO AN NINH ĐA TẦNG (MULTI-LAYER SECURITY ARCHITECTURE)

```mermaid
graph TD
    subgraph "LỚP 1: QUẢN LÝ PHIÊN & ĐIỀU HƯỚNG TOKEN (SESSION & TOKEN SHIELD)"
        REQ[Client HTTP Request] --> SSL[TLS/HTTPS 1.3]
        SSL --> CF[CorsFilter & RateLimiter]
        CF --> JF[JwtAuthenticationFilter: In-Memory Access Token]
        JF --> RF[RefreshTokenRotation: HttpOnly Cookie & refresh_tokens #72]
        JF --> PF[PasswordChangeEnforcementFilter: Chặn mustChangePassword]
    end

    subgraph "LỚP 2: PHÂN CẤP 4 TẦNG & THE FARM BARRIER GUARD"
        PF --> SC[SecurityContextHolder: UserDetails, TenantId, AccessibleFarmIds, RoleScope]
        SC --> AN[Method Security: @PreAuthorize & FarmSecurityEvaluator]
        AN --> ORM[Data Scope Filter: Hibernate Filter / JPA Specification]
        ORM --> DB[(MySQL 8.x: Composite Keys tenant_id + farm_id)]
    end

    subgraph "LỚP 3: CHỐT CHẶN MAKER-CHECKER & TUYỂN DỤNG CẤP BẬC"
        AN --> MC[Maker-Checker Guard: Chống Tự Duyệt inspector != approver]
        AN --> HRG[Hierarchical Recruitment Guard: Owner -> FM -> Staff Cấp 4]
    end

    subgraph "LỚP 4: NHẬT KÝ KIỂM TOÁN BẤT ĐỒNG BỘ (AUDIT LOGGING SHIELD)"
        AN -.->|Spring ApplicationEvent| AP[AuditLogEventListener: @Async]
        AP --> AL[(audit_logs #10: IP, User-Agent, Old/New JSON)]
    end
```

---

## 2. LỚP 1: QUẢN LÝ PHIÊN & TOKEN (JWT + COOKIE SECURITY)

### 2.1. Cấu Trúc Hai Loại Token Độc Lập
1.  **Access Token (Thẻ thông hành ngắn hạn):**
    *   *Định dạng:* Chuẩn JWT, thuật toán ký `HMAC-SHA256` hoặc `RSA-256`.
    *   *Tuổi thọ:* Rất ngắn, từ **15 phút đến tối đa 30 phút**.
    *   *Lưu trữ Client:* **BẮT BUỘC LƯU IN-MEMORY** (trong React Context hoặc Zustand Store).
    *   **NGHIÊM CẤM TUYỆT ĐỐI:** Không lưu Access Token trong `localStorage` hoặc `sessionStorage` của trình duyệt.
    *   *Nội dung Claims:* `sub` (userId), `username`, `tenantId`, `isSuperAdmin`, `roles` (danh sách role code), `permissions` (danh sách mã quyền), `accessibleFarmIds` (mảng ID các farm được phép truy cập), `mustChangePassword` (boolean).
2.  **Refresh Token (Thẻ làm mới dài hạn có lưu vết Database):**
    *   *Định dạng:* Chuỗi ngẫu nhiên 64-128 ký tự mật mã bảo mật (`SecureRandom`).
    *   *Tuổi thọ:* Dài hạn, từ **7 ngày đến 30 ngày**.
    *   *Lưu trữ Server:* Bảng `refresh_tokens` (#72) gồm các cột: `user_id`, `token` (UNIQUE), `expires_at`, `revoked` (boolean), `revoked_at`, `replaced_by_token`, `created_by_ip`, `user_agent`.
    *   *Vận chuyển Client:* Đóng gói trong **`HttpOnly`, `Secure`, `SameSite=Strict` Cookie** tên là `refresh_token`.
3.  **Cơ chế Xoay Vòng Token (Sliding Refresh Token Rotation):**
    *   Khi Access Token hết hạn, Axios Interceptor tự động bắt mã lỗi `401 Unauthorized` và gọi ngầm `POST /api/v1/auth/refresh`.
    *   Nếu phát hiện Refresh Token đã bị thu hồi (`revoked == true`) nhưng vẫn được gửi lên: Hệ thống nhận diện là **Tấn công phát lại (Token Replay Attack)**, lập tức thu hồi toàn bộ phiên của người dùng (`UPDATE refresh_tokens SET revoked = TRUE WHERE user_id = :userId`) và ghi cảnh báo vào `audit_logs`.

### 2.2. Bộ Lọc Cưỡng Chế Đổi Mật Khẩu (Password Change Enforcement Filter)
*   Bảng `users` (#5) có cờ `must_change_password BOOLEAN NOT NULL DEFAULT FALSE`.
*   Khi `mustChangePassword == true`, mọi API nghiệp vụ đều bị trả về **`HTTP 403 Forbidden`** kèm mã lỗi `FORCE_PASSWORD_CHANGE_REQUIRED`.
*   Chỉ cho phép duy nhất: `POST /api/v1/auth/change-password` và `POST /api/v1/auth/logout`.

---

## 3. LỚP 2: RANH GIỚI HỆ THỐNG & THE FARM BARRIER GUARD

### 3.1. Nguyên Tắc Cốt Tử: Tuyệt Đối Không Tin Dữ Liệu Client (Never Trust Client Payload)
1.  Mọi DTO Request (`@RequestBody`) **TUYỆT ĐỐI KHÔNG CHỨA TRƯỜNG `tenantId` VÀ `userId`**.
2.  Backend Service **BẮT BUỘC PHẢI TỰ TRÍCH XUẤT** `tenantId` và `userId` từ `SecurityContextHolder.getContext().getAuthentication().getPrincipal()` đã được xác thực qua JWT.
3.  Đối với `farmId`: Truyền qua `@PathVariable` hoặc `@RequestParam`, Backend bắt buộc phải gọi `FarmSecurityEvaluator.canAccessFarm(farmId)` để chặn đứng nguy cơ IDOR (Insecure Direct Object Reference).

### 3.2. Quy Tắc Cô Lập Dữ Liệu Bắt Buộc (Mandatory Data Scope Filtering)
Mọi câu lệnh truy vấn dữ liệu (Spring Data JPA, Hibernate, JPQL, Native SQL) **BẮT BUỘC PHẢI ÁP ĐẶT ĐIỀU KIỆN CÔ LẬP**:

1.  **Truy vấn cấp Doanh nghiệp / Tenant (Tenant-Scoped Data):**
    *   Áp dụng cho các bảng dùng chung cấp toàn công ty: `enterprises`, `materials`, `material_categories`, `crop_types`, `livestock_breeds`, `cost_categories`, `employees`, `work_shifts`.
    *   Mệnh đề SQL/JPA bắt buộc:
        ```sql
        WHERE tenant_id = :currentTenantId
        ```
2.  **Truy vấn cấp Cơ sở Thực địa (Farm-Scoped Data - The Farm Barrier Guard):**
    *   **Áp dụng triệt để cho cả bảng Đối tác:** Bảng `partners` đã được nâng cấp bổ sung cột `farm_id` (Flyway `V1_1`). Đối tác nhà cung cấp, khách hàng sỉ thuộc trang trại nào thì chỉ hiển thị và giao dịch trong phạm vi `farm_id` đó.
    *   Áp dụng cho toàn bộ các bảng vận hành thực địa: `partners`, `warehouses`, `production_zones`, `zone_locations`, `crop_seasons`, `livestock_groups`, `farming_logs`, `livestock_events`, `warehouse_receipts`, `warehouse_issues`, `stocktakes`, `harvest_records`, `product_batches`, `qc_inspections`, `time_attendances`, `farm_tasks`, `farm_expenses`, `sales_orders`, `debt_records`, `payment_transactions`, `operational_cycles`.
    *   Mệnh đề SQL/JPA bắt buộc:
        ```sql
        WHERE tenant_id = :currentTenantId 
          AND farm_id IN (:userAccessibleFarmIds)
        ```
    *   *Quy tắc phạm vi:*
        *   `ROLE_FARM_OWNER` (Cấp 2, Scope `TENANT`): `:userAccessibleFarmIds` là tập hợp toàn bộ các trang trại thuộc Tenant.
        *   `ROLE_FARM_MANAGER` (Cấp 3, Scope `FARM`): Chỉ truy cập đúng trang trại được giao điều hành trong `farms.manager_user_id` và `user_farm_access`.
        *   `ROLE_ACCOUNTANT`, `ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_FIELD_STAFF` (Cấp 4, Scope `FARM`): Bắt buộc chỉ truy cập dữ liệu trong phạm vi `farmId` được phân công. **Kế toán Cấp 4 tuyệt đối không được xem hay hạch toán số liệu của trang trại khác!**

---

## 4. LỚP 3: CHỐT CHẶN BẢO MẬT MAKER-CHECKER & TUYỂN DỤNG CẤP BẬC

### 4.1. Chốt Chặn Maker - Checker & Luật Chống Tự Duyệt (Self-Approval Immunity)
*   **Nguyên tắc cốt tử:** Nhân viên lập chứng từ / lấy mẫu (**Maker**) tuyệt đối **KHÔNG ĐƯỢC TỰ PHÊ DUYỆT** chứng từ của chính mình (**Checker**).
*   **Kiểm tra QC / KCS:**
    *   Nhân viên kỹ thuật (`ROLE_TECHNICAL_STAFF`) lập biên bản kiểm định KCS (`qc_inspections.inspector_user_id`).
    *   Người duyệt xuất xưởng lô (`product_batches.approved_by_user_id`) phải là `ROLE_FARM_MANAGER` hoặc `ROLE_FARM_OWNER`.
    *   **RÀNG BUỘC SERVICE BẮT BUỘC:** Kể cả khi tài khoản có quyền `PERM_QC_APPROVE`, nếu `inspector_user_id == currentUserId`, Backend **BẮT BUỘC NÉM RA `AccessDeniedException (403 Forbidden)`**:
        `"Luật Maker-Checker: Người lập biên bản kiểm định không được tự phê duyệt lô thành phẩm!"`
*   **Kho vận & Tài chính:**
    *   Thủ kho (`ROLE_WAREHOUSE_STAFF`) lập phiếu kho (`DRAFT`); Farm Manager duyệt (`APPROVED`).
    *   Kế toán (`ROLE_ACCOUNTANT`) lập phiếu chi / đơn bán sỉ (`DRAFT`); Farm Manager duyệt (`APPROVED`). Người tạo phiếu (`created_by_user_id`) không được tự kích hoạt chuyển trạng thái sang `APPROVED`.

### 4.2. Chốt Chặn Tuyển Dụng Theo Cấp Bậc (Hierarchical Recruitment Guard)
Nhằm ngăn ngừa leo thang đặc quyền nội bộ (Privilege Escalation):
1.  **Cấp 2 (`ROLE_FARM_OWNER`):**
    *   Chỉ có thẩm quyền tạo tài khoản, bổ nhiệm nhân sự Cấp 3 (`ROLE_FARM_MANAGER`) phụ trách các trang trại.
    *   Chủ trại không trực tiếp can thiệp tạo nhân viên Cấp 4 tác nghiệp tại từng trại.
2.  **Cấp 3 (`ROLE_FARM_MANAGER`):**
    *   Chỉ được phép tuyển dụng, tạo tài khoản và phân quyền cho nhân sự Cấp 4 (`ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_ACCOUNTANT`, `ROLE_FIELD_STAFF`) **thuộc đúng `farm_id` mà mình đang quản lý**.
    *   **CHỐT CHẶN CẤM:** Farm Manager **TUYỆT ĐỐI BỊ CHẶN** nếu cố gắng gán vai trò `ROLE_FARM_OWNER` hoặc `ROLE_FARM_MANAGER`, hoặc cố gán nhân sự sang trang trại khác (`farm_id != currentManagerFarmId`).
3.  **Cấp 4:** Không có quyền quản lý nhân sự (`PERM_HR_EMPLOYEE_MANAGE = ❌`).

---

## 5. LỚP 4: NHẬT KÝ KIỂM TOÁN BẤT ĐỒNG BỘ (AUDIT LOGGING SHIELD)

### 5.1. Bảng Sổ Cái Kiểm Toán `audit_logs` (#10)
Mọi hành động nhạy cảm đều được ghi nhận vĩnh viễn:
*   `tenant_id`, `user_id`, `action`, `module`, `endpoint`, `method`, `ip_address`, `user_agent`, `status_code`, `execution_time_ms`, `trace_id`, `old_value` (JSON trước thay đổi), `new_value` (JSON sau thay đổi), `created_at`.
*   Danh mục Action nhạy cảm bắt buộc lưu vết:
    *   `GRANT_ROLE`, `HIRE_EMPLOYEE`, `CHANGE_PASSWORD`, `REVOKE_TOKEN`.
    *   `APPROVE_RECEIPT`, `APPROVE_ISSUE`, `APPROVE_STOCKTAKE`, `APPROVE_TRANSFER`.
    *   `APPROVE_QC_BATCH`, `RECALL_BATCH`.
    *   `APPROVE_EXPENSE`, `APPROVE_SALES_ORDER`, `APPROVE_PAYMENT`, `ALLOCATE_PAYMENT`, `SETTLE_CYCLE`.

### 5.2. Kiến Trúc Bất Đồng Bộ (Asynchronous Event-Driven)
*   Sử dụng Spring Event: `applicationEventPublisher.publishEvent(new AuditLogEvent(...))`
*   Listener thực thi với `@Async("auditThreadPool")` và `@TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)`: Không làm chậm độ trễ API và không làm ảnh hưởng đến transaction nghiệp vụ chính.

---

## 6. CÀI ĐẶT SPRING SECURITY CƠ BẢN (REFERENCE CODE)

```java
@Component("farmSecurity")
@RequiredArgsConstructor
public class FarmSecurityEvaluator {

    public boolean canAccessFarm(Long farmId) {
        CustomUserDetails user = SecurityUtils.getCurrentUser();
        if (user.isSuperAdmin()) return true;
        
        // Kiểm tra cùng tenant
        if (!user.getTenantId().equals(SecurityUtils.resolveFarmTenantId(farmId))) {
            return false;
        }
        
        // Cấp 2: Farm Owner (Scope TENANT) -> Được phép truy cập mọi Farm trong Tenant
        if (user.hasRole("ROLE_FARM_OWNER")) {
            return true;
        }
        
        // Cấp 3 (FM) & Cấp 4 (Accountant, Tech, Warehouse, Field) -> Bắt buộc farmId thuộc user_farm_access
        return user.getAccessibleFarmIds().contains(farmId);
    }

    public boolean canApproveBatch(Long farmId, Long batchId) {
        if (!canAccessFarm(farmId)) return false;
        
        CustomUserDetails user = SecurityUtils.getCurrentUser();
        Long inspectorUserId = SecurityUtils.resolveBatchInspectorId(batchId);
        
        // Chốt chặn Maker-Checker
        if (user.getId().equals(inspectorUserId)) {
            throw new AccessDeniedException("Luật Maker-Checker: Người kiểm định không được tự phê duyệt kết quả kiểm định của chính mình");
        }
        return true;
    }
}
```

---
*Văn kiện `RULE-SEC-005` là Hiến pháp an ninh tối cao bảo vệ toàn vẹn nền tảng Farm SaaS trước mọi hình thức tấn công, rò rỉ dữ liệu chéo trang trại và gian lận nội bộ.*
