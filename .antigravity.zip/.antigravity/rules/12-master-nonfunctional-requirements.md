# ĐẶC TẢ YÊU CẦU PHI CHỨC NĂNG & CHỈ TIÊU VẬN HÀNH ĐO LƯỜNG ĐƯỢC
## (MASTER NON-FUNCTIONAL REQUIREMENTS, SLA & MEASURABLE OPERATIONAL METRICS)

> **Mã văn kiện:** `SPEC-NFR-012`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Là Tiêu Chuẩn Nghiệm Thu Định Lượng Đo Lường Được Cho Kiến Trúc, Hiệu Năng & Vận Hành.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Tôn chỉ:** *"Đo lường bằng con số (Quantifiable Metrics) - Không ước lượng cảm tính (Zero Guesswork) - Cam kết SLA/SLO khắt khe"*.

---

## 1. HIỆU NĂNG & THỜI GIAN PHẢN HỒI (PERFORMANCE & LATENCY SLAS)

Toàn bộ các chỉ số độ trễ được đo lường tại tầng Application Server (Spring Boot RestController đến khi ghi xong response ra output stream), không bao gồm độ trễ mạng Internet công cộng của người dùng cuối.

```mermaid
graph LR
    subgraph "CAM KẾT THỜI GIAN PHẢN HỒI (LATENCY TARGETS)"
        A["API Quét Mã Vạch / QR<br/>P95 <= 150ms | P99 <= 300ms"]
        B["API Đọc Danh Sách / Chi Tiết<br/>P95 <= 250ms | P99 <= 500ms"]
        C["Giao Dịch Đa Bảng (ACID)<br/>P95 <= 600ms | P99 <= 1000ms"]
    end
```

### 1.1. Bảng Cam Kết SLA Thời Gian Phản Hồi Chi Tiết

| Nhóm API | Các Endpoint Đại Diện | Chỉ Số P95 (Phần trăm 95) | Chỉ Số P99 (Phần trăm 99) | Cơ Chế Kỹ Thuật Tối Ưu Bắt Buộc |
| :--- | :--- | :---: | :---: | :--- |
| **Tra Cứu Máy Quét & QR Code** | `GET /materials/lookup-barcode`<br/>`GET /public/traceability/{code}` | **$\le 150$ ms** | **$\le 300$ ms** | Tận dụng Index phủ toàn diện: `uk_materials_tenant_barcode`, `uk_unit_conv_tenant_barcode`, `idx_product_batches_trace_code`. Đọc trực tiếp từ bản chụp JSON `traceability_snapshots`. |
| **Truy Vấn Danh Sách & Báo Cáo** | `GET /farms/{id}/inventory`<br/>`GET /farms/{id}/crop-seasons`<br/>`GET /farms/{id}/debts` | **$\le 250$ ms** | **$\le 500$ ms** | Bắt buộc phân trang server-side (`Pageable`), Fetch Join chống lỗi N+1 Hibernate, Composite Index `(tenant_id, farm_id, status)`. |
| **Giao Dịch Đơn Bản Ghi** | `POST /hr/attendance/check-in`<br/>`PUT /tasks/{id}/status` | **$\le 300$ ms** | **$\le 600$ ms** | Single-table write, kiểm tra GPS Geofence bằng thuật toán Haversine in-memory. |
| **Giao Dịch Nguyên Tử Đa Bảng (ACID)** | `POST /farming-logs` (Backflush)<br/>`POST /receipts/{id}/complete`<br/>`POST /payments/{id}/allocate` | **$\le 600$ ms** | **$\le 1000$ ms** | Khóa bi quan theo dòng (`PESSIMISTIC_WRITE`), cập nhật thẻ kho và công nợ trong cùng 1 transaction, bắn sự kiện Audit bất đồng bộ `AFTER_COMMIT`. |
| **Xuất File Báo Cáo / Kết Xuất Dữ Liệu** | `GET /reports/executive-dashboard`<br/>`GET /reports/export-excel` | **$\le 2000$ ms** | **$\le 4000$ ms** | Truy vấn Streaming dữ liệu (SXSSFWorkbook), giới hạn tối đa 10.000 dòng/lần xuất. |

### 1.2. Chiến Lược Phân Trang Bắt Buộc (Mandatory Pagination Strategy)
1.  **Quy Tắc Kích Thước Trang:**
    *   Kích thước mặc định (`default size`): **20 bản ghi/trang**.
    *   Kích thước tối đa cho phép (`max size`): **100 bản ghi/trang**.
    *   *Chốt chặn an toàn:* Nếu Client gửi tham số `size > 100`, Backend **BẮT BUỘC PHẢI TỰ ĐỘNG ÉP VỀ 100** hoặc từ chối bằng lỗi `400 Bad Request - Page size exceeds limit of 100`.
2.  **Cấm Tuyệt Đối `SELECT *` Không Giới Hạn:**
    *   Nghiêm cấm Controller hoặc Repository thực thi `findAll()` mà không truyền tham số `Pageable` trên các bảng sổ cái tăng trưởng nhanh: `warehouse_inventory_transactions` (#38), `product_batch_transactions` (#48), `audit_logs` (#10), `time_attendances` (#54).
    *   Mọi câu lệnh đếm tổng (`COUNT(*)`) phải sử dụng Index để tránh Full Table Scan khi dữ liệu vượt quá 100.000 dòng.

---

## 2. KHẢ NĂNG CHỊU TẢI ĐỒNG THỜI & CHỐNG XUNG ĐỘT (CONCURRENCY & LOCKING)

### 2.1. Chỉ Tiêu Chống Xung Đột Dữ Liệu Đồng Thời (Concurrency Target)
*   **Cam kết:** **0% Lỗi Race Condition** (Zero Negative Stock, Zero Over-allocation, Zero Double Spending).
*   **Kịch bản kiểm thử tải (Stress Concurrency Test):** Khi 50 requests đồng thời gửi yêu cầu xuất kho cùng 1 lô vật tư trong `warehouse_inventory` (#31) hoặc cùng phân bổ thanh toán vào 1 khoản nợ trong `debt_records` (#66):
    *   100% các giao dịch phải được thực thi tuần tự hóa hoặc bị từ chối nếu hết số lượng.
    *   Số dư tồn kho và số dư nợ tuyệt đối không bao giờ bị âm hoặc bị sai lệch toán học so với tổng các dòng thẻ kho.

### 2.2. Quy Định Khóa Bi Quan & Thời Gian Chờ (Pessimistic Locking Timeout)
1.  **Cấu hình Timeout:**
    *   Mọi câu lệnh khóa `PESSIMISTIC_WRITE` bắt buộc thiết lập thuộc tính `javax.persistence.lock.timeout`:
        ```properties
        jakarta.persistence.lock.timeout=3000
        ```
    *   Thời gian chờ khóa tối đa cho phép là **3000ms (3 giây)**.
2.  **Xử Lý Khi Quá Hạn Chờ Khóa:**
    *   Nếu một thread không giành được khóa sau 3 giây (do transaction khác đang giữ), hệ thống bắt buộc bắt ngoại lệ `PessimisticLockingFailureException` hoặc `LockTimeoutException` và chuyển đổi thành:
        $$\text{HTTP 409 Conflict} \longrightarrow \text{errorCode: "CONCURRENT_MODIFICATION"}$$
    *   Message trả về cho Client: *"Dữ liệu đang được cập nhật bởi một giao dịch khác. Vui lòng tải lại và thử lại sau ít giây."*

### 2.3. Khóa Lạc Quan (`@Version` Optimistic Locking) Chống Ghi Đè (Lost Update)
*   Trên các bảng Master Data và Chứng từ (`materials`, `warehouses`, `crop_seasons`, `sales_orders`, `budgets`):
    *   Sử dụng cột `version BIGINT DEFAULT 0` trong DDL để ánh xạ chú thích `@Version` của JPA.
    *   Khi 2 Quản trị viên cùng mở form chỉnh sửa 1 mặt hàng hoặc 1 đơn hàng: Người bấm `[ Lưu ]` sau sẽ nhận ngay lỗi `409 Conflict - Optimistic Lock Failure` thay vì ghi đè âm thầm lên sửa đổi của người trước.

---

## 3. TÍNH TOÀN VẸN, KHẢ NĂNG PHỤC HỒI & LƯU TRỮ TỆP TIN (RELIABILITY & STORAGE)

### 3.1. Ràng Buộc Tải Lên Đa Phương Tiện & Kiểm Thực Nhị Phân (Media Upload Guard)
Các trường lưu trữ URL hình ảnh/tệp tin trong hệ thống: `check_in_photo_url`, `check_out_photo_url` (`time_attendances`), `proof_image_url` (`payment_transactions`), `proof_of_delivery_url` (`sales_deliveries`), `logo_url` (`enterprises`).

| Tiêu Chí Kỹ Thuật | Ngưỡng Giới Hạn Bắt Buộc | Hành Vi Xử Lý Của Hệ Thống |
| :--- | :---: | :--- |
| **Dung Lượng Tệp Tối Đa** | **$\le 5$ MB / file** | Từ chối ngay lập tức ở tầng Gateway bằng lỗi `413 Payload Too Large` nếu vượt quá 5MB. |
| **Định Dạng Mở Rộng Cho Phép** | `.jpg`, `.jpeg`, `.png`, `.webp`, `.pdf` | Chặn tuyệt đối các file thực thi (`.exe`, `.sh`, `.bat`, `.js`, `.php`). |
| **Kiểm Thực Magic Bytes (Bắt Buộc)**| Kiểm tra Header nhị phân thực tế của file | Ngăn chặn việc đổi đuôi file giả mạo (ví dụ: đổi `script.php` thành `image.jpg`). Sử dụng thư viện Apache Tika để đọc magic number. |
| **Nén Ảnh Hiện Trường Phía Client** | Nén trước khi upload | Frontend tự động resize ảnh chụp hiện trường về độ phân giải tối đa 1920x1080 và nén chất lượng WebP 80% (giảm dung lượng từ 4MB xuống < 500KB) nhằm tiết kiệm băng thông 4G ngoài đồng ruộng. |

### 3.2. Chính Sách Lưu Giữ Dữ Liệu Bất Biến (Data Retention & Immutable Ledgers)
*   **Nguyên tắc Không Xóa Vật Lý (No Hard Delete):** Tuyệt đối cấm thực hiện câu lệnh `DELETE` trên 6 bảng sổ cái kế toán và truy xuất:
    1.  `audit_logs` (#10): Nhật ký kiểm toán thao tác người dùng.
    2.  `warehouse_inventory_transactions` (#38): Thẻ kho lịch sử biến động xuất nhập.
    3.  `product_batch_transactions` (#48): Lịch sử giao dịch lô thành phẩm.
    4.  `traceability_snapshots` (#49): Bản chụp đóng băng dữ liệu VietGAP xuất xưởng.
    5.  `payment_allocations` (#68): Bản ghi phân bổ dòng tiền cấn trừ nợ.
    6.  `label_print_logs` (#50): Lịch sử in ấn tem nhãn nhiệt.
*   **Thời Gian Lưu Trữ:** Tối thiểu **5 năm (60 tháng)** để đảm bảo tuân thủ Luật Kế toán Việt Nam và quy chuẩn thanh tra truy xuất nguồn gốc nông sản VietGAP/GlobalGAP.

---

## 4. TƯƠNG THÍCH THIẾT BỊ, TRÌNH DUYỆT & KHẢ NĂNG TIẾP CẬN (COMPATIBILITY)

```mermaid
graph TD
    subgraph "MÔI TRƯỜNG VẬN HÀNH CHUẨN"
        DESKTOP["Máy Tính Văn Phòng / Kế Toán<br/>Độ phân giải >= 1280x720<br/>Chrome, Edge, Safari, Firefox"]
        MOBILE["Di Động Hiện Trường / Công Nhân<br/>Màn hình >= 360px (Mobile-first)<br/>Android Chrome, iOS Safari"]
        SCANNER["Máy Quét Mã Vạch HID<br/>Tốc độ phím <= 50ms/char<br/>Hậu tố Enter KeyCode 13"]
        PRINTER["Máy In Nhiệt ESC/POS<br/>Khổ 50x50mm hoặc 35x22mm<br/>In không phụ thuộc Driver Windows"]
    end
```

### 4.1. Ma Trận Hỗ Trợ Thiết Bị & Trình Duyệt
1.  **Văn Phòng & Kế Toán (Desktop Workspaces A, B, C, D, F1, H1):**
    *   *Trình duyệt:* Google Chrome ($\ge 100$), Microsoft Edge ($\ge 100$), Apple Safari ($\ge 15$), Mozilla Firefox ($\ge 100$).
    *   *Độ phân giải hiển thị tối ưu:* $\ge 1280 \times 720$ (Tối ưu hóa tốt nhất ở Full HD $1920 \times 1080$).
2.  **Công Nhân & Kỹ Sư Hiện Trường (Mobile Workspace G, E, F2, Cổng QR):**
    *   *Trình duyệt di động:* Safari trên iOS 14+, Chrome trên Android 9+.
    *   *Màn hình di động tối thiểu:* $360 \times 640$ pixels.
    *   *Khả năng truy cập phần cứng:* Yêu cầu quyền truy cập Geolocation (GPS độ chính xác cao) và Camera WebRTC trước/sau.

### 4.2. Tương Thích Thiết Bị Ngoại Vi Nông Nghiệp (Hardware Interoperability)
1.  **Máy Quét Mã Vạch Laser / 2D (Barcode / QR Scanners):**
    *   Giao tiếp qua chuẩn **USB HID Keyboard Emulation** hoặc **Bluetooth SPP/HID**.
    *   *Tiêu chuẩn nhận diện:* Hệ thống xử lý chuỗi ký tự nhận vào với tốc độ gõ phím cực nhanh ($\le 50$ms/ký tự) và tự động nhận diện ký tự ngắt dòng `Enter` (`KeyCode = 13`) để kích hoạt API lookup mà không làm reload trang.
2.  **Máy In Tem Nhãn Nhiệt (Direct Thermal Printers):**
    *   Hỗ trợ in qua lệnh in đồ họa trình duyệt hoặc lệnh trực tiếp chuẩn **ESC/POS / TSPL**.
    *   *Quy cách khổ giấy in tem tem nhãn chuẩn:*
        *   Khổ tem vuông truy xuất: **$50 \times 50$ mm** (dán quả, dán hộp nông sản).
        *   Khổ tem barcode kho: **$35 \times 22$ mm** (dán bao bì phân bón, khay vỉ).

---

## 5. GIÁM SÁT, SAO LƯU & KHÔI PHỤC THẢM HỌA (MONITORING, BACKUP & DR)

### 5.1. Giám Sát Sức Khỏe & Ghi Nhật Ký Hệ Thống (Observability & Logging)
1.  **Health Check Endpoints (Spring Boot Actuator):**
    *   `/actuator/health/liveness`: Trả về `UP` nếu tiến trình JVM đang hoạt động bình thường.
    *   `/actuator/health/readiness`: Kiểm tra kết nối cơ sở dữ liệu MySQL và bộ nhớ disk. Trả về `DOWN` nếu mất kết nối Database để Kubernetes/Docker Swarm tự động cô lập instance lỗi.
2.  **Chuẩn Hóa Structured JSON Logging:**
    *   Mọi dòng log của ứng dụng được xuất dưới định dạng JSON có cấu trúc, bắt buộc chứa các trường:
        *   `timestamp`: Thời gian chuẩn ISO-8601 UTC.
        *   `level`: `INFO`, `WARN`, `ERROR`.
        *   `traceId`: Mã định danh luồng yêu cầu phân tán (W3C TraceContext) xuyên suốt từ Frontend Request Header đến SQL Query.
        *   `tenantId`: ID khách thuê phát sinh thao tác (nếu đã xác thực).
        *   `userId`: ID người dùng thực thi.
        *   `message`: Thông điệp mô tả chi tiết kèm Exception StackTrace (nếu là lỗi).

### 5.2. Chỉ Tiêu Khôi Phục Thảm Họa (Disaster Recovery Targets)

| Chỉ Số Mục Tiêu | Ngưỡng Cam Kết | Giải Pháp Kỹ Thuật Đảm Bảo |
| :--- | :---: | :--- |
| **RPO (Recovery Point Objective)**<br/>*Mức độ mất mát dữ liệu tối đa chấp nhận được* | **$\le 24$ Giờ** | Tự động sao lưu toàn bộ (Full Backup) MySQL 8.x mỗi ngày lúc 01:00 AM (giờ máy chủ). Lưu trữ bản backup mã hóa AES-256 trên Cloud Storage độc lập khác vùng địa lý. |
| **RTO (Recovery Time Objective)**<br/>*Thời gian tối đa để hệ thống hoạt động trở lại sau sự cố* | **$\le 2$ Giờ** | Kịch bản khôi phục tự động bằng Docker Compose / Helm Chart kết hợp script phục hồi database từ file dump mới nhất. |
| **Tính Sẵn Sàng Vận Hành (Availability SLA)** | **$99.5\%$ / Tháng** | Thời gian gián đoạn tối đa không quá 3.6 giờ mỗi tháng (không bao gồm lịch bảo trì định kỳ có thông báo trước 48h). |

---

*Văn kiện `SPEC-NFR-012` là tiêu chuẩn chất lượng bất biến; toàn bộ mã nguồn Backend, Frontend và hạ tầng triển khai đều phải thỏa mãn 100% các chỉ số SLA trên trong mọi đợt kiểm thử hiệu năng.*
