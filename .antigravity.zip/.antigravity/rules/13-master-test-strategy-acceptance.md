# ĐẶC TẢ CHIẾN LƯỢC KIỂM THỬ & KỊCH BẢN NGHIỆM THU TOÀN HỆ THỐNG
## (MASTER TEST STRATEGY & END-TO-END ACCEPTANCE SPECIFICATION)

> **Mã văn kiện:** `SPEC-TEST-013`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Là Bộ Tiêu Chuẩn Nghiệm Thu Chất Lượng (Quality Gate) Cho Toàn Bộ Hệ Thống.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Tôn chỉ:** *"Không kiểm thử không merge (No Test, No Merge) - 100% Giao dịch quan trọng có Integration Test - Triệt tiêu lỗi đồng thời (Zero Concurrency Flaws)"*.

---

## 1. CHIẾN LƯỢC KIỂM THỬ 4 TẦNG (THE 4-TIER TESTING PYRAMID)

Hệ thống Agri-ERP áp dụng mô hình Kim Tự Tháp Kiểm Thử 4 Tầng toàn diện nhằm bảo vệ dữ liệu nghiệp vụ, ngăn chặn rò rỉ quyền hạn và đảm bảo khả năng chịu tải:

```mermaid
graph TD
    classDef t1 fill:#3b82f6,stroke:#1d4ed8,stroke-width:2px,color:#ffffff;
    classDef t2 fill:#10b981,stroke:#047857,stroke-width:2px,color:#ffffff;
    classDef t3 fill:#f59e0b,stroke:#b45309,stroke-width:2px,color:#ffffff;
    classDef t4 fill:#8b5cf6,stroke:#6d28d9,stroke-width:2px,color:#ffffff;

    T4["TẦNG 4: FRONTEND COMPONENT & E2E ACCEPTANCE TEST<br/>Vitest, React Testing Library, Playwright E2E<br/>Kiểm thử 4 Shells, <Can> Guard, Luồng Nghiệp Vụ Khép Kín"]:::t4

    T3["TẦNG 3: BẢO MẬT RBAC & CHỊU TẢI ĐỒNG THỜI (CONCURRENCY)<br/>Cross-Tenant, Cross-Farm, Maker-Checker Guard, CountDownLatch 50 Threads"]:::t3

    T2["TẦNG 2: TÍCH HỢP GIAO DỊCH VÀ DATABASE THỰC TẾ (INTEGRATION TEST)<br/>Spring Boot Test + Testcontainers MySQL 8.x InnoDB (72 Bảng)<br/>Xác thực Constraints, Triggers ảo, Rollback 7 Luồng @Transactional"]:::t2

    T1["TẦNG 1: KIỂM THỬ ĐƠN VỊ THUẦN TÚY (UNIT TEST)<br/>JUnit 5 + Mockito (Coverage >= 85%)<br/>Công Thức Toán Học, Máy Trạng Thái FSM, Haversine GPS, Quy Đổi Đơn Vị"]:::t1

    T1 --> T2 --> T3 --> T4
```

---

### 1.1. Tầng 1: Kiểm Thử Đơn Vị Thuần Túy (Unit Test - JUnit 5 & Mockito)
*   **Mục tiêu:** Kiểm thử cách ly logic toán học và các quy tắc miền mà không cần khởi động Spring Context hay Database.
*   **Chỉ tiêu độ bao phủ (Code Coverage):** Tối thiểu **$\ge 85\%$** trên các package `service`, `util`, `validator`.
*   **Các module trọng tâm bắt buộc có Unit Test:**
    1.  **Công thức quy đổi đơn vị:** Kiểm thử `material_unit_conversions` với công thức $\text{quantity} = \text{enteredQuantity} \times \text{conversionFactor}$.
    2.  **Máy trạng thái FSM (File `02`):** Kiểm thử ma trận chuyển dịch trạng thái của 29 thực thể, bảo đảm ném lỗi `IllegalStateException` khi chuyển dịch trạng thái bất hợp lệ (ví dụ: chuyển `sales_orders` từ `CANCELLED` sang `CONFIRMED`).
    3.  **Công thức cách ly an toàn nông nghiệp (File `03`):**
        *   Cách ly thuốc BVTV: $\text{phi\_end\_date} = \text{log\_date} + \text{phi\_days}$.
        *   Cách ly ngưng thuốc thú y: $\text{withdrawal\_end\_date} = \text{event\_date} + \text{withdrawal\_days}$.
    4.  **Khoảng cách Geofence GPS (Thuật toán Haversine):** Kiểm thử tính khoảng cách giữa tọa độ thiết bị và tâm Farm, xác định cờ trong/ngoài bán kính `geofence_radius_m`.
    5.  **Công thức tính giờ công và phút trễ:**
        *   $\text{working\_hours} = (\text{check\_out} - \text{check\_in} - \text{break\_minutes}) / 60$.
        *   $\text{late\_minutes} = \max(0, \text{check\_in} - \text{start\_time} - \text{grace\_late\_minutes})$.
    6.  **Đẳng thức toán học giá thành & công nợ:**
        *   Giá thành đơn vị: $\text{Unit Cost} = \sum \text{Allocated Expenses} / \text{Actual Yield Kg}$.
        *   Công nợ đơn hàng: $\text{debt\_amount} = \text{final\_amount} - \text{paid\_amount}$.

---

### 1.2. Tầng 2: Kiểm Thử Tích Hợp Cơ Sở Dữ Liệu Thực Tế (Integration Test - Testcontainers)
*   **Môi trường:** Bắt buộc sử dụng **Testcontainers chạy container MySQL 8.x InnoDB thực tế** (Tuyệt đối cấm dùng H2 Database in-memory vì H2 không hỗ trợ cú pháp `GENERATED ALWAYS AS ... VIRTUAL`, cú pháp JSON của MySQL và cơ chế khóa dòng `SELECT ... FOR UPDATE`).
*   **Các nội dung kiểm thử bắt buộc:**
    1.  **Kiểm thực 100% Constraints của SQL:**
        *   Vi phạm `geofence_radius_m <= 0 (chk_farms_geofence)` $\rightarrow$ Bắt buộc ném `DataIntegrityViolationException`.
        *   Vi phạm `credit_limit < 0` hoặc `annual_leave_quota < 0` $\rightarrow$ Bắt buộc ném Exception.
        *   Vi phạm Unique Composite Index `uk_user_roles_scoped (user_id, role_id, assigned_scope_farm_id)` khi gán 2 role cùng scope $\rightarrow$ Ném lỗi trùng lặp.
    2.  **Kiểm thực Composite Foreign Keys (The Farm Barrier Guard):**
        *   Tạo bản ghi Zone thuộc Farm B nhưng lại cố tình gán vào Tenant A $\rightarrow$ Database phải chặn bằng lỗi vi phạm khóa ngoại tổ hợp `(tenant_id, farm_id)`.
    3.  **Kiểm thực Tính Toàn Vẹn ACID Của 7 Luồng `@Transactional` (File `06`):**
        *   *Luồng 1 (Farming Log Backflush):* Ghi nhật ký canh tác thành công $\rightarrow$ Kiểm tra tự động sinh đúng 1 dòng `warehouse_issues` và trừ số lượng `warehouse_inventory`. Cố tình gây lỗi ở bước cuối $\rightarrow$ Xác nhận toàn bộ giao dịch bị rollback 100%, tồn kho không bị trừ.
        *   *Luồng 2 (Hoàn tất nhập kho):* Phiếu nhập mua hàng hoàn tất $\rightarrow$ Tăng tồn kho, ghi thẻ kho, sinh bản ghi `debt_records` loại `PAYABLE`.
        *   *Luồng 4 (Duyệt KCS):* Phê duyệt lô $\rightarrow$ Sinh mã UUID, tạo bản ghi `traceability_snapshots` đóng băng dữ liệu.
        *   *Luồng 5 (Giữ chỗ lô bán sỉ):* Duyệt đơn $\rightarrow$ Tăng `reserved_quantity`, không cho phép đơn hàng khác đặt vượt quá số lượng còn lại.
        *   *Luồng 7 (Phân bổ thanh toán):* Cấn trừ nợ $\rightarrow$ Cập nhật `debt_records.paid_amount`, nếu trả đủ thì chuyển trạng thái nợ sang `SETTLED`.

---

### 1.3. Tầng 3: Kiểm Thử An Ninh RBAC & Chịu Tải Đồng Thời (Security & Concurrency Test)

#### A. Ma Trận Kiểm Thử An Ninh & Ranh Giới Dữ Liệu:
1.  **Kiểm thử rào chắn đa khách thuê (Cross-Tenant Barrier):**
    *   Tài khoản thuộc `Tenant 1` gửi request kèm ID kho/mùa vụ của `Tenant 2` $\rightarrow$ Hệ thống bắt buộc trả về `403 Forbidden` hoặc `404 Not Found`. Không có ngoại lệ.
2.  **Kiểm thử rào chắn đa trang trại (Cross-Farm Barrier):**
    *   Tài khoản `ROLE_FIELD_STAFF` của `Farm 1` gửi request thao tác trên `farmId = 2` $\rightarrow$ Chốt chặn `@farmSecurity.canAccessFarm(#farmId)` bắt buộc trả về `403 Forbidden`.
3.  **Kiểm thử chốt chặn phân tách KCS Maker-Checker:**
    *   Tài khoản `ROLE_TECHNICAL_STAFF` cố tình gọi API `/product-batches/{id}/approve` $\rightarrow$ Trả về `403 Forbidden`.
    *   Tài khoản `ROLE_FARM_OWNER` là người trực tiếp lấy mẫu kiểm tra (`qc_inspections.inspector_user_id == currentUserId`) cố tình phê duyệt lô hàng của chính mình $\rightarrow$ Trả về `403 Forbidden - Self-Approval Not Allowed`.
4.  **Kiểm thử cưỡng chế đổi mật khẩu:**
    *   Tài khoản có `must_change_password = true` cố tình gọi API nghiệp vụ (như tạo đơn hàng, chấm công) $\rightarrow$ Trả về `403 Forbidden` yêu cầu chuyển hướng sang màn hình đổi mật khẩu.

#### B. Kiểm Thử Đồng Thời Đa Luồng (Stress Concurrency Test):
Sử dụng `CountDownLatch` kích hoạt đồng thời 50 threads gửi request tới cùng một tài nguyên:
1.  **Bài test 1 - Tranh chấp tồn kho vật tư:**
    *   Lô vật tư có tồn khả dụng là $10.0$ kg.
    *   50 threads đồng thời gửi lệnh xuất kho mỗi lệnh $1.0$ kg.
    *   *Kết quả mong đợi:* Đúng 10 threads thành công, 40 threads còn lại nhận mã lỗi `400 Bad Request (INSUFFICIENT_STOCK)`. Tồn kho cuối cùng phải bằng chính xác $0.0$ kg (Tuyệt đối không bị âm).
2.  **Bài test 2 - Tranh chấp giữ chỗ lô bán sỉ:**
    *   Lô xoài có số lượng mở bán $100.0$ kg.
    *   20 nhân viên đồng thời duyệt đơn đặt mỗi đơn $20.0$ kg.
    *   *Kết quả mong đợi:* Đúng 5 đơn thành công, các đơn sau nhận lỗi hết hàng khả dụng.
3.  **Bài test 3 - Tranh chấp cấn trừ công nợ:**
    *   Khoản nợ còn lại là $50,000,000$ VNĐ.
    *   10 giao dịch đồng thời phân bổ mỗi giao dịch $10,000,000$ VNĐ.
    *   *Kết quả mong đợi:* Đúng 5 giao dịch thành công đưa nợ về $0$ VNĐ, các giao dịch sau bị từ chối. Không xảy ra tình trạng phân bổ vượt nợ (Over-allocation).

---

### 1.4. Tầng 4: Kiểm Thử Giao Diện & Luồng Nghiệp Vụ Khép Kín (Frontend E2E Acceptance)
*   **Công cụ:** Vitest + React Testing Library (Component tests) & Playwright (E2E Integration).
*   **Nội dung kiểm thử thành phần UI:**
    *   **Thẻ `<Can>` Guard:** Kiểm tra render có điều kiện các nút bấm thay đổi trạng thái (ẩn nút `[ Phê Duyệt KCS ]` với tài khoản kỹ thuật).
    *   **Smart Empty State:** Bảng rỗng hiển thị thông báo hướng dẫn và nút CTA điều hướng thay vì bảng trắng trơn.
    *   **Double-Submit Guard:** Nút bấm submit form tự động chuyển sang trạng thái loading và disabled sau lần click đầu tiên để chống gửi request lặp.
*   **Luồng Kiểm Thử E2E Đầu Cuối Khép Kín (The Golden Master Flow):**
    Triển khai kịch bản tự động hóa Playwright mô phỏng 1 chu trình sản xuất nông nghiệp hoàn chỉnh từ A đến Z:
    $$\text{Đăng nhập SaaS} \rightarrow \text{Tạo Trang trại & Phân khu} \rightarrow \text{Khai báo Vật tư & Nhập kho mua hàng} \rightarrow \text{Mở Mùa vụ canh tác}$$
    $$\rightarrow \text{Ghi Nhật ký bón phân (Auto-Backflush trừ kho)} \rightarrow \text{Chấm công công nhân GPS/Selfie} \rightarrow \text{Thu hoạch nông sản (Kiểm tra PHI)}$$
    $$\rightarrow \text{Đóng gói Lô thành phẩm} \rightarrow \text{Kiểm định KCS đạt chuẩn} \rightarrow \text{Duyệt lô & Đóng băng Snapshot QR} \rightarrow \text{Tạo Đơn bán sỉ}$$
    $$\rightarrow \text{Giữ chỗ lô hàng} \rightarrow \text{Giao hàng xuất kho} \rightarrow \text{Quét thanh toán VietQR Napas247} \rightarrow \text{Tất toán công nợ}$$
### 1.5. Giao Thức Kiểm Thử Chống Gian Lận (Anti-Cheat Testing Protocol)

Nhằm đảm bảo tính trung thực tuyệt đối của hệ thống mã nguồn và ngăn chặn các hành vi "lách kiểm thử" (test cheating), toàn bộ lập trình viên và tác nhân AI phải tuân thủ nghiêm ngặt 3 nguyên tắc sau:

1.  **Quy Tắc Bất Biến Về File Kiểm Thử (Strict Test Code Immutability):**
    *   **CẤM TUYỆT ĐỐI** việc chỉnh sửa, xóa bỏ, comment out các câu lệnh `assert`, `expect`, hoặc thay đổi dữ liệu mong đợi trong các file test hiện hữu nhằm mục đích làm cho bài test chuyển xanh (PASS) giả tạo khi code nghiệp vụ đang bị lỗi.
    *   Khi bài test thất bại (FAIL), nguyên nhân mặc định là do mã nguồn nghiệp vụ (Backend/Frontend) chưa đáp ứng đúng đặc tả. **Bắt buộc phải sửa mã nguồn nghiệp vụ** để vượt qua bài test, không được "sửa đề bài" của bài test.
    *   Mọi thay đổi trong thư mục `src/test/` chỉ được chấp nhận khi: Bổ sung thêm test case mới, hoặc có văn bản phê duyệt thay đổi yêu cầu nghiệp vụ (Change Request - CR).

2.  **Cơ Chế Cô Lập & Tự Động Hoàn Tác Database (`@Transactional` Rollback):**
    *   100% các lớp kiểm thử tích hợp giao dịch (`Integration Tests`) có tác động ghi dữ liệu vào MySQL bắt buộc phải được gắn chú thích `@Transactional`.
    *   Mọi dữ liệu sinh ra trong quá trình thực thi test method phải được rollback sạch sẽ 100% sau khi kết thúc test, không để lại dữ liệu rác làm ô nhiễm (pollute) môi trường cho các bài test tiếp theo.
    *   Đối với các bài test đồng thời đa luồng (`Concurrency Tests` dùng `CountDownLatch` chạy ngoài Transaction của Spring Context), test suite bắt buộc phải có phương thức dọn dẹp `@AfterEach` thực hiện xóa sạch các bản ghi thử nghiệm theo đúng thứ tự ràng buộc khóa ngoại.

3.  **Kịch Bản Kiểm Thử Rào Chắn Cô Lập Chéo Trang Trại (Cross-Farm Isolation Test: Bắc Ninh vs. Đà Lạt):**
    *   Bộ dữ liệu thử nghiệm chuẩn bắt buộc khởi tạo tối thiểu 2 trang trại độc lập thuộc cùng hoặc khác khách thuê:
        *   **Trang trại A:** *Trang Trại Trồng Trọt Công Nghệ Cao Bắc Ninh* (`farm_id = 101`).
        *   **Trang trại B:** *Trang Trại Rau Củ Ôn Đới Đà Lạt* (`farm_id = 102`).
    *   **Ma trận thử nghiệm cô lập bắt buộc:**
        *   Nhân sự Cấp 4 của Bắc Ninh (`ROLE_ACCOUNTANT`, `ROLE_TECHNICAL_STAFF`, `ROLE_WAREHOUSE_STAFF`, `ROLE_FIELD_STAFF`) gửi request thao tác trên bất kỳ tài nguyên nào của Đà Lạt (Kho vật tư, phân khu, lô thành phẩm, nhật ký canh tác, đơn hàng, công nợ) $\rightarrow$ Hệ thống bắt buộc từ chối với **HTTP 403 Forbidden**.
        *   **The Farm Barrier Guard trên Đối tác (`partners.farm_id`):** Nhà cung cấp vật tư hoặc Khách hàng đại lý được tạo tại Farm Bắc Ninh tuyệt đối không thể được chọn trong Phiếu nhập kho (`warehouse_receipts`) hoặc Đơn bán sỉ (`sales_orders`) của Farm Đà Lạt $\rightarrow$ Bắt buộc trả về lỗi **HTTP 400 Bad Request / HTTP 404 Entity Not Found**.

---

## 2. DANH MỤC KỊCH BẢN KIỂM THỬ TRỌNG YẾU (MASTER TEST CASES CATALOG)

Bảng dưới đây tổng hợp các Test Case cốt lõi bắt buộc phải vượt qua trong mọi đợt phát hành (Release Gate):

| Mã Test Case | Tên Kịch Bản Nghiệp Vụ | Dữ Liệu Đầu Vào (Pre-conditions & Input) | Các Bước Thực Hiện | Kết Quả Mong Đợi (HTTP Status & DB State) | Điều Kiện Nghiệm Thu |
| :---: | :--- | :--- | :--- | :--- | :--- |
| **`TC-SEC-001`** | Chặn truy cập chéo Tenant (Cross-Tenant Barrier) | User thuộc Tenant 1; Request mang Header Token của Tenant 1 nhưng URI gọi `{warehouseId}` thuộc Tenant 2. | Gửi request `GET /api/v1/farms/1/inventory` với warehouse của Tenant khác. | **HTTP 403 Forbidden** hoặc **404 Not Found**; Không trả về bất kỳ dữ liệu kho nào. | Ranh giới dữ liệu giữa các doanh nghiệp được cô lập 100%. |
| **`TC-SEC-002`** | Chặn thao tác chéo Farm (The Farm Barrier Guard) | User có quyền `PERM_CROP_LOG` nhưng chỉ được cấp quyền `farm_id = 1` trong `user_farm_access`. | Gửi request `POST /api/v1/farms/2/farming-logs` để ghi nhật ký cho Farm 2. | **HTTP 403 Forbidden**; Không có bản ghi nào được ghi vào bảng `farming_logs`. | Nhân viên trại này không thể can thiệp vào dữ liệu trại khác. |
| **`TC-SEC-003`** | Chống tự duyệt KCS (Maker-Checker Separation) | Lô hàng BAT-01 đang `PENDING_APPROVAL`. User A là người lập biên bản kiểm định (`inspector_user_id = User A`). | User A đăng nhập tài khoản Quản lý và gọi `POST /api/v1/farms/1/product-batches/BAT-01/approve`. | **HTTP 403 Forbidden** kèm lỗi `SELF_APPROVAL_NOT_ALLOWED`. Lô giữ nguyên trạng thái `PENDING_APPROVAL`. | Người lập kiểm định KCS không được tự phê duyệt lô hàng. |
| **`TC-SEC-004`** | Cưỡng chế đổi mật khẩu lần đầu (Must Change Password) | Tài khoản nhân sự mới cấp có `must_change_password = TRUE`. | User gửi request `GET /api/v1/farms/1/inventory`. | **HTTP 403 Forbidden**; Interceptor Frontend tự động chuyển hướng sang `/force-change-password`. | Chặn toàn bộ tác vụ cho đến khi mật khẩu mặc định được đổi. |
| **`TC-SEC-005`** | Cô lập Đối tác & Dữ liệu chéo Farm (Bắc Ninh vs. Đà Lạt) | Tài khoản Cấp 4 thuộc Farm Bắc Ninh (`farm_id = 101`); Partner NCC-DL thuộc Farm Đà Lạt (`farm_id = 102`). | Gửi request `POST /api/v1/farms/101/inventory/receipts` chọn NCC-DL, hoặc gọi API sang farm 102. | **HTTP 403 Forbidden** hoặc **HTTP 400 Bad Request**; Hệ thống từ chối do vi phạm rào chắn `partners.farm_id`. | Cô lập 100% đối tác và nghiệp vụ giữa các trang trại. |
| **`TC-CONC-001`**| Tranh chấp xuất kho đồng thời (Zero Negative Stock) | Lô phân bón LOT-01 còn tồn khả dụng $10.0$ kg trong `warehouse_inventory`. | 50 threads đồng thời gọi API xuất kho mỗi lệnh $1.0$ kg (`POST /inventory/issues`). | Đúng 10 lệnh thành công (**HTTP 200**), 40 lệnh trả về **HTTP 400** `INSUFFICIENT_STOCK`. Tồn kho cuối cùng chính xác bằng $0.0$ kg. | Tồn kho không bị âm dưới bất kỳ tình huống đồng thời nào. |
| **`TC-CONC-002`**| Tranh chấp phân bổ công nợ đồng thời | Khoản nợ `debt_records` còn nợ $20,000,000$ VNĐ. | 10 threads đồng thời gọi `POST /payments/1/allocate` số tiền $5,000,000$ VNĐ. | Đúng 4 lệnh thành công, 6 lệnh thất bại. Số nợ còn lại chính xác bằng $0.0$ VNĐ. | Tổng số tiền phân bổ không vượt quá số nợ còn lại. |
| **`TC-INV-001`** | Nhập kho mua hàng & Tự động sinh công nợ phải trả | Phiếu nhập `RC-01` trạng thái `DRAFT`, loại `PURCHASE`, đối tác NCC-01, tổng tiền $30,000,000$ VNĐ. | Gọi `POST /api/v1/farms/1/inventory/receipts/RC-01/complete`. | **HTTP 200 OK**; Phiếu nhập đổi sang `COMPLETED`; Tồn kho tăng; Bảng `debt_records` sinh bản ghi nợ `PAYABLE` $30,000,000$ VNĐ. | Luồng giao dịch số 2 trong File 06 thực thi nguyên tử. |
| **`TC-INV-002`** | Quét mã vạch bao bì tự động quy đổi đơn vị | Vật tư NPK có đơn vị chuẩn là `KG`. Đã cấu hình quy cách `BOX` = 20 `KG` có `unit_barcode = '893001'`. | Gọi `GET /api/v1/farms/1/materials/lookup-barcode?code=893001`. | **HTTP 200 OK**; Trả về `materialId`, `enteredUnit = 'BOX'`, `conversionFactor = 20.0`, `standardUnit = 'KG'`. | Máy quét mã vạch tự động nhận diện và tính đúng số lượng chuẩn. |
| **`TC-CROP-001`**| Ghi nhật ký canh tác tự động trừ kho (Auto-Backflush) | Vụ mùa SSN-01 đang `GROWING`; Lô phân bón LOT-NPK còn tồn $100$ kg. | Gọi `POST /api/v1/farms/1/farming-logs` kèm tiêu hao $30$ kg phân bón. | **HTTP 200 OK**; Bản ghi `farming_logs` được tạo; Tự động sinh phiếu xuất kho `warehouse_issues` loại `PRODUCTION_BACKFLUSH`; Tồn kho giảm còn $70$ kg; Sinh chi phí trong `farm_expenses`. | Luồng giao dịch số 1 trong File 06 thực thi nguyên tử. |
| **`TC-CROP-002`**| Chốt chặn an toàn PHI ngăn thu hoạch trong thời gian cách ly | Vụ xoài SSN-01 vừa phun thuốc BVTV ngày hôm qua với `phi_days = 7` (Còn cách ly 6 ngày). | Gọi `POST /api/v1/farms/1/harvest-records` cho vụ SSN-01. | **HTTP 400 Bad Request** kèm lỗi `HARVEST_BLOCKED_BY_PHI`; UI nút Thu hoạch bị vô hiệu hóa màu đỏ. | Tuyệt đối không cho phép thu hoạch khi chưa hết thời gian cách ly PHI. |
| **`TC-LIVE-001`**| Ghi nhận cân nặng đàn & Tính tốc độ tăng trọng ADG | Lứa heo PIG-01 có số lượng $100$ con. Lần cân trước trung bình $40$ kg cách đây 10 ngày. | Gọi `POST /api/v1/farms/1/livestock-groups/PIG-01/weigh-in` với mẫu 10 con, tổng $500$ kg. | **HTTP 200 OK**; `average_weight_kg = 50.0` kg; Tính tốc độ tăng trọng $\text{ADG} = (50 - 40) / 10 = 1.0$ kg/con/ngày. | Đồ thị ADG được cập nhật tức thì trên Dashboard. |
| **`TC-QA-001`**  | Phê duyệt KCS & Đóng băng Snapshot QR nguồn gốc | Lô xoài BAT-01 có kết quả kiểm nghiệm `PASSED`. Quản lý độc lập duyệt lô. | Gọi `POST /api/v1/farms/1/product-batches/BAT-01/approve`. | **HTTP 200 OK**; Lô chuyển sang `READY_TO_PRINT`; Sinh mã UUID; Tạo bản ghi `traceability_snapshots` đóng băng 5 trường JSON; Tạo mã hash SHA-256. | Cổng QR công khai đọc được thông tin tức thì không cần login. |
| **`TC-QA-002`**  | Phát lệnh thu hồi khẩn cấp lô thành phẩm | Lô BAT-01 đang ở trạng thái `SELLING` trên thị trường. | Quản lý gọi `POST /api/v1/farms/1/product-batches/BAT-01/recall` kèm lý do. | **HTTP 200 OK**; Lô chuyển sang `RECALLED`; Khóa ngay lập tức không cho thêm vào Đơn bán sỉ; Cổng QR hiển thị cảnh báo đỏ toàn màn hình. | Cơ chế thu hồi khẩn cấp phản ứng tức thì bảo vệ người tiêu dùng. |
| **`TC-HR-001`**  | Chấm công GPS ngoài Geofence bị từ chối | Trang trại có Geofence bán kính $200$m. Công nhân đứng cách tâm trại $500$m. | Gửi request `POST /api/v1/hr/attendance/check-in` kèm tọa độ thực tế của máy. | **HTTP 400 Bad Request** kèm lỗi `GPS_OUTSIDE_GEOFENCE`; Hệ thống không ghi nhận công và rung chuông cảnh báo. | Ngăn chặn gian lận chấm công từ xa ngoài ranh giới trại. |
| **`TC-HR-002`**  | Chấm công GPS + Selfie hợp lệ tính đúng giờ và phạt trễ | Ca làm việc 07:00 - 11:30 (nghỉ 0 phút), ân hạn trễ 15 phút. Công nhân check-in lúc 07:25 (trễ 10 phút ngoài ân hạn) và check-out 11:30 tại trại. | Gửi check-in lúc 07:25 và check-out lúc 11:30 kèm ảnh selfie trực tiếp. | **HTTP 200 OK**; `time_attendances` ghi nhận `late_minutes = 10`, `working_hours = 4.08` giờ; Ảnh selfie lưu lên CDN. | Chấm công 2 đầu GPS + Camera hoạt động chính xác. |
| **`TC-HR-003`**  | Phê duyệt đơn xin nghỉ phép trừ quỹ phép năm | Nhân viên có `annual_leave_quota = 12` ngày. Gửi đơn xin nghỉ phép năm 3 ngày. | Quản lý bấm `[ Phê Duyệt ]` trên màn hình duyệt phép. | **HTTP 200 OK**; Đơn chuyển sang `APPROVED`; Cột `employees.annual_leave_quota` tự động giảm còn $9$ ngày. | Quỹ phép năm được quản trị tự động, chặt chẽ. |
| **`TC-HR-004`**  | Điểm danh tổ thời vụ 6B một chạm (Batch Roll-Call) | Tổ gồm 10 lao động thời vụ `SEASONAL` tại phân khu B. Trưởng khu chụp ảnh và gửi điểm danh. | Gửi `POST /api/v1/hr/attendance/batch-roll-call` kèm mảng 10 `employeeIds`, GPS và URL ảnh đội. | **HTTP 200 OK**; Tự động tạo 10 bản ghi trong `employee_attendances` với `status = 'PRESENT'`, `verified_by_user_id = managerId`. | Điểm danh tập thể nhanh gọn, không cần từng lao động lập tài khoản SaaS. |
| **`TC-FIN-001`** | Phê duyệt đơn bán sỉ & Tự động giữ chỗ lô hàng | Đơn hàng `SO-01` đặt $50$ kg xoài từ Lô BAT-01 (Lô đang có tồn $100$ kg, đã giữ chỗ $0$ kg). | Quản lý gọi `POST /api/v1/farms/1/sales-orders/SO-01/confirm`. | **HTTP 200 OK**; Đơn chuyển sang `CONFIRMED`; Lô BAT-01 cập nhật `reserved_quantity = 50` kg; Tồn thực tế giữ nguyên $100$ kg; Khả dụng còn $50$ kg. | Lô thành phẩm được giữ chỗ an toàn, không bị bán trùng lặp. |
| **`TC-FIN-002`** | Giao hàng nhiều đợt giải phóng giữ chỗ và trừ tồn kho | Đơn `SO-01` đã giữ chỗ $50$ kg. Xuất giao hàng đợt 1 số lượng $30$ kg. | Thủ kho gọi `POST /api/v1/farms/1/sales-deliveries` kèm $30$ kg và ảnh POD. | **HTTP 200 OK**; `product_batches` cập nhật `remaining_quantity = 70` kg, `reserved_quantity = 20` kg, đơn cập nhật `shipped_quantity = 30` kg. | Giữ chỗ được giải phóng nhịp nhàng theo tiến độ giao hàng thực tế. |
| **`TC-FIN-003`** | Cấn trừ công nợ 2 chiều đối tác Đại lý (DEBT_OFFSET) | Đối tác AGENT-01 có khoản nợ phải thu (mua hàng) $50$ triệu và khoản nợ phải trả (bán vật tư) $30$ triệu. | Kế toán gọi `POST /api/v1/farms/1/debts/offset` cấn trừ $30$ triệu. | **HTTP 200 OK**; Khoản nợ phải trả chuyển sang `SETTLED` ($0$ đ); Khoản nợ phải thu giảm còn $20$ triệu; Bảng `payment_allocations` ghi nhận phương thức `DEBT_OFFSET`. | Dòng tiền đối trừ minh bạch không cần chuyển khoản qua lại. |
| **`TC-FIN-004`** | Phân bổ chi phí chung vào mùa vụ tính giá thành thực tế | Hóa đơn tiền điện trạm bơm $10,000,000$ VNĐ. Vụ xoài SSN-01 thu hoạch được $5,000$ kg. | Phân bổ $5,000,000$ VNĐ tiền điện vào vụ SSN-01 (`cost_allocations`). | **HTTP 200 OK**; Chi phí phân bổ được ghi nhận; Báo cáo tính giá thành ghi nhận thêm $1,000$ VNĐ/kg chi phí điện vào giá vốn quả xoài. | Giá thành thực tế trên từng đơn vị sản lượng phản ánh chính xác chi phí. |
| **`TC-FIN-005`** | Kết toán chu kỳ vận hành 3 bước (Cycle Settlement) | Vụ mùa SSN-01 thu hoạch xong. Kế toán lập `DRAFT` $\rightarrow$ Quản lý Trại ký `SIGNED_BY_MANAGER` $\rightarrow$ Chủ Trại bấm `[ Xác Nhận & Đóng Chu Kỳ ]`. | Gọi `POST /api/v1/farms/1/cycles/1/settlement/confirm`. | **HTTP 200 OK**; Chu kỳ chuyển sang `CLOSED`; Bảng `cycle_settlements` chuyển `CONFIRMED`; Toàn bộ `farm_tasks` còn tồn đọng tự động chuyển `CANCELLED`. | Chu trình kết toán tài chính khép kín, giải phóng mặt bằng sạch cho vụ mới. |
| **`TC-RPT-001`** | Báo cáo điều hành Executive KPI Dashboard | Farm 1 có doanh thu bán hàng và chi phí vận hành năm 2026 trong DB. | Gọi `GET /api/v1/farms/1/reports/executive-kpi?year=2026`. | **HTTP 200 OK**; Trả về DTO chứa doanh thu, chi phí lũy kế, lợi nhuận gộp, tỷ lệ hoàn thành kế hoạch. | Số liệu tính toán chuẩn xác, thời gian phản hồi P95 $\le$ 250ms. |
| **`TC-RPT-002`** | Báo cáo tuổi thọ tồn kho (Inventory Aging) | Kho có các lô vật tư nhập ở các thời điểm khác nhau (0-30, 31-60, 61-90, >90 ngày). | Gọi `GET /api/v1/farms/1/reports/inventory-aging`. | **HTTP 200 OK**; Phân bổ chính xác số lượng & giá trị theo 4 nhóm tuổi thọ; cảnh báo các lô cận `expiry_alert_days`. | Phát hiện chính xác hàng tồn đọng và cận date để ưu tiên xuất FEFO. |
| **`TC-RPT-003`** | Báo cáo giá thành & Lợi nhuận vụ mùa (Crop P&L) | Vụ mùa SSN-01 đã đóng vụ; có đầy đủ chi phí phân bổ và sản lượng thu hoạch thực tế. | Gọi `GET /api/v1/farms/1/reports/crop-pnl?seasonId=SSN-01`. | **HTTP 200 OK**; Trả về bảng đối chiếu dự toán vs thực tế, giá thành đơn vị/kg, doanh thu và lãi gộp từng vụ. | So sánh chi tiết biến động chi phí và tỷ suất lợi nhuận mùa vụ. |
| **`TC-RPT-004`** | Báo cáo tiêu tốn thức ăn FCR & Nuôi sống | Đàn heo PIG-01 có nhật ký xuất cám và lịch sử cân trọng lượng tăng trưởng. | Gọi `GET /api/v1/farms/1/reports/livestock-fcr?groupId=PIG-01`. | **HTTP 200 OK**; Tính chính xác hệ số $\text{FCR} = \sum \text{Cám} / \sum \text{Tăng trọng}$, đối chiếu định mức giống chuẩn. | Đánh giá chính xác hiệu quả chuyển hóa thức ăn và tay nghề chăn nuôi. |
| **`TC-RPT-005`** | Báo cáo phân tích tuổi nợ khách hàng (Debt Aging) | Danh sách công nợ phải thu từ khách hàng với các hóa đơn trong hạn và quá hạn. | Gọi `GET /api/v1/farms/1/reports/debt-aging`. | **HTTP 200 OK**; Tổng hợp nợ theo các khung (1-30, 31-60, >90 ngày), gắn nhãn cảnh báo nợ xấu đối với khoản quá hạn. | Giúp kiểm soát rủi ro dòng tiền và cảnh báo tín dụng khách hàng. |
| **`TC-SYS-001`** | Tra cứu nhật ký kiểm toán bất biến (Audit Logs) | Hệ thống đã phát sinh thao tác UPDATE và DELETE trên các bảng nghiệp vụ. | Gọi `GET /api/v1/system/audit-logs?module=INVENTORY&page=0&size=20`. | **HTTP 200 OK**; Trả về đầy đủ `created_at, module, action, endpoint, method, status_code, ip_address, old_value, new_value`. | Dữ liệu bất biến READ-ONLY 100%, không cho phép chỉnh sửa hoặc xóa qua API. |
| **`TC-SYS-002`** | Khởi tạo khách thuê SaaS mới (Super Admin Shell) | Super Admin đăng nhập; DTO tạo tenant gồm `code, name, subdomain, subscriptionPlan`. | Gọi `POST /platform/tenants` với thông tin tenant mới. | **HTTP 201 Created**; Bản ghi `tenants` được tạo với `status = 'ACTIVE'`, tự động tạo profile `enterprises` và tài khoản Farm Owner. | Khởi tạo tenant mới độc lập hoàn toàn trên kiến trúc multi-tenant. |
| **`TC-SYS-003`** | Khóa khách thuê khẩn cấp & Thu hồi Token tức thì | Tenant 1 đang hoạt động bình thường, người dùng đang giữ JWT Token hợp lệ. | Super Admin gọi `POST /platform/tenants/1/suspend`. | **HTTP 200 OK**; `tenants.status` chuyển sang `SUSPENDED`; Mọi request tiếp theo từ token thuộc Tenant 1 bị chặn với **HTTP 403 Forbidden**. | Cơ chế khóa khẩn cấp ngắt kết nối người dùng tenant vi phạm ngay lập tức. |
| **`TC-SYS-004`** | Ghi Audit Log bất đồng bộ sau Commit (Event-Driven) | Giao dịch cập nhật đơn hàng bán sỉ `SO-01` commit thành công vào database. | Thực hiện cập nhật đơn hàng và kiểm tra thread ghi log kiểm toán. | **HTTP 200 OK**; Giao dịch chính hoàn tất tức thì; `AuditLogEventListener` chạy trên thread pool riêng lưu bản ghi vào `audit_logs` (#10). | Tác vụ ghi log không làm chậm giao dịch chính và không gây rollback ngoài ý muốn. |
| **`TC-SYS-005`** | Cổng tra cứu QR nguồn gốc nông sản công khai | Lô nông sản BAT-01 đã duyệt KCS và có `traceability_snapshots`. Request từ người tiêu dùng không có Auth Token. | Gọi `GET /api/v1/public/traceability/{snapshotCode}`. | **HTTP 200 OK**; Trả về dữ liệu đóng băng (thông tin trại, VietGAP, nhật ký canh tác, KCS); tự động tăng `scan_count`. | Giao diện công khai, siêu nhẹ, không cần đăng nhập, phản hồi dưới 100ms. |

---

*Văn kiện `SPEC-TEST-013` là thước đo nghiệm thu kỹ thuật tối cao. Bất kỳ chức năng nào chưa vượt qua đầy đủ các test case trong văn kiện này đều không được phép chuyển trạng thái sang `IMPLEMENTED`.*
