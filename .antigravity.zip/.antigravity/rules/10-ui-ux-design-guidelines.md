# TIÊU CHUẨN THẨM MỸ, DESIGN TOKENS & NGHIỆM THU FRONTEND AGRI-ERP
## (MASTER UI/UX DESIGN GUIDELINES, DESIGN TOKENS & ACCEPTANCE CHECKLIST)

> **Mã văn kiện:** `RULE-UX-010`  
> **Cấp độ hiệu lực:** **BẮT BUỘC (MANDATORY)** — Bộ Tiêu Chuẩn Thẩm Mỹ, Thiết Kế & Cổng Nghiệm Thu Code Frontend Trước Khi Merge Vào Nhánh Chính.  
> **Nguồn chuẩn DDL:** `V1_0__init_system_core.sql` (Chuẩn MySQL 8.x InnoDB, 72 bảng hợp nhất).  
> **Tôn chỉ:** *"Đẹp hiện đại nhưng thực dụng hiện trường - Phản hồi tức thì - Chống lỗi thao tác đúp - Màu sắc mang ý nghĩa trạng thái chuẩn xác"*.

---

## 1. DESIGN TOKENS & BẢNG ÁNH XẠ MÀU SẮC TRẠNG THÁI (SEMANTIC STATUS COLORS)

Tuyệt đối không dùng màu sắc tùy tiện theo cảm tính cá nhân. Toàn bộ 29 thực thể có trạng thái trong hệ thống được quy chuẩn hóa về 5 họ màu ngữ nghĩa (Semantic Color Families) dựa trên TailwindCSS:

```mermaid
graph LR
    subgraph "HỆ THỐNG MÀU NGỮ NGHĨA TRẠNG THÁI"
        S[SUCCESS / GREEN<br/>Hoàn tất, Hợp lệ, Đạt chuẩn]
        P[PRIMARY / BLUE<br/>Đang vận hành, Xuất bán]
        W[WARNING / AMBER<br/>Cách ly, Chờ duyệt, Quá hạn]
        D[DANGER / ROSE<br/>Thu hồi, Từ chối, Hủy bỏ]
        N[NEUTRAL / SLATE<br/>Bản nháp, Kế hoạch, Đóng sổ]
    end
```

### Bảng Ánh Xạ Trạng Thái SQL Ra Lớp CSS (TailwindCSS Badges):

| Nhóm Ngữ Nghĩa | Giá Trị Cột SQL (Enum / Check Constraint) | Lớp Giao Diện Badge (TailwindCSS) | Biểu Tượng Gợi Ý (Lucide Icons) |
| :--- | :--- | :--- | :---: |
| **SUCCESS** (Xanh lục) | `COMPLETED`, `PASSED`, `VALID`, `SETTLED`, `PAID`, `ACTIVE` (farms, tenants, employees) | `bg-emerald-50 text-emerald-700 border-emerald-200 ring-1 ring-emerald-600/20` | `CheckCircle2` |
| **PRIMARY** (Xanh dương) | `SELLING`, `PRINTED`, `IN_TRANSIT`, `IN_PROGRESS`, `GROWING`, `CONFIRMED`, `DISPATCHED` | `bg-blue-50 text-blue-700 border-blue-200 ring-1 ring-blue-600/20` | `PlayCircle` / `Truck` |
| **WARNING** (Vàng cam) | `QUARANTINED`, `PENDING_APPROVAL`, `OVERDUE`, `OUT_OF_RANGE`, `LATE`, `EARLY_DEPARTURE`, `FALLOW`, `MAINTENANCE`, `CONDITIONAL` | `bg-amber-50 text-amber-700 border-amber-200 ring-1 ring-amber-600/20` | `AlertTriangle` / `Clock` |
| **DANGER** (Đỏ thẫm) | `RECALLED`, `REJECTED`, `CANCELLED`, `BAD_DEBT`, `TERMINATED`, `LOCKED`, `BLACKLISTED`, `ABSENT` | `bg-rose-50 text-rose-700 border-rose-200 ring-1 ring-rose-600/20` | `XCircle` / `AlertOctagon` |
| **NEUTRAL** (Xám tro) | `DRAFT`, `PENDING`, `PLANNING`, `TODO`, `CLOSED`, `RESIGNED`, `INACTIVE`, `EMPTY`, `DISCONTINUED` | `bg-slate-50 text-slate-700 border-slate-200 ring-1 ring-slate-600/20` | `FileText` / `Archive` |

---

## 2. QUY CHUẨN ĐỊNH DẠNG DỮ LIỆU ĐỒNG BỘ (FORMATTING STANDARDS)

Để tránh nhầm lẫn và đồng nhất trải nghiệm trên toàn bộ hệ thống:

1.  **Múi Giờ Hệ Thống (Timezone):**
    *   Cố định theo Giờ Việt Nam: **`Asia/Ho_Chi_Minh` (UTC+7)**.
    *   Mọi thời gian `TIMESTAMP` trả về từ Backend (UTC ISO-8601) phải được chuyển đổi sang múi giờ VN trước khi hiển thị.
2.  **Định Dạng Ngày Tháng & Giờ Giấc:**
    *   *Ngày ngắn (Date only):* **`DD/MM/YYYY`** (Ví dụ: `18/10/2026`).
    *   *Dấu thời gian đầy đủ (DateTime):* **`DD/MM/YYYY HH:mm`** (Ví dụ: `18/10/2026 14:30`).
    *   *Giờ làm việc (Time only):* **`HH:mm`** (Ví dụ: `07:30`, `17:00`).
3.  **Định Dạng Tiền Tệ (Currency):**
    *   Đơn vị tiền tệ chính thức: **Việt Nam Đồng (VNĐ)**.
    *   Sử dụng hàm định dạng chuẩn `Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' })`:
        *   Hiển thị: `125.000.000 ₫` hoặc `125,000,000 VNĐ`.
        *   Tuyệt đối không hiển thị số trần dạng `125000000.00`.
4.  **Định Dạng Số Lượng, Khối Lượng & Diện Tích:**
    *   *Khối lượng:* Dưới 1 tấn hiển thị `kg` (Ví dụ: `850.50 kg`), trên 1 tấn hiển thị `tấn` (Ví dụ: `2.45 tấn`).
    *   *Diện tích:* Dưới $10.000 \text{ m}^2$ hiển thị $\text{m}^2$ (Ví dụ: `4.500 m²`), trên $10.000 \text{ m}^2$ hiển thị $\text{ha}$ (Ví dụ: `3.5 ha`).
    *   Số thập phân: Tối đa 2 chữ số lẻ (trừ Hệ số quy đổi `conversion_factor` hiển thị 4 số lẻ).
5.  **Xử Lý Giá Trị `NULL` / Trống:**
    *   **NGHIÊM CẤM** để ô trống vô hồn hoặc hiển thị chữ `null` / `undefined`.
    *   Bắt buộc hiển thị dấu gạch ngang mảnh **`—`** (em-dash màu `text-slate-400`) hoặc badge mờ **`Chưa cập nhật`**.

---

## 3. QUY CHUẨN RESPONSIVE & IN ẤN TEM NHÃN NHIỆT (ESC/POS PRINTING)

### 3.1. Phân Tách Trải Nghiệm Desktop vs Mobile-First
*   **Màn hình Desktop / Tablet ($\ge 1024px$ - Phục vụ Văn phòng / Thủ kho):**
    *   Tối ưu cho việc xem bảng dữ liệu lớn (DataTable nhiều cột), bảng điều khiển Kanban, biểu đồ chi phí và thao tác lọc đa chiều.
    *   Hỗ trợ phím tắt (`Ctrl+K` mở tìm kiếm nhanh, `Esc` đóng Modal/Drawer, `Enter` xác nhận quét mã vạch).
*   **Màn hình Di động Mobile-First ($< 768px$ - Phục vụ Công nhân / Kỹ sư Hiện trường):**
    *   Giao diện chạm ngón tay tối ưu: Kích thước vùng bấm nút tối thiểu **$48 \times 48\text{ px}$**.
    *   Màn hình Chấm công GPS: Thiết kế 1 nút bấm lớn trung tâm `[ CHẤM CÔNG VÀO CA ]`, tự động kích hoạt camera selfie và lấy tọa độ GPS mà không cần cuộn trang.
    *   Màn hình Ghi Nhật Ký: Thiết kế dạng từng bước (Step-by-step Wizard) để người dùng dễ thao tác bằng một tay ngoài đồng ruộng nắng chói.

### 3.2. Quy Chuẩn In Tem Nhãn Nhiệt Mã QR Truy Xuất Nguồn Gốc (ESC/POS Direct Print)
Hệ thống hỗ trợ in trực tiếp ra máy in nhiệt công nghiệp (Xprinter, Bixolon, Zebra) qua giao thức WebUSB hoặc Print Service không cần cài driver phức tạp:

```mermaid
graph TD
    subgraph "QUY CHUẨN TEM IN NHIỆT ESC/POS"
        T1["Khổ Vuông 50x50mm (Dán Thùng / Bao Lớn)<br/>- Logo Doanh Nghiệp (Góc Trái)<br/>- Mã QR Truy Xuất NanoID (Kích thước 25x25mm)<br/>- Tên Sản Phẩm & Chứng Nhận VietGAP<br/>- Mã Lô, Ngày Thu Hoạch, Hạn Sử Dụng"]
        T2["Khổ Nhỏ 35x22mm (Dán Quả / Hộp Nhỏ)<br/>- Mã QR Truy Xuất NanoID (15x15mm)<br/>- Tên Sản Phẩm & Mã Lô Tối Giản"]
    end
```

---

## 4. BỘ 10 TIÊU CHÍ NGHIỆM THU FRONTEND (FRONTEND ACCEPTANCE CHECKLIST)

Mọi Pull Request (PR) hoặc Component giao diện mới trước khi được nghiệm thu vào hệ thống **BẮT BUỘC PHẢI VƯỢT QUA 100% CÁC TIÊU CHÍ SAU**:

- [ ] **1. Chống Thao Tác Đúp (Double-Submit Guard):** Khi người dùng bấm nút Gửi/Lưu (`Submit`), nút bấm phải lập tức chuyển sang trạng thái `disabled = true`, hiển thị Spinner quay tròn và đổi nhãn thành `Đang xử lý...`. Ngăn chặn hoàn toàn việc click liên tục tạo nhiều request trùng lặp.
- [ ] **2. Kiểm Tra Ngữ Cảnh Dữ Liệu Rỗng (Smart Empty State):** Khi danh sách chưa có dữ liệu (ví dụ: Trang trại mới chưa có Vụ mùa nào), màn hình không được để bảng trống mà phải hiển thị hình minh họa Vector thân thiện kèm nút bấm điều hướng: `[ + Tạo Vụ Mùa Đầu Tiên ]`.
- [ ] **3. Xử Lý Mất Mạng / Lỗi Kết Nối (Network Error Boundary):** Nếu Client mất kết nối Internet khi đang thao tác, giao diện phải hiển thị Toast cảnh báo màu vàng: *"Mất kết nối mạng. Vui lòng kiểm tra lại đường truyền!"*. Đối với Chấm công GPS trên Mobile, lưu tạm lịch sử chấm công vào `IndexedDB` và tự động gửi lại khi có mạng.
- [ ] **4. Ánh Xạ Lỗi Validation Chuẩn Xác (Inline Field Error Mapping):** Khi Backend trả về lỗi `400 Bad Request` kèm cấu trúc `fieldErrors`, Frontend phải tự động làm đỏ viền ô input tương ứng và hiển thị đúng câu thông báo lỗi phía dưới ô đó (không chỉ hiển thị một Toast chung chung).
- [ ] **5. Cơ Chế Làm Mới Phiên Tự Động (Silent Token Refresh):** Khi Access Token hết hạn trong lúc người dùng đang điền Form dở dang, Axios Interceptor phải tự động gọi API `/refresh` ngầm để lấy token mới mà **KHÔNG ĐƯỢC RESET TRẮNG FORM** hoặc đá người dùng ra trang Login đột ngột.
- [ ] **6. Cưỡng Chế Đổi Mật Khẩu (Force Password Change Interceptor):** Nếu người dùng có cờ `mustChangePassword == true`, hệ thống tự động khóa toàn bộ menu và hiển thị Modal bắt buộc đổi mật khẩu, không cho phép tắt Modal bằng nút Close hay nhấn ra ngoài.
- [ ] **7. Rào Chắn Ngữ Cảnh Trang Trại (Farm Context Synchronization):** Khi người dùng thay đổi Trang trại trên thanh Header (`FarmContextSwitcher`), toàn bộ dữ liệu trên màn hình hiện tại phải tự động Fetch lại theo `farmId` mới, hoặc tự động redirect về trang tổng quan nếu màn hình hiện tại không thuộc Farm mới.
- [ ] **8. Phân Quyền Nút Bấm Nghiêm Ngặt (`<Can>` Guard):** Mọi nút bấm tác động dữ liệu (`Duyệt`, `Xóa`, `Sửa`, `Xuất kho`, `Giao việc`) đều phải được kiểm tra quyền hạn. Nếu tài khoản không có quyền, nút bấm phải bị ẩn hoặc hiển thị Tooltip giải thích: *"Bạn không có quyền thực hiện thao tác này"*.
- [ ] **9. Định Dạng Số Liệu Đồng Nhất (Data Formatting Uniformity):** 100% các cột tiền tệ, ngày tháng, sản lượng, số nợ đều phải chạy qua các hàm format chuẩn (`formatCurrency`, `formatDate`, `formatWeight`). Tuyệt đối không hiển thị số thập phân tùy tiện hay ngày tháng dạng `2026-10-18T07:15:00.000Z`.
- [ ] **10. Sạch Sẽ Console Trình Duyệt (Zero Console Errors):** Mở Developer Tools Console kiểm tra: **0 lỗi đỏ (Zero Red Errors)**, 0 cảnh báo `Each child in a list should have a unique 'key' prop`, và 0 cảnh báo `Can't perform a React state update on an unmounted component`.

---
*Văn kiện `RULE-UX-010` là tiêu chuẩn nghiệm thu giao diện cuối cùng, hoàn thiện trọn vẹn Bộ 10 Văn Kiện Đặc Tả Hệ Thống Farm SaaS.*
